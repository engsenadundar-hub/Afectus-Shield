# PWA Assets Placeholder

Bu klasörde aşağıdaki dosyalar bulunmalı:

- icon-192.png (192x192 px)
- icon-512.png (512x512 px)
- apple-touch-icon.png (180x180 px)
- og-image.jpg (1200x630 px)
- logo.png (şirket logosu)

Şu anda bu dosyalar yok, ama manifest.json ve HTML head'de referans veriliyor.

## Geçici Çözüm

Favicon.svg varsayılan olarak kullanılıyor. Gerçek logo dosyalarını eklemek için:

1. Figma'dan logo export et (PNG, 512x512)
2. icon-192.png, icon-512.png olarak resize et
3. Bu klasöre yükle

## Not

Eksik icon'lar PWA çalışmasını engellemez, sadece install banner ve home screen icon'ları etkilenir.
