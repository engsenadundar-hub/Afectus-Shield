/**
 * SERVICE WORKER - AFECTUS SHIELD
 * 
 * PWA Offline-First Strategy:
 * - Cache-First: Static assets (CSS, JS, fonts, images)
 * - Network-First: API calls, dynamic content
 * - Stale-While-Revalidate: HTML pages
 * 
 * Features:
 * ✅ Offline capability
 * ✅ Fast repeat visits
 * ✅ Background sync (future)
 * ✅ Push notifications (future)
 */

const CACHE_VERSION = 'afectus-shield-v1.0.0';
const STATIC_CACHE = `${CACHE_VERSION}-static`;
const DYNAMIC_CACHE = `${CACHE_VERSION}-dynamic`;
const IMAGE_CACHE = `${CACHE_VERSION}-images`;

// Static assets to pre-cache on install
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.svg',
];

// Max cache sizes
const MAX_DYNAMIC_CACHE_SIZE = 50;
const MAX_IMAGE_CACHE_SIZE = 60;

// =============================================================================
// INSTALL EVENT - Pre-cache static assets
// =============================================================================
self.addEventListener('install', (event) => {
  
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    }).then(() => {
      return self.skipWaiting(); // Activate immediately
    })
  );
});

// =============================================================================
// ACTIVATE EVENT - Clean up old caches
// =============================================================================
self.addEventListener('activate', (event) => {
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // Delete old cache versions
          if (!cacheName.startsWith(CACHE_VERSION)) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      return self.clients.claim(); // Take control immediately
    })
  );
});

// =============================================================================
// FETCH EVENT - Network strategies
// =============================================================================
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  // Skip external domains (except allowed CDNs)
  if (url.origin !== location.origin && 
      !url.origin.includes('fonts.googleapis.com') &&
      !url.origin.includes('fonts.gstatic.com') &&
      !url.origin.includes('images.unsplash.com')) {
    return;
  }

  // Strategy 1: CACHE-FIRST for static assets
  if (isStaticAsset(url.pathname)) {
    event.respondWith(cacheFirst(request, STATIC_CACHE));
    return;
  }

  // Strategy 2: CACHE-FIRST for images
  if (isImage(url.pathname)) {
    event.respondWith(cacheFirst(request, IMAGE_CACHE, MAX_IMAGE_CACHE_SIZE));
    return;
  }

  // Strategy 3: STALE-WHILE-REVALIDATE for HTML pages
  if (isHTMLPage(request)) {
    event.respondWith(staleWhileRevalidate(request, DYNAMIC_CACHE));
    return;
  }

  // Strategy 4: NETWORK-FIRST for everything else
  event.respondWith(networkFirst(request, DYNAMIC_CACHE, MAX_DYNAMIC_CACHE_SIZE));
});

// =============================================================================
// CACHING STRATEGIES
// =============================================================================

/**
 * CACHE-FIRST STRATEGY
 * Try cache first, fallback to network
 * Best for: Static assets that rarely change
 */
async function cacheFirst(request, cacheName, maxSize = null) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  
  if (cached) {
    return cached;
  }
  
  try {
    const response = await fetch(request);
    if (response && response.status === 200) {
      const clonedResponse = response.clone();
      cache.put(request, clonedResponse);
      
      // Limit cache size if specified
      if (maxSize) {
        limitCacheSize(cacheName, maxSize);
      }
    }
    return response;
  } catch (error) {
    // Return offline page if available
    return cache.match('/offline.html');
  }
}

/**
 * NETWORK-FIRST STRATEGY
 * Try network first, fallback to cache
 * Best for: Dynamic content that should be fresh
 */
async function networkFirst(request, cacheName, maxSize = null) {
  const cache = await caches.open(cacheName);
  
  try {
    const response = await fetch(request);
    if (response && response.status === 200) {
      const clonedResponse = response.clone();
      cache.put(request, clonedResponse);
      
      if (maxSize) {
        limitCacheSize(cacheName, maxSize);
      }
    }
    return response;
  } catch (error) {
    const cached = await cache.match(request);
    return cached || new Response('Offline - no cached version available', {
      status: 503,
      statusText: 'Service Unavailable'
    });
  }
}

/**
 * STALE-WHILE-REVALIDATE STRATEGY
 * Return cached version immediately, update cache in background
 * Best for: HTML pages - fast load, always updating
 */
async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  
  const fetchPromise = fetch(request).then((response) => {
    if (response && response.status === 200) {
      cache.put(request, response.clone());
    }
    return response;
  });
  
  return cached || fetchPromise;
}

// =============================================================================
// UTILITY FUNCTIONS
// =============================================================================

function isStaticAsset(pathname) {
  return pathname.match(/\.(js|css|woff2?|ttf|otf)$/);
}

function isImage(pathname) {
  return pathname.match(/\.(jpg|jpeg|png|gif|webp|svg|ico)$/);
}

function isHTMLPage(request) {
  return request.headers.get('Accept').includes('text/html');
}

async function limitCacheSize(cacheName, maxSize) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  
  if (keys.length > maxSize) {
    // Delete oldest entries (FIFO)
    const deleteCount = keys.length - maxSize;
    for (let i = 0; i < deleteCount; i++) {
      await cache.delete(keys[i]);
    }
  }
}

// =============================================================================
// BACKGROUND SYNC (Future Enhancement)
// =============================================================================

// self.addEventListener('sync', (event) => {
//   if (event.tag === 'sync-forms') {
//     event.waitUntil(syncForms());
//   }
// });

// =============================================================================
// PUSH NOTIFICATIONS (Future Enhancement)
// =============================================================================

// self.addEventListener('push', (event) => {
//   const data = event.data.json();
//   const options = {
//     body: data.body,
//     icon: '/icon-192.png',
//     badge: '/icon-96.png',
//   };
//   event.waitUntil(
//     self.registration.showNotification(data.title, options)
//   );
// });

