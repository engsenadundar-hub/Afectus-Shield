// TypeScript type definitions for i18next
// This provides autocomplete for translation keys

import 'react-i18next';
import type translationTR from './locales/tr.json';

declare module 'react-i18next' {
  interface CustomTypeOptions {
    defaultNS: 'translation';
    resources: {
      translation: typeof translationTR;
    };
  }
}

// Export translation key types
export type TranslationKeys = keyof typeof translationTR;

// Utility type for nested keys
export type NestedKeyOf<ObjectType extends object> = {
  [Key in keyof ObjectType & (string | number)]: ObjectType[Key] extends object
    ? `${Key}` | `${Key}.${NestedKeyOf<ObjectType[Key]>}`
    : `${Key}`;
}[keyof ObjectType & (string | number)];

// Example usage:
// const key: NestedKeyOf<typeof translationTR> = 'header.nav.home';
