import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Translation resources
import translationTR from './locales/tr.json';
import translationEN from './locales/en.json';

const resources = {
  tr: {
    translation: translationTR,
  },
  en: {
    translation: translationEN,
  },
};

// Get initial language safely
function getInitialLanguage(): string {
  try {
    const stored = localStorage.getItem('afectus-language');
    if (stored === 'tr' || stored === 'en') {
      return stored;
    }
  } catch (error) {
    // localStorage might not be available
    
  }
  return 'tr';
}

// Initialize i18next
// Use synchronous init to avoid race conditions during HMR
i18n
  // Detect user language
  .use(LanguageDetector)
  // Pass the i18n instance to react-i18next
  .use(initReactI18next)
  // Initialize i18next
  .init({
    resources,
    fallbackLng: 'tr',
    lng: getInitialLanguage(), // Set initial language synchronously
    debug: false, // Set to true for development debugging
    
    // Language detection options
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'],
      lookupLocalStorage: 'afectus-language',
    },

    interpolation: {
      escapeValue: false, // React already escapes values
    },

    // Namespace configuration
    ns: ['translation'],
    defaultNS: 'translation',

    // React configuration
    react: {
      useSuspense: false, // Critical: prevents Suspense-related HMR issues
    },
    
    // Performance optimization
    initImmediate: false, // Initialize synchronously for HMR stability
  });

export default i18n;