import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import i18n from '../i18n/config';

type Language = 'tr' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (tr: string, en: string) => string; // Legacy support
  i18n: typeof i18n; // New i18next support
}

// Create context with a default value to prevent HMR issues
const defaultContextValue: LanguageContextType = {
  language: 'tr',
  setLanguage: () => {},
  t: (tr: string) => tr,
  i18n: i18n,
};

const LanguageContext = createContext<LanguageContextType>(defaultContextValue);

export function LanguageProvider({ children }: { children: ReactNode }) {
  // Don't call useTranslation here - it causes HMR issues!
  // Each component will call useTranslation directly via useI18n()
  
  const [language, setLanguage] = useState<Language>(() => {
    // Try to get from localStorage first (with safety check)
    try {
      const stored = localStorage.getItem('afectus-language');
      if (stored === 'tr' || stored === 'en') {
        return stored as Language;
      }
    } catch (error) {
      // localStorage might not be available (SSR, privacy mode, etc.)
      
    }
    
    // Default to Turkish for Turkish business
    return 'tr';
  });

  // Sync i18next language with state
  useEffect(() => {
    i18n.changeLanguage(language);
    try {
      localStorage.setItem('afectus-language', language);
    } catch (error) {
      
    }
    document.documentElement.lang = language;
    
    // Update meta tags for language
    const existingMeta = document.querySelector('meta[http-equiv="content-language"]');
    if (existingMeta) {
      existingMeta.setAttribute('content', language);
    } else {
      const meta = document.createElement('meta');
      meta.httpEquiv = 'content-language';
      meta.content = language;
      document.head.appendChild(meta);
    }
  }, [language]);

  // Legacy t() function for backward compatibility
  const legacyT = (tr: string, en: string) => {
    return language === 'tr' ? tr : en;
  };

  const value: LanguageContextType = {
    language,
    setLanguage,
    t: legacyT,
    i18n: i18n,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  // No need to check - we have a default value now
  return context;
}

// New hook for direct i18next usage
export function useI18n() {
  const context = useContext(LanguageContext);
  // No need to check - we have a default value now
  const { t } = useTranslation();
  return {
    t,
    language: context.language,
    changeLanguage: context.setLanguage,
    i18n: context.i18n,
  };
}