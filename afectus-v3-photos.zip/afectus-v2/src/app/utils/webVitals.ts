// Web Vitals Monitoring
// Tracks Core Web Vitals (CLS, LCP, FID, FCP, TTFB, INP)

export interface WebVitalsMetric {
  name: 'CLS' | 'FCP' | 'FID' | 'LCP' | 'TTFB' | 'INP';
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  delta: number;
  id: string;
  navigationType: string;
}

// Thresholds for Core Web Vitals (Google standards)
const THRESHOLDS = {
  CLS: { good: 0.1, poor: 0.25 },
  FCP: { good: 1800, poor: 3000 },
  FID: { good: 100, poor: 300 },
  LCP: { good: 2500, poor: 4000 },
  TTFB: { good: 800, poor: 1800 },
  INP: { good: 200, poor: 500 },
};

// Rating calculator
function getRating(name: WebVitalsMetric['name'], value: number): WebVitalsMetric['rating'] {
  const threshold = THRESHOLDS[name];
  if (value <= threshold.good) return 'good';
  if (value <= threshold.poor) return 'needs-improvement';
  return 'poor';
}

// Format value for display
function formatValue(name: WebVitalsMetric['name'], value: number): string {
  if (name === 'CLS') {
    return value.toFixed(3);
  }
  return `${Math.round(value)}ms`;
}

// Log metric to console (dev mode)
function logMetric(metric: WebVitalsMetric) {
  const emoji = {
    good: '✅',
    'needs-improvement': '⚠️',
    poor: '❌',
  }[metric.rating];

  console.log(
    `${emoji} ${metric.name}: ${formatValue(metric.name, metric.value)} (${metric.rating})`,
    metric
  );
}

// Send metric to analytics
function sendToAnalytics(metric: WebVitalsMetric) {
  // Safety check: Only send if window is available
  if (typeof window === 'undefined') return;

  // Send to Google Analytics (only if gtag is loaded)
  try {
    if ((window as any).gtag) {
      (window as any).gtag('event', metric.name, {
        event_category: 'Web Vitals',
        event_label: metric.id,
        value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
        metric_rating: metric.rating,
        non_interaction: true,
      });
    }
  } catch (error) {
    // Silently fail - analytics is optional
  }

  // Send to Plausible (only if plausible is loaded)
  try {
    if ((window as any).plausible) {
      (window as any).plausible('Web Vital', {
        props: {
          metric: metric.name,
          value: Math.round(metric.value),
          rating: metric.rating,
        },
      });
    }
  } catch (error) {
    // Silently fail - analytics is optional
  }

  // Send to custom endpoint (if you have one)
  // fetch('/api/web-vitals', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify(metric),
  // });
}

// Main reporting function
export function reportWebVitals(onPerfEntry?: (metric: WebVitalsMetric) => void) {
  if (typeof window === 'undefined') return;

  // Import web-vitals library (you need to install it: npm install web-vitals)
  // For now, we'll use the native Performance API as fallback

  try {
    // Try to use web-vitals library if available
    import('web-vitals').then(({ onCLS, onFCP, onFID, onLCP, onTTFB, onINP }) => {
      const handleMetric = (metric: any) => {
        const webVitalsMetric: WebVitalsMetric = {
          name: metric.name,
          value: metric.value,
          rating: getRating(metric.name, metric.value),
          delta: metric.delta,
          id: metric.id,
          navigationType: metric.navigationType || 'navigate',
        };

        // Log to console (dev mode)
        if (process.env.NODE_ENV === 'development') {
          logMetric(webVitalsMetric);
        }

        // Send to analytics
        sendToAnalytics(webVitalsMetric);

        // Custom callback
        if (onPerfEntry) {
          onPerfEntry(webVitalsMetric);
        }
      };

      onCLS(handleMetric);
      onFCP(handleMetric);
      onFID(handleMetric);
      onLCP(handleMetric);
      onTTFB(handleMetric);
      onINP(handleMetric);
    }).catch(() => {
      // Fallback: Use Performance Observer API
      console.log('web-vitals library not available, using Performance API fallback');
      measureWithPerformanceAPI(onPerfEntry);
    });
  } catch (error) {
    console.error('Error initializing Web Vitals:', error);
  }
}

// Fallback: Measure with Performance API
function measureWithPerformanceAPI(onPerfEntry?: (metric: WebVitalsMetric) => void) {
  if (!('PerformanceObserver' in window)) return;

  // Measure LCP
  try {
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1] as any;
      
      const metric: WebVitalsMetric = {
        name: 'LCP',
        value: lastEntry.renderTime || lastEntry.loadTime,
        rating: getRating('LCP', lastEntry.renderTime || lastEntry.loadTime),
        delta: lastEntry.renderTime || lastEntry.loadTime,
        id: `lcp-${Date.now()}`,
        navigationType: 'navigate',
      };

      if (process.env.NODE_ENV === 'development') {
        logMetric(metric);
      }
      sendToAnalytics(metric);
      if (onPerfEntry) onPerfEntry(metric);
    });

    lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });
  } catch (e) {
    console.error('LCP measurement failed:', e);
  }

  // Measure FCP
  try {
    const fcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        if (entry.name === 'first-contentful-paint') {
          const metric: WebVitalsMetric = {
            name: 'FCP',
            value: entry.startTime,
            rating: getRating('FCP', entry.startTime),
            delta: entry.startTime,
            id: `fcp-${Date.now()}`,
            navigationType: 'navigate',
          };

          if (process.env.NODE_ENV === 'development') {
            logMetric(metric);
          }
          sendToAnalytics(metric);
          if (onPerfEntry) onPerfEntry(metric);
        }
      });
    });

    fcpObserver.observe({ type: 'paint', buffered: true });
  } catch (e) {
    console.error('FCP measurement failed:', e);
  }

  // Measure CLS
  try {
    let clsValue = 0;
    const clsObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries() as any[];
      entries.forEach((entry) => {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
        }
      });

      const metric: WebVitalsMetric = {
        name: 'CLS',
        value: clsValue,
        rating: getRating('CLS', clsValue),
        delta: clsValue,
        id: `cls-${Date.now()}`,
        navigationType: 'navigate',
      };

      if (process.env.NODE_ENV === 'development') {
        logMetric(metric);
      }
      sendToAnalytics(metric);
      if (onPerfEntry) onPerfEntry(metric);
    });

    clsObserver.observe({ type: 'layout-shift', buffered: true });
  } catch (e) {
    console.error('CLS measurement failed:', e);
  }
}

// Display Web Vitals badge (dev mode only)
export function showWebVitalsBadge() {
  if (process.env.NODE_ENV !== 'development' || typeof window === 'undefined') return;

  const badge = document.createElement('div');
  badge.id = 'web-vitals-badge';
  badge.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #0A0E1A;
    border: 2px solid #E63946;
    color: white;
    padding: 12px 16px;
    border-radius: 8px;
    font-family: monospace;
    font-size: 12px;
    z-index: 999999;
    max-width: 300px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5);
  `;

  badge.innerHTML = `
    <div style="font-weight: bold; margin-bottom: 8px; color: #E63946;">Web Vitals Monitor</div>
    <div id="web-vitals-content" style="line-height: 1.6;">Loading...</div>
  `;

  document.body.appendChild(badge);

  const content = document.getElementById('web-vitals-content');

  reportWebVitals((metric) => {
    if (!content) return;

    const emoji = {
      good: '✅',
      'needs-improvement': '⚠️',
      poor: '❌',
    }[metric.rating];

    const existingMetric = content.querySelector(`[data-metric="${metric.name}"]`);
    const metricHtml = `<div data-metric="${metric.name}">${emoji} ${metric.name}: ${formatValue(metric.name, metric.value)}</div>`;

    if (existingMetric) {
      existingMetric.outerHTML = metricHtml;
    } else {
      content.innerHTML += metricHtml;
    }
  });
}

// Export default
export default {
  reportWebVitals,
  showWebVitalsBadge,
};