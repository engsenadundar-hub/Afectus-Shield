// Analytics Tracking Utilities
// TODO: Add your Google Analytics / Plausible Analytics tracking ID

interface AnalyticsEvent {
  category: string;
  action: string;
  label?: string;
  value?: number;
}

// Google Analytics (GA4)
export const initGA = (trackingId: string) => {
  if (typeof window === 'undefined') return;

  // Add Google Analytics script
  const script1 = document.createElement('script');
  script1.async = true;
  script1.src = `https://www.googletagmanager.com/gtag/js?id=${trackingId}`;
  document.head.appendChild(script1);

  const script2 = document.createElement('script');
  script2.innerHTML = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${trackingId}', {
      page_path: window.location.pathname,
    });
  `;
  document.head.appendChild(script2);
};

// Track page views
export const trackPageView = (url: string) => {
  if (typeof window === 'undefined') return;
  
  try {
    if ((window as any).gtag) {
      (window as any).gtag('config', 'GA_MEASUREMENT_ID', {
        page_path: url,
      });
    }
  } catch (error) {
    // Silently fail - analytics is optional
    console.debug('Failed to track page view:', error);
  }
};

// Track custom events
export const trackEvent = ({ category, action, label, value }: AnalyticsEvent) => {
  if (typeof window === 'undefined') return;
  
  try {
    if ((window as any).gtag) {
      (window as any).gtag('event', action, {
        event_category: category,
        event_label: label,
        value: value,
      });
    }
  } catch (error) {
    // Silently fail - analytics is optional
    console.debug('Failed to track event:', error);
  }
};

// Plausible Analytics (Privacy-friendly alternative)
export const initPlausible = (domain: string) => {
  if (typeof window === 'undefined') return;

  const script = document.createElement('script');
  script.defer = true;
  script.setAttribute('data-domain', domain);
  script.src = 'https://plausible.io/js/script.js';
  document.head.appendChild(script);
};

// Track custom events (Plausible)
export const trackPlausibleEvent = (eventName: string, props?: Record<string, any>) => {
  if (typeof window === 'undefined') return;
  
  try {
    if ((window as any).plausible) {
      (window as any).plausible(eventName, { props });
    }
  } catch (error) {
    // Silently fail - analytics is optional
    console.debug('Failed to track Plausible event:', error);
  }
};

// Common event trackers
export const analytics = {
  // Contact form submission
  trackContactFormSubmit: () => {
    trackEvent({
      category: 'Form',
      action: 'Submit',
      label: 'Contact Form',
    });
    trackPlausibleEvent('Contact Form Submit');
  },

  // CTA button clicks
  trackCTAClick: (label: string) => {
    trackEvent({
      category: 'CTA',
      action: 'Click',
      label,
    });
    trackPlausibleEvent('CTA Click', { button: label });
  },

  // Phone call tracking
  trackPhoneClick: () => {
    trackEvent({
      category: 'Contact',
      action: 'Phone Click',
      label: 'Header Phone',
    });
    trackPlausibleEvent('Phone Click');
  },

  // WhatsApp click tracking
  trackWhatsAppClick: () => {
    trackEvent({
      category: 'Contact',
      action: 'WhatsApp Click',
      label: 'WhatsApp Button',
    });
    trackPlausibleEvent('WhatsApp Click');
  },

  // Email click tracking
  trackEmailClick: () => {
    trackEvent({
      category: 'Contact',
      action: 'Email Click',
      label: 'Header Email',
    });
    trackPlausibleEvent('Email Click');
  },

  // Service page views
  trackServiceView: (serviceName: string) => {
    trackEvent({
      category: 'Service',
      action: 'View',
      label: serviceName,
    });
    trackPlausibleEvent('Service View', { service: serviceName });
  },

  // PDF/Document downloads
  trackDocumentDownload: (documentName: string) => {
    trackEvent({
      category: 'Download',
      action: 'Document',
      label: documentName,
    });
    trackPlausibleEvent('Document Download', { document: documentName });
  },

  // Language switch
  trackLanguageSwitch: (from: string, to: string) => {
    trackEvent({
      category: 'Language',
      action: 'Switch',
      label: `${from} to ${to}`,
    });
    trackPlausibleEvent('Language Switch', { from, to });
  },
};

// TODO: Initialize analytics in your main App component
// Example usage:
/*
import { useEffect } from 'react';
import { useLocation } from 'react-router';
import { initGA, initPlausible, trackPageView } from './utils/analytics';

function App() {
  const location = useLocation();

  useEffect(() => {
    // Initialize analytics (do this once on app mount)
    // Option 1: Google Analytics
    initGA('YOUR_GA_MEASUREMENT_ID'); // e.g., 'G-XXXXXXXXXX'
    
    // Option 2: Plausible (privacy-friendly alternative)
    initPlausible('afectusshield.com');
  }, []);

  useEffect(() => {
    // Track page views on route change
    trackPageView(location.pathname + location.search);
  }, [location]);

  return <YourApp />;
}
*/

export default analytics;