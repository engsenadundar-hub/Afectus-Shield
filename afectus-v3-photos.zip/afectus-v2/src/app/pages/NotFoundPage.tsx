import { useLanguage } from '../contexts/LanguageContext';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { AlertTriangle, Home, ArrowLeft, Search, BookOpen, Wrench } from 'lucide-react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { SEO } from '../components/SEO';

export function NotFoundPage() {
  const { t } = useLanguage();

  const quickLinks = [
    {
      icon: Home,
      titleTr: 'Ana Sayfa',
      titleEn: 'Homepage',
      path: '/',
    },
    {
      icon: Wrench,
      titleTr: 'Hizmetlerimiz',
      titleEn: 'Our Services',
      path: '/hizmetler',
    },
    {
      icon: BookOpen,
      titleTr: 'Hakkımızda',
      titleEn: 'About Us',
      path: '/hakkimizda',
    },
    {
      icon: Search,
      titleTr: 'İletişim',
      titleEn: 'Contact',
      path: '/iletisim',
    },
  ];

  return (
    <>
      <SEO
        titleTr="404 - Sayfa Bulunamadı | Afectus Shield İzmir"
        titleEn="404 - Page Not Found | Afectus Shield Izmir"
        descriptionTr="Aradığınız sayfa bulunamadı. İzmir yıldırım koruma sistemleri ve paratoner hizmetleri için ana sayfamıza dönebilirsiniz."
        descriptionEn="The page you are looking for was not found. You can return to our homepage for Izmir lightning protection systems and services."
      />
      <div className="min-h-screen bg-[#0A0E1A] flex flex-col" style={{ position: 'relative' }}>
        <Header />
        
        <main className="flex-1 flex items-center justify-center px-6 py-24 pt-[120px] md:pt-[144px]">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
            >
              {/* Error Icon */}
              <div className="inline-flex items-center justify-center w-32 h-32 border-4 border-[#E63946] mb-8">
                <AlertTriangle className="w-16 h-16 text-[#E63946]" strokeWidth={2} />
              </div>

              {/* 404 Text */}
              <h1 className="text-8xl font-bold text-[#E63946] mb-4">404</h1>
              
              <h2 className="text-3xl font-bold text-[#E8EAED] mb-6 uppercase tracking-wide">
                {t('Sayfa Bulunamadı', 'Page Not Found')}
              </h2>
              
              <p className="text-xl text-[#B8BCC4] mb-12 leading-relaxed max-w-2xl mx-auto">
                {t(
                  'Aradığınız sayfa mevcut değil veya taşınmış olabilir. Aşağıdaki hızlı bağlantıları kullanarak istediğiniz içeriğe ulaşabilirsiniz.',
                  'The page you are looking for does not exist or may have been moved. You can reach the content you want using the quick links below.'
                )}
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                <Link
                  to="/"
                  className="inline-flex items-center justify-center gap-3 bg-[#E63946] text-white px-8 py-4 font-semibold uppercase tracking-wide transition-all duration-200 hover:bg-[#B91C2C] hover:-translate-y-1"
                >
                  <Home className="w-5 h-5" strokeWidth={2.5} />
                  {t('Ana Sayfaya Dön', 'Back to Homepage')}
                </Link>
                
                <button
                  onClick={() => window.history.back()}
                  className="inline-flex items-center justify-center gap-3 border-2 border-[#334155] text-[#E8EAED] px-8 py-4 font-semibold uppercase tracking-wide transition-all duration-200 hover:border-[#E63946] hover:text-[#E63946] hover:-translate-y-1"
                >
                  <ArrowLeft className="w-5 h-5" strokeWidth={2.5} />
                  {t('Geri Dön', 'Go Back')}
                </button>
              </div>

              {/* Quick Links Grid */}
              <div className="border-t border-[#334155] pt-12">
                <h3 className="text-sm font-bold text-[#71757E] uppercase tracking-wider mb-6">
                  {t('HIZLI ERİŞİM', 'QUICK ACCESS')}
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {quickLinks.map((link, index) => (
                    <Link
                      key={index}
                      to={link.path}
                      className="group p-6 border border-[#334155] hover:border-[#E63946] transition-all duration-300"
                    >
                      <link.icon className="w-8 h-8 text-[#71757E] group-hover:text-[#E63946] mx-auto mb-3 transition-colors" strokeWidth={2} />
                      <p className="text-sm font-semibold text-[#B8BCC4] group-hover:text-[#E8EAED] uppercase tracking-wide transition-colors">
                        {t(link.titleTr, link.titleEn)}
                      </p>
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}