import { Link } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { SEO } from '../components/SEO';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { ArrowLeft } from 'lucide-react';

export function ConsentFormPage() {
  const { t } = useLanguage();

  return (
    <>
      <SEO />
      <div className="min-h-screen bg-[#0f0f12]" style={{ position: 'relative' }}>
        <Header />
        
        <main className="py-24 px-6">
          <div className="max-w-4xl mx-auto">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-[#a1a1aa] hover:text-[#dc2626] transition-colors duration-200 mb-8"
            >
              <ArrowLeft className="w-4 h-4" strokeWidth={2.5} />
              <span className="text-sm font-medium uppercase tracking-wider">
                {t('Ana Sayfaya Dön', 'Back to Home')}
              </span>
            </Link>

            <div className="mb-12">
              <div className="w-16 h-1 bg-[#dc2626] mb-6"></div>
              <h1 className="text-4xl md:text-5xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                {t('AÇIK RIZA BEYANI', 'EXPLICIT CONSENT FORM')}
              </h1>
            </div>

            <div className="prose prose-invert max-w-none">
              <div className="bg-[#1a1a1f] border border-[#2a2a32] p-8 space-y-6">
                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('Kişisel Verilerin İşlenmesine İlişkin Açık Rıza Beyanı', 'Explicit Consent for Processing of Personal Data')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      '6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, Liksus Elektrik Güç Sistemleri Ltd. Şti. (Afectus Shield) tarafından kişisel verilerimin işlenmesine ilişkin olarak aşağıdaki hususlarda bilgilendirildim:',
                      'In accordance with the Personal Data Protection Law No. 6698 ("KVKK"), I have been informed by Liksus Electric Power Systems Ltd. (Afectus Shield) regarding the processing of my personal data as follows:'
                    )}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('1. İşlenecek Kişisel Veriler', '1. Personal Data to be Processed')}
                  </h2>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Kimlik bilgilerim (ad, soyad)', 'My identity information (name, surname)')}</li>
                    <li>{t('İletişim bilgilerim (telefon, e-posta, adres)', 'My contact information (phone, email, address)')}</li>
                    <li>{t('Şirket bilgilerim (firma adı, unvan, vergi bilgileri)', 'My company information (company name, title, tax information)')}</li>
                    <li>{t('Proje ve tesis bilgileri', 'Project and facility information')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('2. İşlenme Amaçları', '2. Processing Purposes')}
                  </h2>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Yıldırımdan korunma sistemleri hizmetlerinin sunulması', 'Providing lightning protection system services')}</li>
                    <li>{t('Teklif hazırlama ve sözleşme yönetimi', 'Preparing proposals and contract management')}</li>
                    <li>{t('Proje tasarımı ve uygulaması', 'Project design and implementation')}</li>
                    <li>{t('Teknik destek ve danışmanlık hizmetleri', 'Technical support and consultancy services')}</li>
                    <li>{t('Yasal yükümlülüklerin yerine getirilmesi', 'Fulfillment of legal obligations')}</li>
                    <li>{t('EMO onay süreçleri ve sigorta dokümantasyonu', 'EMO approval processes and insurance documentation')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('3. Kişisel Verilerin Aktarımı', '3. Transfer of Personal Data')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t(
                      'Kişisel verilerimin aşağıdaki taraflara aktarılabileceğini biliyorum:',
                      'I am aware that my personal data may be transferred to the following parties:'
                    )}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Elektrik Mühendisleri Odası (EMO)', 'Chamber of Electrical Engineers (EMO)')}</li>
                    <li>{t('Sigorta şirketleri', 'Insurance companies')}</li>
                    <li>{t('Yasal merciler ve düzenleyici kurumlar', 'Legal authorities and regulatory bodies')}</li>
                    <li>{t('İş ortakları ve tedarikçiler (proje bazlı)', 'Business partners and suppliers (project-based)')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('4. Haklarım', '4. My Rights')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t(
                      'KVKK kapsamında aşağıdaki haklara sahip olduğumu biliyorum:',
                      'I am aware that I have the following rights under the KVKK:'
                    )}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Kişisel verilerimin işlenip işlenmediğini öğrenme', 'Learning whether my personal data is processed')}</li>
                    <li>{t('İşlenme amacını ve uygunluğunu sorgulama', 'Questioning the purpose and appropriateness of processing')}</li>
                    <li>{t('Düzeltme, silme veya yok etme talep etme', 'Requesting correction, deletion or destruction')}</li>
                    <li>{t('İtiraz etme ve zarar giderim talep etme', 'Objecting and requesting compensation for damages')}</li>
                  </ul>
                </section>

                <section className="bg-[#2a2a32] p-6 border-l-4 border-[#dc2626]">
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('BEYANIM', 'MY DECLARATION')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      'Yukarıda belirtilen hususlar doğrultusunda, kişisel verilerimin Liksus Elektrik Güç Sistemleri Ltd. Şti. (Afectus Shield) tarafından işlenmesine, saklanmasına ve aktarılmasına açık rızam ile onay veriyorum.',
                      'In accordance with the matters stated above, I give my explicit consent to the processing, storage and transfer of my personal data by Liksus Electric Power Systems Ltd. (Afectus Shield).'
                    )}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('İletişim', 'Contact')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      'Rıza beyanınızı geri çekmek veya haklarınızı kullanmak için: info@afectusshield.com',
                      'To withdraw your consent or exercise your rights: info@afectusshield.com'
                    )}
                  </p>
                </section>
              </div>
            </div>

            <p className="text-[#71717a] text-xs mt-8 text-center">
              {t('Son Güncelleme: Şubat 2026', 'Last Updated: February 2026')}
            </p>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}