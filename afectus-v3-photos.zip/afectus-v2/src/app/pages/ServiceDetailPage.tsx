import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { useParams, Link } from 'react-router';
import { Header } from '../components/Header';
import { QuoteForm } from '../components/QuoteForm';
import { Footer } from '../components/Footer';
import { SEO } from '../components/SEO';
import { FileSearch, PenTool, Wrench, ClipboardCheck, ShieldAlert, CheckCircle2, ArrowRight, ArrowLeft } from 'lucide-react';

export function ServiceDetailPage() {
  const { t } = useLanguage();
  const { slug } = useParams();

  const services: Record<string, any> = {
    'risk-analizi': {
      icon: FileSearch,
      titleTr: 'Risk Analizi',
      titleEn: 'Risk Analysis',
      descTr: 'IEC 62305 standardına göre kapsamlı risk değerlendirmesi ve raporlama hizmeti.',
      descEn: 'Comprehensive risk assessment and reporting service according to IEC 62305 standard.',
      image: 'https://images.unsplash.com/photo-1581093196277-8b9e9c5e0e5a?w=1200&q=85&auto=format&fit=crop',
      features: [
        { tr: 'Tesis bazlı detaylı risk analizi', en: 'Detailed facility-based risk analysis' },
        { tr: 'IEC 62305-2 standardına tam uyum', en: 'Full compliance with IEC 62305-2 standard' },
        { tr: 'R1-R4 risk seviyesi hesaplaması', en: 'R1-R4 risk level calculation' },
        { tr: 'Koruma gereksinimi belirleme', en: 'Protection requirement determination' },
        { tr: 'Maliyet-fayda analizi', en: 'Cost-benefit analysis' },
        { tr: 'Detaylı teknik raporlama', en: 'Detailed technical reporting' },
      ],
      process: [
        { tr: 'Tesis bilgilerinin toplanması', en: 'Collection of facility information' },
        { tr: 'Çevresel faktörlerin analizi', en: 'Analysis of environmental factors' },
        { tr: 'Risk parametrelerinin hesaplanması', en: 'Calculation of risk parameters' },
        { tr: 'Koruma önlemlerinin belirlenmesi', en: 'Determination of protection measures' },
        { tr: 'Raporlama ve sunum', en: 'Reporting and presentation' },
      ],
    },
    'muhendislik-tasarimi': {
      icon: PenTool,
      titleTr: 'Mühendislik Tasarımı',
      titleEn: 'Engineering Design',
      descTr: 'Tesise özel yıldırımdan korunma sistemi mühendislik projeleri ve çözümleri.',
      descEn: 'Facility-specific lightning protection system engineering projects and solutions.',
      image: 'https://images.unsplash.com/photo-1453023795691-9b2b92a39c9e?w=1200&q=85&auto=format&fit=crop',
      features: [
        { tr: 'LPS Tip I-IV sistem tasarımı', en: 'LPS Type I-IV system design' },
        { tr: 'SPM ve SPD entegrasyonu', en: 'SPM and SPD integration' },
        { tr: '3D modelleme ve simülasyon', en: '3D modeling and simulation' },
        { tr: 'Malzeme listesi ve spesifikasyonlar', en: 'Bill of materials and specifications' },
        { tr: 'Uygulama detayları ve çizimler', en: 'Implementation details and drawings' },
        { tr: 'EMO onay süreçleri', en: 'EMO approval processes' },
      ],
      process: [
        { tr: 'Ön keşif ve ölçüm', en: 'Preliminary survey and measurement' },
        { tr: 'Sistem tipinin belirlenmesi', en: 'Determination of system type' },
        { tr: 'Tasarım hesaplamaları', en: 'Design calculations' },
        { tr: 'Proje çizimlerinin hazırlanması', en: 'Preparation of project drawings' },
        { tr: 'Onay ve teslim', en: 'Approval and delivery' },
      ],
    },
    'uygulama-montaj': {
      icon: Wrench,
      titleTr: 'Uygulama ve Montaj',
      titleEn: 'Implementation & Installation',
      descTr: 'Sertifikalı ekip ile profesyonel sistem kurulumu ve entegrasyon hizmeti.',
      descEn: 'Professional system setup and integration service with certified team.',
      image: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=1200&q=85&auto=format&fit=crop',
      features: [
        { tr: 'Deneyimli sertifikalı montaj ekibi', en: 'Experienced certified installation team' },
        { tr: 'Kaliteli orijinal malzeme kullanımı', en: 'Use of quality original materials' },
        { tr: 'İş güvenliği standartlarına uyum', en: 'Compliance with occupational safety standards' },
        { tr: 'Minimal operasyonel kesinti', en: 'Minimal operational disruption' },
        { tr: 'Projeye uygun uygulama', en: 'Implementation according to project' },
        { tr: 'Anahtar teslim çözüm', en: 'Turnkey solution' },
      ],
      process: [
        { tr: 'İş programının oluşturulması', en: 'Creation of work schedule' },
        { tr: 'Malzeme temini ve kontrolü', en: 'Material procurement and inspection' },
        { tr: 'Montaj çalışmalarının yürütülmesi', en: 'Execution of installation work' },
        { tr: 'Kalite kontrol testleri', en: 'Quality control tests' },
        { tr: 'Teslim ve dokümantasyon', en: 'Delivery and documentation' },
      ],
    },
    'test-raporlama': {
      icon: ClipboardCheck,
      titleTr: 'Test ve Raporlama',
      titleEn: 'Testing & Reporting',
      descTr: 'Akrediteli laboratuvar ölçümleri ve belgelendirme süreçleri hizmeti.',
      descEn: 'Accredited laboratory measurements and certification processes service.',
      image: 'https://images.unsplash.com/photo-1581093450021-4a7360e9c6e3?w=1200&q=85&auto=format&fit=crop',
      features: [
        { tr: 'Topraklama direnci ölçümü', en: 'Grounding resistance measurement' },
        { tr: 'Süreklilik testleri', en: 'Continuity tests' },
        { tr: 'İletkenlik kontrolleri', en: 'Conductivity checks' },
        { tr: 'SPD fonksiyon testleri', en: 'SPD function tests' },
        { tr: 'Resmi test raporları', en: 'Official test reports' },
        { tr: 'EMO belgelendirmesi', en: 'EMO certification' },
      ],
      process: [
        { tr: 'Test programının hazırlanması', en: 'Preparation of test program' },
        { tr: 'Akrediteli ölçüm cihazları ile test', en: 'Testing with accredited measuring devices' },
        { tr: 'Veri analizi ve değerlendirme', en: 'Data analysis and evaluation' },
        { tr: 'Test raporlarının hazırlanması', en: 'Preparation of test reports' },
        { tr: 'Belgelendirme ve teslim', en: 'Certification and delivery' },
      ],
    },
    'periyodik-bakim': {
      icon: ShieldAlert,
      titleTr: 'Periyodik Bakım',
      titleEn: 'Periodic Maintenance',
      descTr: 'Yıllık kontrol, ölçüm ve sistem güncelleme hizmetleri.',
      descEn: 'Annual inspection, measurement and system update services.',
      image: 'https://images.unsplash.com/photo-1565814636199-ae8133055c1c?w=1200&q=85&auto=format&fit=crop',
      features: [
        { tr: 'Yıllık bakım kontratları', en: 'Annual maintenance contracts' },
        { tr: 'Periyodik sistem denetimleri', en: 'Periodic system inspections' },
        { tr: 'Performans ölçümleri', en: 'Performance measurements' },
        { tr: 'Aşınma ve hasar kontrolü', en: 'Wear and damage inspection' },
        { tr: 'Gerekli onarımlar ve değişimler', en: 'Necessary repairs and replacements' },
        { tr: '7/24 acil destek hattı', en: '24/7 emergency support line' },
      ],
      process: [
        { tr: 'Bakım planının oluşturulması', en: 'Creation of maintenance plan' },
        { tr: 'Periyodik ziyaret ve inceleme', en: 'Periodic visit and inspection' },
        { tr: 'Test ve ölçüm çalışmaları', en: 'Testing and measurement work' },
        { tr: 'Bakım raporu hazırlama', en: 'Maintenance report preparation' },
        { tr: 'Gerekli müdahaleler', en: 'Necessary interventions' },
      ],
    },
  };

  const service = slug ? services[slug] : null;

  if (!service) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-accent mb-4">
            {t('Hizmet Bulunamadı', 'Service Not Found')}
          </h1>
          <Link to="/hizmetler" className="text-foreground hover:text-accent">
            {t('Hizmetlere Dön', 'Back to Services')}
          </Link>
        </div>
      </div>
    );
  }

  const ServiceIcon = service.icon;

  return (
    <>
      <SEO 
        title={`${t(service.titleTr, service.titleEn)} - Afectus Shield`}
        description={t(service.descTr, service.descEn)}
      />
      <div className="min-h-screen bg-background" style={{ position: 'relative' }}>
        <Header />
        
        {/* Hero Section */}
        <section className="relative pt-32 pb-24 border-b border-border overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src={service.image}
              alt={t(service.titleTr, service.titleEn)}
              width={800}
                  height={500}
                  loading="lazy"
                  className="w-full h-full object-cover opacity-10"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/95 to-background"></div>
          </div>

          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Link 
                to="/hizmetler"
                className="inline-flex items-center gap-2 text-muted-foreground hover:text-accent transition-colors mb-8"
              >
                <ArrowLeft className="w-4 h-4" strokeWidth={2.5} />
                {t('Tüm Hizmetler', 'All Services')}
              </Link>

              <div className="w-20 h-20 flex items-center justify-center border-2 border-accent mb-8">
                <ServiceIcon className="w-10 h-10 text-accent" strokeWidth={2.5} />
              </div>
              
              <h1 className="text-foreground mb-6">
                {t(service.titleTr, service.titleEn)}
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl">
                {t(service.descTr, service.descEn)}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="relative py-24 bg-card border-b border-border">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="mb-12"
            >
              <h2 className="text-3xl font-bold text-foreground mb-4 uppercase tracking-wide">
                {t('Hizmet Özellikleri', 'Service Features')}
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
              {service.features.map((feature: any, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-4 border border-border bg-background p-6 hover:border-accent transition-all duration-300"
                >
                  <CheckCircle2 className="w-6 h-6 text-accent flex-shrink-0 mt-1" strokeWidth={2} />
                  <span className="text-foreground text-lg">
                    {t(feature.tr, feature.en)}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="relative py-24 bg-background">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="mb-12"
            >
              <h2 className="text-3xl font-bold text-foreground mb-4 uppercase tracking-wide">
                {t('Hizmet Süreci', 'Service Process')}
              </h2>
              <p className="text-muted-foreground text-lg">
                {t(
                  'Adım adım profesyonel hizmet sürecimiz.',
                  'Our step-by-step professional service process.'
                )}
              </p>
            </motion.div>

            <div className="space-y-6">
              {service.process.map((step: any, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-6"
                >
                  <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center border-2 border-accent bg-card text-2xl font-bold text-accent">
                    {index + 1}
                  </div>
                  <div className="flex-1 border border-border bg-card p-6">
                    <p className="text-foreground text-lg">
                      {t(step.tr, step.en)}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-card border-t border-border">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <h2 className="text-3xl font-bold text-foreground mb-6">
              {t('Projeniz İçin Teklif Alın', 'Get a Quote for Your Project')}
            </h2>
            <Link
              to="/iletisim"
              className="inline-flex items-center gap-3 bg-accent text-white px-8 py-4 font-semibold uppercase tracking-wide transition-all duration-200 hover:bg-[#B91C2C] hover:-translate-y-1"
            >
              {t('İletişime Geçin', 'Contact Us')}
              <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
            </Link>
          </div>
        </section>

        <QuoteForm serviceTr={service?.titleTr} serviceEn={service?.titleEn} />
        <Footer />
      </div>
    </>
  );
}