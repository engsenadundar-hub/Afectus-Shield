import { useParams, Link } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { motion } from 'motion/react';
import { SEO } from '../components/SEO';
import { Zap, Cable, ShieldCheck, CheckCircle2, ArrowLeft, ArrowRight } from 'lucide-react';

export function SystemComponentPage() {
  const { t } = useLanguage();
  const { slug } = useParams();

  const components: Record<string, any> = {
    'dis-yildirimlik': {
      icon: Zap,
      titleTr: 'Dış Yıldırımlık Sistemi (LPS)',
      titleEn: 'External Lightning Protection System (LPS)',
      descTr: 'Hava sonlandırma elemanları, iletken sistemler ve topraklama elektrodu sistemi ile dış koruma çözümleri.',
      descEn: 'External protection solutions with air termination, down conductors and earth termination systems.',
      image: 'https://images.unsplash.com/photo-1602193438882-fedb6b7c72b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWdodG5pbmclMjByb2QlMjBidWlsZGluZyUyMHJvb2Z8ZW58MXx8fHwxNzcxNDg0NDEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
      components: [
        { tr: 'Yakalama çubukları (Franklin Rod)', en: 'Lightning rods (Franklin Rod)' },
        { tr: 'Kafes sistemleri (Faraday Cage)', en: 'Mesh systems (Faraday Cage)' },
        { tr: 'Germe telli sistemler', en: 'Catenary wire systems' },
        { tr: 'İniş iletkenleri', en: 'Down conductors' },
        { tr: 'Topraklama elektrodu sistemi', en: 'Earth termination system' },
        { tr: 'Bağlantı ve sabitleme elemanları', en: 'Connection and fastening elements' },
      ],
      features: [
        { tr: 'IEC 62305-3 standardına uygun tasarım', en: 'Design according to IEC 62305-3 standard' },
        { tr: 'Tip I-IV koruma seviyeleri', en: 'Type I-IV protection levels' },
        { tr: 'Dayanıklı paslanmaz malzemeler', en: 'Durable stainless materials' },
        { tr: 'Düşük bakım gereksinimi', en: 'Low maintenance requirement' },
        { tr: 'Uzun ömürlü performans', en: 'Long-lasting performance' },
      ],
      standards: [
        'IEC 62305-3: LPS Fiziksel Hasarlara Karşı Koruma',
        'IEC 62561: Yıldırım Koruma Sistem Bileşenleri',
        'TS EN 62305: Türk Standardı',
      ],
    },
    'ic-yildirimlik': {
      icon: Cable,
      titleTr: 'İç Yıldırımlık Sistemi (SPM)',
      titleEn: 'Internal Lightning Protection System (SPM)',
      descTr: 'Potansiyel dengeleme, güvenli mesafe hesaplamaları ve izolasyon koordinasyonu ile iç koruma çözümleri.',
      descEn: 'Internal protection solutions with equipotential bonding, separation distance and isolation coordination.',
      image: 'https://images.unsplash.com/photo-1646747149414-e0bd32b1a121?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpY2FsJTIwcGFuZWwlMjBjYWJpbmV0JTIwZGlzdHJpYnV0aW9ufGVufDF8fHx8MTc3MTQ4NDcwOXww&ixlib=rb-4.1.0&q=80&w=1080',
      components: [
        { tr: 'Eşpotansiyel bara sistemleri', en: 'Equipotential bonding bar systems' },
        { tr: 'Ana topraklama bara (MEB)', en: 'Main earthing bar (MEB)' },
        { tr: 'Bağlantı iletkenleri', en: 'Bonding conductors' },
        { tr: 'İzolasyon elemanları', en: 'Isolation elements' },
        { tr: 'Manyetik ekranlama', en: 'Magnetic shielding' },
        { tr: 'Hat yönlendirme sistemleri', en: 'Cable routing systems' },
      ],
      features: [
        { tr: 'IEC 62305-4 standardına uygun tasarım', en: 'Design according to IEC 62305-4 standard' },
        { tr: 'Elektriksel ve elektronik sistemlere koruma', en: 'Protection for electrical and electronic systems' },
        { tr: 'Potansiyel farkı minimizasyonu', en: 'Potential difference minimization' },
        { tr: 'LEMP (Lightning Electromagnetic Pulse) koruması', en: 'LEMP (Lightning Electromagnetic Pulse) protection' },
        { tr: 'Kritik altyapı güvenliği', en: 'Critical infrastructure security' },
      ],
      standards: [
        'IEC 62305-4: LPS Elektriksel ve Elektronik Sistemler',
        'IEC 61643: Düşük Gerilim Parafudrlar',
        'TS EN 62305: Türk Standardı',
      ],
    },
    'parafudr': {
      icon: ShieldCheck,
      titleTr: 'Parafudr Sistemleri (SPD)',
      titleEn: 'Surge Protection Devices (SPD)',
      descTr: 'Tip 1, Tip 2 ve Tip 3 parafudrlar ile güç hatları ve sinyal hatlarının korunması çözümleri.',
      descEn: 'Protection solutions for power and signal lines with Type 1, Type 2 and Type 3 surge arresters.',
      image: 'https://images.unsplash.com/photo-1593642532972-bd73c040e33a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJhZnVkcml8ZW58MXx8fHwxNzcxNDg0NDEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
      components: [
        { tr: 'Tip 1 SPD (Sınıf I Deneme)', en: 'Type 1 SPD (Class I Test)' },
        { tr: 'Tip 2 SPD (Sınıf II Deneme)', en: 'Type 2 SPD (Class II Test)' },
        { tr: 'Tip 3 SPD (Sınıf III Deneme)', en: 'Type 3 SPD (Class III Test)' },
        { tr: 'Kombine parafudrlar', en: 'Combined SPDs' },
        { tr: 'Veri hattı parafudrları', en: 'Data line SPDs' },
        { tr: 'Sinyal hattı parafudrları', en: 'Signal line SPDs' },
      ],
      features: [
        { tr: 'IEC 61643 standardına uygun', en: 'Compliant with IEC 61643 standard' },
        { tr: 'Yüksek boşalma kapasitesi', en: 'High discharge capacity' },
        { tr: 'Hızlı tepki süresi (<25ns)', en: 'Fast response time (<25ns)' },
        { tr: 'Görsel durum göstergesi', en: 'Visual status indicator' },
        { tr: 'Kolay montaj ve bakım', en: 'Easy installation and maintenance' },
      ],
      standards: [
        'IEC 61643-11: Düşük Gerilim AC Parafudrlar',
        'IEC 61643-21: Telekomünikasyon Parafudrları',
        'EN 61643-12: Düşük Gerilim DC Parafudrlar',
      ],
    },
  };

  const component = slug ? components[slug] : null;

  if (!component) {
    return (
      <div className="min-h-screen bg-[#0f0f12] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-[#dc2626] mb-4">
            {t('Sistem Bulunamadı', 'System Not Found')}
          </h1>
          <Link to="/" className="text-[#d4d4d8] hover:text-[#dc2626]">
            {t('Ana Sayfaya Dön', 'Back to Homepage')}
          </Link>
        </div>
      </div>
    );
  }

  const ComponentIcon = component.icon;

  return (
    <>
      <SEO 
        title={t(`${component.titleTr} - Afectus Shield`, `${component.titleEn} - Afectus Shield`)}
        description={t(component.descTr, component.descEn)}
      />
      <div className="min-h-screen bg-[#0f0f12]" style={{ position: 'relative' }}>
        <Header />
        
        {/* Hero Section */}
        <section className="relative pt-32 pb-24 border-b border-[#2a2a32] overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src={component.image}
              alt={t(component.titleTr, component.titleEn)}
              width={800}
                  height={500}
                  loading="lazy"
                  className="w-full h-full object-cover opacity-10"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#0f0f12]/90 via-[#0f0f12]/95 to-[#0f0f12]"></div>
          </div>

          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Link
                to="/#services"
                className="inline-flex items-center gap-2 text-[#a1a1aa] hover:text-[#dc2626] transition-colors mb-8"
              >
                <ArrowLeft className="w-5 h-5" strokeWidth={2} />
                {t('Sistem Bileşenleri', 'System Components')}
              </Link>

              <div className="w-20 h-20 flex items-center justify-center border-2 border-[#dc2626] mb-8">
                <ComponentIcon className="w-10 h-10 text-[#dc2626]" strokeWidth={2.5} />
              </div>

              <h1 className="text-[#d4d4d8] mb-6">
                {t(component.titleTr, component.titleEn)}
              </h1>
              <p className="text-2xl text-[#a1a1aa] max-w-3xl">
                {t(component.descTr, component.descEn)}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Components Section */}
        <section className="relative py-24 bg-[#1a1a1f] border-b border-[#2a2a32]">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl font-bold text-[#d4d4d8] mb-4 uppercase tracking-wide">
                {t('Sistem Bileşenleri', 'System Components')}
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {component.components.map((item: any, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="flex items-start gap-4 border border-[#2a2a32] bg-[#0f0f12] p-6 hover:border-[#dc2626] transition-all duration-300"
                >
                  <div className="w-2 h-2 bg-[#dc2626] flex-shrink-0 mt-2"></div>
                  <span className="text-[#d4d4d8]">{t(item.tr, item.en)}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="relative py-24">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl font-bold text-[#d4d4d8] mb-4 uppercase tracking-wide">
                {t('Teknik Özellikler', 'Technical Features')}
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {component.features.map((feature: any, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="flex items-start gap-4 border border-[#2a2a32] bg-[#1a1a1f] p-6 hover:border-[#dc2626] transition-all duration-300"
                >
                  <CheckCircle2 className="w-6 h-6 text-[#dc2626] flex-shrink-0 mt-1" strokeWidth={2} />
                  <span className="text-[#d4d4d8]">{t(feature.tr, feature.en)}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Standards Section */}
        <section className="py-24 bg-[#1a1a1f] border-t border-[#2a2a32]">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl font-bold text-[#d4d4d8] mb-4 uppercase tracking-wide">
                {t('İlgili Standartlar', 'Related Standards')}
              </h2>
            </motion.div>

            <div className="max-w-3xl mx-auto space-y-4">
              {component.standards.map((standard: string, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="border border-[#2a2a32] bg-[#0f0f12] p-6"
                >
                  <p className="text-[#d4d4d8]">{standard}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-[#0f0f12] border-t border-[#2a2a32]">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <h2 className="text-3xl font-bold text-[#d4d4d8] mb-6 uppercase tracking-wide">
              {t('Sistem Tasarımı İçin İletişime Geçin', 'Contact for System Design')}
            </h2>
            <Link
              to="/iletisim"
              className="inline-flex items-center gap-3 bg-[#dc2626] text-white px-8 py-4 font-semibold uppercase tracking-wide transition-all duration-200 hover:bg-[#b91c1c] hover:-translate-y-1"
            >
              {t('Teklif Alın', 'Get a Quote')}
              <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
            </Link>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}