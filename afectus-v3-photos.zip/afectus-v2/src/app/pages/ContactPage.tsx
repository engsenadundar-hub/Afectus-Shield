import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { SEO } from '../components/SEO';
import { MapPin, Phone, Mail, Clock, Send, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

export function ContactPage() {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    subject: '',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Validation functions
  const validateEmail = (email: string): boolean => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const validatePhone = (phone: string): boolean => {
    if (!phone) return true; // Optional field
    const re = /^[\d\s\-\+\(\)]{10,}$/;
    return re.test(phone);
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Name validation
    if (!formData.name.trim()) {
      newErrors.name = t('Ad Soyad gereklidir', 'Full Name is required');
    } else if (formData.name.trim().length < 3) {
      newErrors.name = t('Ad Soyad en az 3 karakter olmalıdır', 'Full Name must be at least 3 characters');
    }

    // Email validation
    if (!formData.email.trim()) {
      newErrors.email = t('E-posta gereklidir', 'Email is required');
    } else if (!validateEmail(formData.email)) {
      newErrors.email = t('Geçerli bir e-posta adresi giriniz', 'Please enter a valid email address');
    }

    // Phone validation (optional but must be valid if provided)
    if (formData.phone && !validatePhone(formData.phone)) {
      newErrors.phone = t('Geçerli bir telefon numarası giriniz', 'Please enter a valid phone number');
    }

    // Subject validation
    if (!formData.subject.trim()) {
      newErrors.subject = t('Konu gereklidir', 'Subject is required');
    } else if (formData.subject.trim().length < 5) {
      newErrors.subject = t('Konu en az 5 karakter olmalıdır', 'Subject must be at least 5 characters');
    }

    // Message validation
    if (!formData.message.trim()) {
      newErrors.message = t('Mesaj gereklidir', 'Message is required');
    } else if (formData.message.trim().length < 20) {
      newErrors.message = t('Mesaj en az 20 karakter olmalıdır', 'Message must be at least 20 characters');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      // Netlify Forms - encode form data
      const encode = (data: Record<string, string>) =>
        Object.keys(data)
          .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(data[key]))
          .join('&');

      const response = await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encode({
          'form-name': 'iletisim',
          ...formData,
        }),
      });

      if (response.ok) {
        setIsSubmitted(true);
        setFormData({ name: '', email: '', phone: '', company: '', subject: '', message: '' });
        setErrors({});
        setTimeout(() => setIsSubmitted(false), 6000);
      } else {
        throw new Error('Form gönderilemedi');
      }
    } catch {
      setErrors({ submit: 'Form gönderilirken bir hata oluştu. Lütfen e-posta veya telefon ile iletişime geçin.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Real-time validation on blur
  const handleBlur = (field: string) => {
    const newErrors = { ...errors };

    switch (field) {
      case 'name':
        if (!formData.name.trim()) {
          newErrors.name = t('Ad Soyad gereklidir', 'Full Name is required');
        } else if (formData.name.trim().length < 3) {
          newErrors.name = t('Ad Soyad en az 3 karakter olmalıdır', 'Full Name must be at least 3 characters');
        } else {
          delete newErrors.name;
        }
        break;
      case 'email':
        if (!formData.email.trim()) {
          newErrors.email = t('E-posta gereklidir', 'Email is required');
        } else if (!validateEmail(formData.email)) {
          newErrors.email = t('Geçerli bir e-posta adresi giriniz', 'Please enter a valid email address');
        } else {
          delete newErrors.email;
        }
        break;
      case 'phone':
        if (formData.phone && !validatePhone(formData.phone)) {
          newErrors.phone = t('Geçerli bir telefon numarası giriniz', 'Please enter a valid phone number');
        } else {
          delete newErrors.phone;
        }
        break;
      case 'subject':
        if (!formData.subject.trim()) {
          newErrors.subject = t('Konu gereklidir', 'Subject is required');
        } else if (formData.subject.trim().length < 5) {
          newErrors.subject = t('Konu en az 5 karakter olmalıdır', 'Subject must be at least 5 characters');
        } else {
          delete newErrors.subject;
        }
        break;
      case 'message':
        if (!formData.message.trim()) {
          newErrors.message = t('Mesaj gereklidir', 'Message is required');
        } else if (formData.message.trim().length < 20) {
          newErrors.message = t('Mesaj en az 20 karakter olmalıdır', 'Message must be at least 20 characters');
        } else {
          delete newErrors.message;
        }
        break;
    }

    setErrors(newErrors);
  };

  const contactInfo = [
    {
      icon: MapPin,
      titleTr: 'Adres',
      titleEn: 'Address',
      contentTr: 'Konak, İzmir',
      contentEn: 'Konak, Izmir',
    },
    {
      icon: Phone,
      titleTr: 'Telefon',
      titleEn: 'Phone',
      contentTr: '+90 (553) 720 69 72',
      contentEn: '+90 (553) 720 69 72',
    },
    {
      icon: Mail,
      titleTr: 'E-posta',
      titleEn: 'Email',
      contentTr: 'info@afectusshield.com',
      contentEn: 'info@afectusshield.com',
    },
    {
      icon: Clock,
      titleTr: 'Çalışma Saatleri',
      titleEn: 'Working Hours',
      contentTr: 'Pazartesi - Cuma: 09:00 - 18:00',
      contentEn: 'Monday - Friday: 09:00 - 18:00',
    },
  ];

  return (
    <>
      <SEO
        titleTr="İletişim | İzmir Yıldırım Koruma Firması - Ücretsiz Keşif ve Teklif"
        titleEn="Contact | Izmir Lightning Protection Company - Free Survey & Quote"
        descriptionTr="İzmir Konak'ta yıldırım koruma sistemleri için ücretsiz keşif ve teklif. 0553 720 69 72 - 7/24 acil destek. Paratoner montajı, risk analizi ve bakım hizmetleri."
        descriptionEn="Free survey and quote for lightning protection systems in Konak, Izmir. 0553 720 69 72 - 24/7 emergency support. Lightning rod installation, risk analysis and maintenance."
        canonical="/iletisim"
      />
      <div className="min-h-screen bg-background" style={{ position: 'relative' }}>
        <Header />
        
        {/* Hero Section */}
        <section className="relative pt-32 pb-16 border-b border-border">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                {t('İletişim', 'Contact')}
              </span>
              <h1 className="text-foreground mb-6">
                {t('Bizimle İletişime Geçin', 'Get in Touch')}
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                {t(
                  'Yıldırımdan korunma sistemleri hakkında detaylı bilgi almak ve projeleriniz için teklif talep etmek için formu doldurun.',
                  'Fill out the form to get detailed information about lightning protection systems and request a quote for your projects.'
                )}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Contact Info Cards */}
        <section className="relative py-16 bg-card border-b border-border">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {contactInfo.map((info, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="border border-border bg-background p-6 hover:border-accent transition-all duration-300"
                >
                  <info.icon className="w-10 h-10 text-accent mb-4" strokeWidth={2} />
                  <h3 className="text-sm font-bold text-foreground uppercase tracking-wide mb-2">
                    {t(info.titleTr, info.titleEn)}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {t(info.contentTr, info.contentEn)}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Form & Map */}
        <section className="relative py-24">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Form */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="text-3xl font-bold text-foreground mb-6">
                  {t('Teklif Talep Formu', 'Request a Quote')}
                </h2>
                <p className="text-muted-foreground mb-8">
                  {t(
                    'Aşağıdaki formu doldurarak size en kısa sürede geri dönüş yapalım.',
                    'Fill out the form below and we will get back to you as soon as possible.'
                  )}
                </p>

                <form 
                  name="contact-page-form" 
                  method="POST" 
                  data-netlify="true"
                  netlify-honeypot="bot-field"
                  onSubmit={handleSubmit}
                  className="space-y-6"
                >
                  <input type="hidden" name="form-name" value="iletisim" />
                  <p className="hidden">
                    <label>
                      Don't fill this out: <input name="bot-field" />
                    </label>
                  </p>

                  {/* Name */}
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-foreground mb-2">
                      {t('Ad Soyad *', 'Full Name *')}
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      onBlur={() => handleBlur('name')}
                      className="w-full bg-card border border-border text-foreground px-4 py-3 focus:outline-none focus:border-accent transition-colors"
                    />
                    {errors.name && (
                      <p className="text-red-500 text-sm mt-1">
                        <AlertCircle className="w-4 h-4 inline-block mr-1" />
                        {errors.name}
                      </p>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-foreground mb-2">
                      {t('E-posta *', 'Email *')}
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      onBlur={() => handleBlur('email')}
                      className="w-full bg-card border border-border text-foreground px-4 py-3 focus:outline-none focus:border-accent transition-colors"
                    />
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">
                        <AlertCircle className="w-4 h-4 inline-block mr-1" />
                        {errors.email}
                      </p>
                    )}
                  </div>

                  {/* Phone */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold text-foreground mb-2">
                      {t('Telefon', 'Phone')}
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      onBlur={() => handleBlur('phone')}
                      className="w-full bg-card border border-border text-foreground px-4 py-3 focus:outline-none focus:border-accent transition-colors"
                    />
                    {errors.phone && (
                      <p className="text-red-500 text-sm mt-1">
                        <AlertCircle className="w-4 h-4 inline-block mr-1" />
                        {errors.phone}
                      </p>
                    )}
                  </div>

                  {/* Company */}
                  <div>
                    <label htmlFor="company" className="block text-sm font-semibold text-foreground mb-2">
                      {t('Firma', 'Company')}
                    </label>
                    <input
                      type="text"
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="w-full bg-card border border-border text-foreground px-4 py-3 focus:outline-none focus:border-accent transition-colors"
                    />
                  </div>

                  {/* Subject */}
                  <div>
                    <label htmlFor="subject" className="block text-sm font-semibold text-foreground mb-2">
                      {t('Konu *', 'Subject *')}
                    </label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      required
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      onBlur={() => handleBlur('subject')}
                      className="w-full bg-card border border-border text-foreground px-4 py-3 focus:outline-none focus:border-accent transition-colors"
                    />
                    {errors.subject && (
                      <p className="text-red-500 text-sm mt-1">
                        <AlertCircle className="w-4 h-4 inline-block mr-1" />
                        {errors.subject}
                      </p>
                    )}
                  </div>

                  {/* Message */}
                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-foreground mb-2">
                      {t('Mesajınız *', 'Your Message *')}
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={6}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      onBlur={() => handleBlur('message')}
                      className="w-full bg-card border border-border text-foreground px-4 py-3 focus:outline-none focus:border-accent transition-colors resize-none"
                    />
                    {errors.message && (
                      <p className="text-red-500 text-sm mt-1">
                        <AlertCircle className="w-4 h-4 inline-block mr-1" />
                        {errors.message}
                      </p>
                    )}
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-3 bg-accent text-white px-8 py-4 font-semibold uppercase tracking-wide transition-all duration-200 hover:bg-[#B91C2C] hover:-translate-y-1 w-full md:w-auto disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={isSubmitting}
                  >
                    <Send className="w-5 h-5" strokeWidth={2.5} />
                    {isSubmitting 
                      ? t('Gönderiliyor...', 'Sending...') 
                      : t('Gönder', 'Send')
                    }
                  </button>

                  {errors.submit && (
                <div className="p-4 border border-accent/50 bg-accent/10 text-sm text-accent">
                  {errors.submit}
                </div>
              )}

              {isSubmitted && (
                    <p className="text-green-500 font-semibold">
                      {t(
                        'Mesajınız başarıyla gönderildi! En kısa sürede size dönüş yapacağız.',
                        'Your message has been sent successfully! We will get back to you as soon as possible.'
                      )}
                    </p>
                  )}
                </form>
              </motion.div>

              {/* Google Map */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="h-[600px] border border-border"
              >
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d50544.67897468798!2d27.0916!3d38.4188!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14bbd862a762cacd%3A0x628cbba1a59ce8fe!2sKonak%2C%20%C4%B0zmir!5e0!3m2!1str!2str!4v1640000000000!5m2!1str!2str"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title={t('Afectus Shield Konum', 'Afectus Shield Location')}
                />
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}