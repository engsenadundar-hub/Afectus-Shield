import { useLanguage } from '../contexts/LanguageContext';
import { SEO } from '../components/SEO';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { IndustriesSection } from '../components/IndustriesSection';
import { ContactCTA } from '../components/ContactCTA';
import { motion } from 'motion/react';
import { Building2, Factory, Hospital, Warehouse, Plane, Zap, Shield } from 'lucide-react';

export function IndustriesPage() {
  const { t } = useLanguage();

  const industriesDetailed = [
    {
      icon: Factory,
      image: 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=700&q=85&auto=format&fit=crop',
      titleTr: 'Petrokimya ve Rafineri',
      titleEn: 'Petrochemical and Refinery',
      descTr: 'Patlayıcı ortamlarda kritik yıldırım koruması. ATEX Zone 0/1/2 uyumlu sistemler, ex-proof ekipmanlar ve acil müdahale protokolleri.',
      descEn: 'Critical lightning protection in explosive atmospheres. ATEX Zone 0/1/2 compliant systems, ex-proof equipment, and emergency response protocols.',
      color: 'from-red-500 to-red-600',
      stats: [
        { labelTr: 'Risk Seviyesi', labelEn: 'Risk Level', value: 'LPL I' },
        { labelTr: 'ATEX Zone', labelEn: 'ATEX Zone', value: '0/1/2' },
        { labelTr: 'Müdahale Süresi', labelEn: 'Response Time', value: '< 2 saat' },
      ],
    },
    {
      icon: Hospital,
      image: 'https://images.unsplash.com/photo-1519494026892-476079a9e9e0?w=700&q=85&auto=format&fit=crop',
      titleTr: 'Hastane ve Sağlık',
      titleEn: 'Hospital and Healthcare',
      descTr: 'Kesintisiz hizmet için kritik altyapı koruması. Ameliyathane, yoğun bakım ve medikal ekipman koruması. 7/24 teknik destek.',
      descEn: 'Critical infrastructure protection for uninterrupted service. Operating room, ICU, and medical equipment protection. 24/7 technical support.',
      color: 'from-blue-500 to-blue-600',
      stats: [
        { labelTr: 'Risk Seviyesi', labelEn: 'Risk Level', value: 'LPL I' },
        { labelTr: 'Süreklilik', labelEn: 'Continuity', value: '%99.99' },
        { labelTr: 'Destek', labelEn: 'Support', value: '7/24' },
      ],
    },
    {
      icon: Building2,
      image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=700&q=85&auto=format&fit=crop',
      titleTr: 'Veri Merkezi',
      titleEn: 'Data Center',
      descTr: 'Server odaları, network altyapısı ve kritik veri koruması. SPD sistemleri, yedekli topraklama ve fiber optik koruma.',
      descEn: 'Server rooms, network infrastructure, and critical data protection. SPD systems, redundant grounding, and fiber optic protection.',
      color: 'from-purple-500 to-purple-600',
      stats: [
        { labelTr: 'Uptime', labelEn: 'Uptime', value: '%99.999' },
        { labelTr: 'SPD Sınıfı', labelEn: 'SPD Class', value: 'Type 1+2' },
        { labelTr: 'Risk Seviyesi', labelEn: 'Risk Level', value: 'LPL I' },
      ],
    },
    {
      icon: Warehouse,
      image: 'https://images.unsplash.com/photo-1581244936167-05c94e8ed71a?w=700&q=85&auto=format&fit=crop',
      titleTr: 'Endüstriyel Tesis',
      titleEn: 'Industrial Facility',
      descTr: 'Üretim hatları, depolama alanları ve kritik ekipman koruması. Proses sürekliliği ve personel güvenliği odaklı çözümler.',
      descEn: 'Production lines, storage areas, and critical equipment protection. Process continuity and personnel safety focused solutions.',
      color: 'from-red-600 to-red-700',
      stats: [
        { labelTr: 'Risk Seviyesi', labelEn: 'Risk Level', value: 'LPL II' },
        { labelTr: 'Kapsam', labelEn: 'Coverage', value: '%100' },
        { labelTr: 'Bakım', labelEn: 'Maintenance', value: 'Yıllık' },
      ],
    },
    {
      icon: Plane,
      image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=700&q=85&auto=format&fit=crop',
      titleTr: 'Havaalanı ve Lojistik',
      titleEn: 'Airport and Logistics',
      descTr: 'Hava trafik kontrol kuleleri, hangarlar ve yakıt depolama alanları. CAA standartlarına uygun sistemler.',
      descEn: 'Air traffic control towers, hangars, and fuel storage areas. CAA standard compliant systems.',
      color: 'from-cyan-500 to-cyan-600',
      stats: [
        { labelTr: 'Standart', labelEn: 'Standard', value: 'CAA' },
        { labelTr: 'Risk Seviyesi', labelEn: 'Risk Level', value: 'LPL I' },
        { labelTr: 'Sertifika', labelEn: 'Certificate', value: 'ICAO' },
      ],
    },
    {
      icon: Zap,
      image: 'https://images.unsplash.com/photo-1466611653911-0265b1d1a1b1?w=700&q=85&auto=format&fit=crop',
      titleTr: 'Enerji Santrali',
      titleEn: 'Power Plant',
      descTr: 'Trafo merkezleri, türbin sistemleri ve kontrol odaları. Yüksek gerilim koruma ve topraklama sistemleri.',
      descEn: 'Transformer stations, turbine systems, and control rooms. High voltage protection and grounding systems.',
      color: 'from-yellow-500 to-yellow-600',
      stats: [
        { labelTr: 'Kapasite', labelEn: 'Capacity', value: '> 100 MW' },
        { labelTr: 'Risk Seviyesi', labelEn: 'Risk Level', value: 'LPL I' },
        { labelTr: 'Topraklama', labelEn: 'Grounding', value: '< 1Ω' },
      ],
    },
  ];

  const caseStudies = [
    {
      titleTr: '500+ Tesis',
      titleEn: '500+ Facilities',
      descTr: 'Türkiye genelinde başarıyla tamamlanmış projeler',
      descEn: 'Successfully completed projects across Turkey',
      icon: '🏭',
    },
    {
      titleTr: '15+ Yıl',
      titleEn: '15+ Years',
      descTr: 'Yıldırım koruma sistemleri deneyimi',
      descEn: 'Lightning protection systems experience',
      icon: '⚡',
    },
    {
      titleTr: '%100 Uyum',
      titleEn: '100% Compliance',
      descTr: 'IEC 62305:2024 standart uyumluluğu',
      descEn: 'IEC 62305:2024 standard compliance',
      icon: '✅',
    },
    {
      titleTr: '7/24 Destek',
      titleEn: '24/7 Support',
      descTr: 'Kesintisiz teknik destek ve acil müdahale',
      descEn: 'Uninterrupted technical support and emergency response',
      icon: '🛡️',
    },
  ];

  return (
    <>
      <SEO
        titleTr="Sektörel Paratoner Çözümleri İzmir | Fabrika Hastane Veri Merkezi"
        titleEn="Industry Lightning Protection Izmir | Factory Hospital Data Center"
        descriptionTr="İzmir'de petrokimya, hastane, veri merkezi, fabrika, havaalanı ve enerji santrali için özel paratoner sistemleri. ATEX Zone uyumlu çözümler, LPL I-IV risk analizi."
        descriptionEn="Specialized lightning rod systems for petrochemical, hospital, data center, factory, airport, and power plant in Izmir. ATEX Zone compliant solutions, LPL I-IV risk analysis."
        canonical="/sektorler"
      />

      <div className="min-h-screen bg-background" style={{ position: 'relative' }}>
        <Header />
        <main>
          {/* Hero Section */}
          <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden pt-40 pb-20">
            {/* Background fotoğraf */}
            <div className="absolute inset-0">
              <img
                src="https://images.unsplash.com/photo-1513828583688-c52b4e3f531f?w=1600&q=80&auto=format&fit=crop"
                alt="Industrial facilities we protect"
                width={1600}
                height={900}
                className="w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-background/85 via-background/75 to-background" />
            </div>
            {/* Motion effects */}
            <div className="absolute inset-0 pointer-events-none">
              <motion.div
                className="absolute top-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"
                animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.5, 0.3] }}
                transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
              />
              <motion.div
                className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-cyan-primary/10 rounded-full blur-3xl"
                animate={{ scale: [1.3, 1, 1.3], opacity: [0.5, 0.3, 0.5] }}
                transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
              />
            </div>{/* /motion effects */}

            <div className="max-w-4xl mx-auto px-6 text-center relative z-10 py-20">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <div className="inline-flex items-center gap-3 mb-6 px-6 py-3 border border-accent/30 bg-accent/5">
                  <Shield className="w-6 h-6 text-accent" strokeWidth={2.5} />
                  <span className="text-accent font-bold uppercase tracking-wider text-sm">
                    {t('Sektörel Uzmanlık', 'Industry Expertise')}
                  </span>
                </div>
                
                <h1 className="text-foreground mb-6">
                  {t(
                    'Hizmet Verdiğimiz Sektörler',
                    'Industries We Serve'
                  )}
                </h1>
                
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                  {t(
                    'Her sektörün kendine özgü ihtiyaçlarına göre özelleştirilmiş yıldırım koruma çözümleri.',
                    'Customized lightning protection solutions tailored to each industry\'s unique needs.'
                  )}
                </p>
              </motion.div>
            </div>
          </section>

          {/* Detailed Industries Grid */}
          <section className="relative py-24 bg-background mt-32">
            <div className="max-w-7xl mx-auto px-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {industriesDetailed.map((industry, index) => {
                  const Icon = industry.icon;
                  return (
                    <motion.div
                      key={index}
                      className="relative group"
                      initial={{ opacity: 0, y: 50 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, margin: '-50px' }}
                      transition={{ duration: 0.6, delay: index * 0.1 }}
                    >
                      <div className="border border-border bg-[#0F1419] h-full transition-all duration-300 group-hover:border-accent group-hover:-translate-y-2 overflow-hidden flex flex-col">
                        {/* Fotoğraf */}
                        <div className="relative h-44 overflow-hidden flex-shrink-0">
                          <img
                            src={industry.image}
                            alt={t(industry.titleTr, industry.titleEn)}
                            width={700}
                            height={176}
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-[#0F1419] via-[#0F1419]/50 to-transparent" />
                          <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${industry.color}`} />
                        </div>
                        <div className="p-8 flex flex-col flex-1">
                        {/* Icon with gradient */}
                        <div className={`inline-flex items-center justify-center w-16 h-16 mb-6 bg-gradient-to-br ${industry.color}`}>
                          <Icon className="w-8 h-8 text-white" strokeWidth={2.5} />
                        </div>

                        {/* Title */}
                        <h3 className="text-foreground mb-4 text-xl">
                          {t(industry.titleTr, industry.titleEn)}
                        </h3>

                        {/* Description */}
                        <p className="text-muted-foreground leading-relaxed mb-6">
                          {t(industry.descTr, industry.descEn)}
                        </p>

                        {/* Stats */}
                        <div className="space-y-3 pt-6 border-t border-border">
                          {industry.stats.map((stat, idx) => (
                            <div key={idx} className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground">
                                {t(stat.labelTr, stat.labelEn)}
                              </span>
                              <span className="text-accent font-bold">
                                {stat.value}
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Bottom accent line */}
                        <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${industry.color} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300`} />
                        </div>{/* /p-8 */}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* Case Studies / Stats */}
          <section className="relative py-24 bg-navy-900">
            <div className="max-w-7xl mx-auto px-6">
              <motion.div
                className="text-center mb-16"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                  {t('Referanslar', 'References')}
                </span>
                <h2 className="text-foreground mb-6">
                  {t('Deneyimimiz Rakamlarla', 'Our Experience in Numbers')}
                </h2>
              </motion.div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {caseStudies.map((item, index) => (
                  <motion.div
                    key={index}
                    className="border border-border bg-[#0F1419] p-8 text-center group hover:border-accent transition-all duration-300"
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <div className="text-6xl mb-4">
                      {item.icon}
                    </div>
                    <h3 className="text-foreground text-2xl font-bold mb-3">
                      {t(item.titleTr, item.titleEn)}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {t(item.descTr, item.descEn)}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Main Industries Section */}
          <IndustriesSection />

          {/* Contact CTA */}
          <ContactCTA />
        </main>
        <Footer />
      </div>
    </>
  );
}