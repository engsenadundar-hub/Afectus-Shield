import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { SEO } from '../components/SEO';
import { Calendar, User, ArrowRight, Tag } from 'lucide-react';

export function BlogPage() {
  const { t } = useLanguage();

  const blogPosts = [
    {
      id: 1,
      titleTr: 'IEC 62305 Standardı: Yıldırımdan Korunmanın Temelleri',
      titleEn: 'IEC 62305 Standard: Fundamentals of Lightning Protection',
      excerpt: {
        tr: 'Yıldırımdan korunma sistemlerinin tasarımında uluslararası standart olan IEC 62305 hakkında bilmeniz gerekenler.',
        en: 'What you need to know about IEC 62305, the international standard for lightning protection system design.',
      },
      date: '15 Şubat 2024',
      author: 'Mehmet Yılmaz',
      category: { tr: 'Teknik', en: 'Technical' },
      image: 'https://images.unsplash.com/photo-1769149068959-b11392164add?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmdpbmVlciUyMGluc3BlY3RpbmclMjBlbGVjdHJpY2FsJTIwc3lzdGVtfGVufDF8fHx8MTc3MTMzMzg1MHww&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 2,
      titleTr: 'Veri Merkezlerinde Yıldırım Koruması: Kritik Önem',
      titleEn: 'Lightning Protection in Data Centers: Critical Importance',
      excerpt: {
        tr: 'Veri merkezlerinde kesintisiz hizmet için etkili yıldırım koruma sistemlerinin önemi ve uygulama stratejileri.',
        en: 'The importance of effective lightning protection systems for uninterrupted service in data centers and implementation strategies.',
      },
      date: '08 Şubat 2024',
      author: 'Ayşe Demir',
      category: { tr: 'Sektörel', en: 'Industry' },
      image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwY2VudGVyJTIwc2VydmVyfGVufDF8fHx8MTc0MDgzMzk5Mnww&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 3,
      titleTr: 'Topraklama Direnci Ölçümü: Doğru Yöntemler',
      titleEn: 'Grounding Resistance Measurement: Correct Methods',
      excerpt: {
        tr: 'Topraklama sistemlerinin etkinliğini değerlendirmek için kullanılan ölçüm yöntemleri ve standartlar.',
        en: 'Measurement methods and standards used to evaluate the effectiveness of grounding systems.',
      },
      date: '01 Şubat 2024',
      author: 'Can Öztürk',
      category: { tr: 'Teknik', en: 'Technical' },
      image: 'https://images.unsplash.com/photo-1652961221312-607cea8d5bdb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncm91bmRpbmclMjBlYXJ0aGluZyUyMHJvZCUyMGluc3RhbGxhdGlvbnxlbnwxfHx8fDE3NzE0ODQ0MTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 4,
      titleTr: 'Parafudr Seçimi: Tip 1, Tip 2, Tip 3 Farkları',
      titleEn: 'SPD Selection: Type 1, Type 2, Type 3 Differences',
      excerpt: {
        tr: 'Farklı parafudr tipleri arasındaki farklar ve uygulamaya göre doğru seçim kriterleri.',
        en: 'Differences between different SPD types and correct selection criteria according to application.',
      },
      date: '25 Ocak 2024',
      author: 'Elif Kaya',
      category: { tr: 'Ürün', en: 'Product' },
      image: 'https://images.unsplash.com/photo-1768796365086-a030a51d10b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJnZSUyMHByb3RlY3Rpb24lMjBkZXZpY2UlMjBhcnJlc3RlcnxlbnwxfHx8fDE3NzE0ODQ1MjR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 5,
      titleTr: 'Risk Analizi: IEC 62305-2 Uygulamaları',
      titleEn: 'Risk Analysis: IEC 62305-2 Applications',
      excerpt: {
        tr: 'IEC 62305-2 standardına göre risk analizi yapma adımları ve değerlendirme kriterleri.',
        en: 'Steps for conducting risk analysis according to IEC 62305-2 standard and evaluation criteria.',
      },
      date: '18 Ocak 2024',
      author: 'Mehmet Yılmaz',
      category: { tr: 'Teknik', en: 'Technical' },
      image: 'https://images.unsplash.com/photo-1769698655332-9d11e7bb2a24?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWN0b3J5JTIwaW5kdXN0cmlhbCUyMHBsYW50JTIwYWVyaWFsfGVufDF8fHx8MTc3MTMzMzg0OXww&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 6,
      titleTr: 'Petrokimya Tesislerinde Özel Koruma Gereksinimleri',
      titleEn: 'Special Protection Requirements in Petrochemical Facilities',
      excerpt: {
        tr: 'Patlayıcı ortamlara sahip petrokimya tesislerinde yıldırımdan korunma sistemlerinin tasarım kriterleri.',
        en: 'Design criteria for lightning protection systems in petrochemical facilities with explosive atmospheres.',
      },
      date: '10 Ocak 2024',
      author: 'Ayşe Demir',
      category: { tr: 'Sektörel', en: 'Industry' },
      image: 'https://images.unsplash.com/photo-1759853025392-0f7d077d2a23?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZmFjdG9yeSUyMHNreWxpbmUlMjBkYXJrfGVufDF8fHx8MTc3MTQ3OTg0MHww&ixlib=rb-4.1.0&q=80&w=1080',
    },
  ];

  return (
    <>
      <SEO
        titleTr="Blog | Yıldırım Koruma ve Paratoner Sistemleri Güncel Bilgiler"
        titleEn="Blog | Lightning Protection & Grounding Systems Latest Updates"
        descriptionTr="Yıldırım koruma sistemleri, IEC 62305 standardı, paratoner teknolojileri, ATEX uygulamaları ve endüstriyel güvenlik hakkında uzman yazılar. İzmir elektrik mühendisliği blog."
        descriptionEn="Expert articles on lightning protection systems, IEC 62305 standard, lightning rod technologies, ATEX applications and industrial safety. Izmir electrical engineering blog."
        canonical="/blog"
      />
      <div className="min-h-screen bg-background" style={{ position: 'relative' }}>
        <Header />
        
        {/* Hero Section */}
        <section className="relative pt-32 pb-24 border-b border-border">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                {t('Blog', 'Blog')}
              </span>
              <h1 className="text-[#d4d4d8] mb-6">
                {t('Teknik Makaleler ve Haberler', 'Technical Articles and News')}
              </h1>
              <p className="text-xl text-[#a1a1aa] max-w-3xl mx-auto">
                {t(
                  'Yıldırımdan korunma teknolojileri ve sektörel gelişmeler hakkında güncel içerikler.',
                  'Current content about lightning protection technologies and industry developments.'
                )}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Blog Posts Grid */}
        <section className="relative py-24">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map((post, index) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group border border-border bg-card overflow-hidden relative"
                >
                  {/* Coming Soon Badge */}
                  <div className="absolute top-4 right-4 z-10 bg-background border border-accent text-accent px-3 py-1.5 text-xs font-bold uppercase tracking-wider">
                    {t('Yakında', 'Coming Soon')}
                  </div>

                  {/* Post Image */}
                  <div className="h-56 overflow-hidden relative">
                    <img
                      src={post.image}
                      alt={t(post.titleTr, post.titleEn)}
                      width={800}
                  height={500}
                  loading="lazy"
                  className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute top-4 left-4 bg-accent text-white px-3 py-1 text-xs font-bold uppercase tracking-wider">
                      {t(post.category.tr, post.category.en)}
                    </div>
                  </div>

                  {/* Post Content */}
                  <div className="p-6 opacity-70">
                    {/* Meta */}
                    <div className="flex items-center gap-4 mb-4 text-xs text-muted-foreground/80">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5" strokeWidth={2} />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5" strokeWidth={2} />
                        <span>{post.author}</span>
                      </div>
                    </div>

                    {/* Title */}
                    <h2 className="text-lg font-bold text-foreground mb-3">
                      {t(post.titleTr, post.titleEn)}
                    </h2>

                    {/* Excerpt */}
                    <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                      {t(post.excerpt.tr, post.excerpt.en)}
                    </p>

                    {/* Read More - Disabled */}
                    <div className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground/60 uppercase tracking-wide cursor-not-allowed">
                      {t('Devamını Oku', 'Read More')}
                      <ArrowRight className="w-4 h-4" strokeWidth={2.5} />
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}