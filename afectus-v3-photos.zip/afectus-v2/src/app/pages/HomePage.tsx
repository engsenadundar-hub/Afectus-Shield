/**
 * HOME PAGE
 * 
 * Main landing page with all key sections:
 * - Hero section
 * - Trust indicators
 * - Problem/Solution showcase
 * - Services overview
 * - Process overview
 * - LPL Levels explanation
 * - ATEX information
 * - Industries served
 * - FAQ
 * - Contact CTA
 * 
 * This is the most content-heavy page but code-split for optimal loading.
 */

import { SEO } from '../components/SEO';
import { Header } from '../components/Header';
import { Hero } from '../components/Hero';
import { TrustSection } from '../components/TrustSection';
import { InteractiveProblemSolution } from '../components/InteractiveProblemSolution';
import { ProblemSolution } from '../components/ProblemSolution';
import { ServicesSection } from '../components/ServicesSection';
import { ProcessSection } from '../components/ProcessSection';
import { LPLLevelsSection } from '../components/LPLLevelsSection';
import { ATEXSection } from '../components/ATEXSection';
import { IndustriesSection } from '../components/IndustriesSection';
import { FAQSection } from '../components/FAQSection';
import { ProjectsSection } from '../components/ProjectsSection';
import { ContactCTA } from '../components/ContactCTA';
import { Footer } from '../components/Footer';

export function HomePage() {
  return (
    <>
      <SEO 
        titleTr="İzmir Yıldırımdan Korunma Firması | Paratoner Sistemi Kurulumu - Afectus Shield"
        titleEn="Lightning Protection Company Izmir | Lightning Rod Installation - Afectus Shield"
        descriptionTr="İzmir'de profesyonel yıldırım koruma sistemleri ve paratoner kurulumu. IEC 62305:2024 standartlarında fabrika, hastane, veri merkezi için risk analizi ve topraklama. 7/24 teknik destek."
        descriptionEn="Professional lightning protection systems and lightning rod installation in Izmir. Risk analysis and grounding for factories, hospitals, data centers per IEC 62305:2024 standards. 24/7 support."
        canonical="/"
      />
      <div className="min-h-screen bg-background" style={{ overflow: 'visible', touchAction: 'auto', position: 'relative' }}>
        <Header />
        <main id="main-content" style={{ overflow: 'visible', position: 'relative' }}>
          <Hero />
          <TrustSection />
          <InteractiveProblemSolution />
          <ProblemSolution />
          <ServicesSection />
          <ProcessSection />
          <LPLLevelsSection />
          <ATEXSection />
          <IndustriesSection />
          <ProjectsSection />
          <FAQSection />
          <ContactCTA />
        </main>
        <Footer />
      </div>
    </>
  );
}