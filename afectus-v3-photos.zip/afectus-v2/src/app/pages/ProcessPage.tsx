import { useLanguage } from '../contexts/LanguageContext';
import { SEO } from '../components/SEO';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { ProcessSection } from '../components/ProcessSection';
import { LPLLevelsSection } from '../components/LPLLevelsSection';
import { ATEXSection } from '../components/ATEXSection';
import { ContactCTA } from '../components/ContactCTA';
import { motion } from 'motion/react';
import { Shield, CheckCircle2, FileText } from 'lucide-react';

export function ProcessPage() {
  const { t } = useLanguage();

  const processDetails = [
    {
      iconTr: '🔍',
      iconEn: '🔍',
      titleTr: 'Ön İnceleme ve Ölçüm',
      titleEn: 'Preliminary Inspection and Measurement',
      descTr: 'Tesis yerinde detaylı ölçüm ve risk analizi yapılır. Zemin direnci, yapısal özellikler ve çevresel faktörler değerlendirilir.',
      descEn: 'Detailed on-site measurement and risk analysis. Ground resistance, structural features, and environmental factors are evaluated.',
    },
    {
      iconTr: '📐',
      iconEn: '📐',
      titleTr: 'Mühendislik Projesi',
      titleEn: 'Engineering Design',
      descTr: 'IEC 62305 standardına uygun mühendislik projesi hazırlanır. LPL seviyesi belirlenir, sistem bileşenleri seçilir.',
      descEn: 'Engineering project prepared in accordance with IEC 62305 standard. LPL level determined, system components selected.',
    },
    {
      iconTr: '⚡',
      iconEn: '⚡',
      titleTr: 'Montaj ve Uygulama',
      titleEn: 'Installation and Implementation',
      descTr: 'Uzman ekip tarafından profesyonel montaj. Havai sonlandırıcılar, iniş iletkenleri ve topraklama sistemi kurulumu.',
      descEn: 'Professional installation by expert team. Air terminals, down conductors, and grounding system installation.',
    },
    {
      iconTr: '✅',
      iconEn: '✅',
      titleTr: 'Test ve Ölçüm',
      titleEn: 'Testing and Measurement',
      descTr: 'Topraklama direnci, süreklilik ve yalıtım testleri yapılır. Tüm değerler standart limitleri sağlamalıdır.',
      descEn: 'Ground resistance, continuity, and insulation tests performed. All values must meet standard limits.',
    },
    {
      iconTr: '📋',
      iconEn: '📋',
      titleTr: 'Raporlama ve Onay',
      titleEn: 'Reporting and Approval',
      descTr: 'Detaylı test raporları ve ölçüm sonuçları hazırlanır. Bakanlık onayı için gerekli belgeler sunulur.',
      descEn: 'Detailed test reports and measurement results prepared. Required documents submitted for ministry approval.',
    },
    {
      iconTr: '🔧',
      iconEn: '🔧',
      titleTr: 'Bakım ve Destek',
      titleEn: 'Maintenance and Support',
      descTr: 'Periyodik bakım planlaması ve 7/24 teknik destek. Sistem performansı düzenli olarak kontrol edilir.',
      descEn: 'Periodic maintenance planning and 24/7 technical support. System performance regularly monitored.',
    },
  ];

  const certifications = [
    {
      iconTr: '🏛️',
      iconEn: '🏛️',
      titleTr: 'Bakanlık Onaylı',
      titleEn: 'Ministry Approved',
      descTr: 'Tüm projelerimiz Çevre, Şehircilik ve İklim Değişikliği Bakanlığı tarafından onaylanır.',
      descEn: 'All our projects are approved by the Ministry of Environment, Urbanization and Climate Change.',
    },
    {
      iconTr: '📜',
      iconEn: '📜',
      titleTr: 'IEC 62305:2024',
      titleEn: 'IEC 62305:2024',
      descTr: 'En güncel uluslararası yıldırım koruma standardına tam uyum.',
      descEn: 'Full compliance with the latest international lightning protection standard.',
    },
    {
      iconTr: '⚡',
      iconEn: '⚡',
      titleTr: 'EMO Üyesi',
      titleEn: 'EMO Member',
      descTr: 'Elektrik Mühendisleri Odası üyeliği ile profesyonel hizmet garantisi.',
      descEn: 'Professional service guarantee with Chamber of Electrical Engineers membership.',
    },
    {
      iconTr: '🛡️',
      iconEn: '🛡️',
      titleTr: 'Sigorta Uyumlu',
      titleEn: 'Insurance Compliant',
      descTr: 'Sigorta şirketleri tarafından kabul edilen standart uyumlu çözümler.',
      descEn: 'Standard compliant solutions accepted by insurance companies.',
    },
  ];

  return (
    <>
      <SEO
        titleTr="Yıldırım Koruma Sistemi Kurulum Süreci | İzmir 7 Adımda Montaj"
        titleEn="Lightning Protection System Installation Process | Izmir 7-Step Setup"
        descriptionTr="İzmir'de yıldırım koruma sistemi nasıl kurulur? Saha incelemesi, risk analizi, tasarım, montaj, test, belgelendirme ve bakım. IEC 62305 uyumlu adım adım süreç."
        descriptionEn="How to install lightning protection system in Izmir? Site survey, risk analysis, design, installation, testing, certification and maintenance. IEC 62305 compliant step-by-step process."
        canonical="/surec"
      />

      <div className="min-h-screen bg-background" style={{ position: 'relative' }}>
        <Header />
        <main id="main-content">
          {/* Hero Section */}
          <section className="relative min-h-[70vh] flex items-center justify-center bg-gradient-to-b from-background via-navy-900 to-background overflow-hidden pt-40 pb-20">
            {/* Background effects */}
            <div className="absolute inset-0">
              <motion.div
                className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"
                animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.5, 0.3] }}
                transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
              />
              <motion.div
                className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-primary/10 rounded-full blur-3xl"
                animate={{ scale: [1.3, 1, 1.3], opacity: [0.5, 0.3, 0.5] }}
                transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
              />
            </div>

            <div className="max-w-4xl mx-auto px-6 text-center relative z-10 py-20">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <div className="inline-flex items-center gap-3 mb-6 px-6 py-3 border border-accent/30 bg-accent/5">
                  <Shield className="w-6 h-6 text-accent" strokeWidth={2.5} />
                  <span className="text-accent font-bold uppercase tracking-wider text-sm">
                    {t('Profesyonel Süreç', 'Professional Process')}
                  </span>
                </div>
                
                <h1 className="text-foreground mb-6">
                  {t(
                    'Yıldırım Koruma Sistemi Kurulum Süreci',
                    'Lightning Protection System Installation Process'
                  )}
                </h1>
                
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                  {t(
                    'IEC 62305 standardına uygun, bakanlık onaylı ve sigorta uyumlu 6 adımlı profesyonel kurulum süreci.',
                    'IEC 62305 compliant, ministry approved, and insurance-compliant 6-step professional installation process.'
                  )}
                </p>
              </motion.div>
            </div>
          </section>

          {/* Process Steps Section */}
          <section className="relative py-24 bg-background mt-32">
            <div className="max-w-7xl mx-auto px-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {processDetails.map((item, index) => (
                  <motion.div
                    key={index}
                    className="relative group"
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-50px' }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <div className="border border-border bg-[#0F1419] p-8 h-full transition-all duration-300 group-hover:border-accent group-hover:-translate-y-2">
                      {/* Step Number */}
                      <div className="absolute top-0 left-0 w-12 h-12 bg-accent flex items-center justify-center">
                        <span className="text-white font-bold text-xl">{index + 1}</span>
                      </div>

                      {/* Icon */}
                      <div className="text-5xl mb-4 mt-8">
                        {t(item.iconTr, item.iconEn)}
                      </div>

                      {/* Title */}
                      <h3 className="text-foreground mb-4 text-xl">
                        {t(item.titleTr, item.titleEn)}
                      </h3>

                      {/* Description */}
                      <p className="text-muted-foreground leading-relaxed">
                        {t(item.descTr, item.descEn)}
                      </p>

                      {/* Bottom accent line */}
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-accent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Certifications Section */}
          <section className="relative py-24 bg-navy-900">
            <div className="max-w-7xl mx-auto px-6">
              <motion.div
                className="text-center mb-16"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                  {t('Sertifikalar ve Onaylar', 'Certifications and Approvals')}
                </span>
                <h2 className="text-foreground mb-6">
                  {t('Standart Uyumluluk Garantisi', 'Standard Compliance Guarantee')}
                </h2>
              </motion.div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {certifications.map((cert, index) => (
                  <motion.div
                    key={index}
                    className="border border-border bg-[#0F1419] p-6 text-center group hover:border-accent transition-all duration-300"
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <div className="text-5xl mb-4">
                      {t(cert.iconTr, cert.iconEn)}
                    </div>
                    <h4 className="text-foreground mb-3 font-semibold">
                      {t(cert.titleTr, cert.titleEn)}
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {t(cert.descTr, cert.descEn)}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Main Process Section */}
          <ProcessSection />

          {/* LPL Levels Section */}
          <LPLLevelsSection />

          {/* ATEX Section */}
          <ATEXSection />

          {/* Contact CTA */}
          <ContactCTA />
        </main>
        <Footer />
      </div>
    </>
  );
}