import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { SEO } from '../components/SEO';
import { Factory, Zap, Building2, Warehouse, Database, Wind } from 'lucide-react';

export function IndustriesOverviewPage() {
  const { t } = useLanguage();

  const industries = [
    {
      icon: Factory,
      nameTr: 'İmalat Tesisleri',
      nameEn: 'Manufacturing Facilities',
      descTr: 'Üretim hatlarını ve kritik ekipmanları yıldırımdan kaynaklanan kesintilere karşı koruma.',
      descEn: 'Protection of production lines and critical equipment against lightning-induced interruptions.',
      image: 'https://images.unsplash.com/photo-1769698655332-9d11e7bb2a24?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWN0b3J5JTIwaW5kdXN0cmlhbCUyMHBsYW50JTIwYWVyaWFsfGVufDF8fHx8MTc3MTMzMzg0OXww&ixlib=rb-4.1.0&q=80&w=1080',
      features: [
        { tr: 'Üretim sürekliliği', en: 'Production continuity' },
        { tr: 'Ekipman koruması', en: 'Equipment protection' },
        { tr: 'İşçi güvenliği', en: 'Worker safety' },
      ],
    },
    {
      icon: Zap,
      nameTr: 'Enerji Santralleri',
      nameEn: 'Power Plants',
      descTr: 'Kritik enerji altyapısını ve dağıtım sistemlerini yüksek voltajlı yıldırım etkilerine karşı koruma.',
      descEn: 'Protection of critical energy infrastructure and distribution systems against high voltage lightning effects.',
      image: 'https://images.unsplash.com/photo-1765375522929-994a71439c63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3dlciUyMHN1YnN0YXRpb24lMjBlbGVjdHJpY2FsJTIwaW5mcmFzdHJ1Y3R1cmV8ZW58MXx8fHwxNzcxMjYwMTA4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      features: [
        { tr: 'Yüksek voltaj koruması', en: 'High voltage protection' },
        { tr: 'Kritik altyapı güvenliği', en: 'Critical infrastructure security' },
        { tr: 'Sistem sürekliliği', en: 'System continuity' },
      ],
    },
    {
      icon: Building2,
      nameTr: 'Ticari Binalar',
      nameEn: 'Commercial Buildings',
      descTr: 'Yüksek binalar, ofis kompleksleri ve alışveriş merkezlerinde kapsamlı yıldırım koruması.',
      descEn: 'Comprehensive lightning protection in high-rise buildings, office complexes and shopping centers.',
      image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tZXJjaWFsJTIwYnVpbGRpbmclMjBza3lzY3JhcGVyfGVufDF8fHx8MTc0MDgzNDA0OHww&ixlib=rb-4.1.0&q=80&w=1080',
      features: [
        { tr: 'Can güvenliği', en: 'Life safety' },
        { tr: 'Yapısal koruma', en: 'Structural protection' },
        { tr: 'Sigorta uyumluluğu', en: 'Insurance compliance' },
      ],
    },
    {
      icon: Warehouse,
      nameTr: 'Lojistik Merkezleri',
      nameEn: 'Logistics Centers',
      descTr: 'Geniş alanlı depo tesislerinde etkili LPS sistemleri ile mal ve ekipman güvenliği.',
      descEn: 'Safety of goods and equipment with effective LPS systems in wide-area warehouse facilities.',
      image: 'https://images.unsplash.com/photo-1761115435501-bebf019aba54?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwYnVpbGRpbmclMjByb29mdG9wJTIwZXF1aXBtZW50fGVufDF8fHx8MTc3MTMzMzg1MXww&ixlib=rb-4.1.0&q=80&w=1080',
      features: [
        { tr: 'Geniş alan koruması', en: 'Wide area protection' },
        { tr: 'Stok güvenliği', en: 'Inventory security' },
        { tr: 'Operasyonel süreklilik', en: 'Operational continuity' },
      ],
    },
    {
      icon: Database,
      nameTr: 'Veri Merkezleri',
      nameEn: 'Data Centers',
      descTr: 'Kritik IT altyapısı için çok katmanlı SPD koruması ve elektromanyetik uyumluluk çözümleri.',
      descEn: 'Multi-layer SPD protection and electromagnetic compatibility solutions for critical IT infrastructure.',
      image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwY2VudGVyJTIwc2VydmVyfGVufDF8fHx8MTc0MDgzMzk5Mnww&ixlib=rb-4.1.0&q=80&w=1080',
      features: [
        { tr: 'Veri koruması', en: 'Data protection' },
        { tr: 'Uptime garantisi', en: 'Uptime guarantee' },
        { tr: 'EMC uyumluluğu', en: 'EMC compliance' },
      ],
    },
    {
      icon: Wind,
      nameTr: 'Petrokimya',
      nameEn: 'Petrochemical',
      descTr: 'Patlayıcı ortamlarda özel tehlike analizi ve ATEX uyumlu yıldırım koruma çözümleri.',
      descEn: 'Special hazard analysis in explosive atmospheres and ATEX compliant lightning protection solutions.',
      image: 'https://images.unsplash.com/photo-1759853025392-0f7d077d2a23?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZmFjdG9yeSUyMHNreWxpbmUlMjBkYXJrfGVufDF8fHx8MTc3MTQ3OTg0MHww&ixlib=rb-4.1.0&q=80&w=1080',
      features: [
        { tr: 'ATEX uyumluluğu', en: 'ATEX compliance' },
        { tr: 'Patlama riski analizi', en: 'Explosion risk analysis' },
        { tr: 'Özel tehlike zonları', en: 'Special hazard zones' },
      ],
    },
  ];

  return (
    <>
      <SEO 
        title={t('Sektörler - Afectus Shield', 'Industries - Afectus Shield')}
        description={t(
          'Farklı sektörlerde yıldırımdan korunma sistemi çözümlerimiz ve uzmanlık alanlarımız.',
          'Our lightning protection system solutions and areas of expertise in different sectors.'
        )}
      />
      <div className="min-h-screen bg-[#0f0f12]">
        <Header />
        
        {/* Hero Section */}
        <section className="relative pt-32 pb-24 border-b border-[#2a2a32] overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src="https://images.unsplash.com/photo-1759853025392-0f7d077d2a23?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZmFjdG9yeSUyMHNreWxpbmUlMjBkYXJrfGVufDF8fHx8MTc3MTQ3OTg0MHww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Industries"
              width={800}
                  height={500}
                  loading="lazy"
                  className="w-full h-full object-cover opacity-10"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#0f0f12]/90 via-[#0f0f12]/95 to-[#0f0f12]"></div>
          </div>

          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <span className="text-sm font-bold text-[#dc2626] uppercase tracking-wider mb-4 block">
                {t('Sektörler', 'Industries')}
              </span>
              <h1 className="text-[#d4d4d8] mb-6">
                {t('Geniş Sektör Yelpazesinde Deneyim', 'Experience Across Wide Range of Industries')}
              </h1>
              <p className="text-xl text-[#a1a1aa] max-w-3xl mx-auto">
                {t(
                  'Farklı endüstrilerde özelleştirilmiş yıldırımdan korunma çözümleri sunuyoruz.',
                  'We provide customized lightning protection solutions across different industries.'
                )}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Industries Grid */}
        <section className="relative py-24">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {industries.map((industry, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group border border-[#2a2a32] bg-[#1a1a1f] overflow-hidden hover:border-[#dc2626] transition-all duration-300"
                >
                  {/* Industry Image */}
                  <div className="h-56 overflow-hidden relative">
                    <img
                      src={industry.image}
                      alt={t(industry.nameTr, industry.nameEn)}
                      width={800}
                  height={500}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1f] via-[#1a1a1f]/60 to-transparent"></div>
                    
                    {/* Icon Overlay */}
                    <div className="absolute bottom-4 left-4">
                      <div className="w-16 h-16 flex items-center justify-center border-2 border-[#dc2626] bg-[#0f0f12]">
                        <industry.icon className="w-8 h-8 text-[#dc2626]" strokeWidth={2} />
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-8">
                    <h3 className="text-2xl font-bold text-[#d4d4d8] mb-4 uppercase tracking-wide">
                      {t(industry.nameTr, industry.nameEn)}
                    </h3>
                    
                    <p className="text-[#a1a1aa] mb-6 leading-relaxed">
                      {t(industry.descTr, industry.descEn)}
                    </p>

                    <ul className="space-y-2">
                      {industry.features.map((feature, fIndex) => (
                        <li key={fIndex} className="flex items-center gap-3 text-[#a1a1aa]">
                          <div className="w-1.5 h-1.5 bg-[#dc2626]"></div>
                          <span>{t(feature.tr, feature.en)}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}