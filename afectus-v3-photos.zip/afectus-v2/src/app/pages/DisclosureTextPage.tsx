import { Link } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { SEO } from '../components/SEO';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { ArrowLeft } from 'lucide-react';

export function DisclosureTextPage() {
  const { t } = useLanguage();

  return (
    <>
      <SEO />
      <div className="min-h-screen bg-[#0f0f12]" style={{ position: 'relative' }}>
        <Header />
        
        <main className="py-24 px-6">
          <div className="max-w-4xl mx-auto">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-[#a1a1aa] hover:text-[#dc2626] transition-colors duration-200 mb-8"
            >
              <ArrowLeft className="w-4 h-4" strokeWidth={2.5} />
              <span className="text-sm font-medium uppercase tracking-wider">
                {t('Ana Sayfaya Dön', 'Back to Home')}
              </span>
            </Link>

            <div className="mb-12">
              <div className="w-16 h-1 bg-[#dc2626] mb-6"></div>
              <h1 className="text-4xl md:text-5xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                {t('AYDINLATMA METNİ', 'DISCLOSURE TEXT')}
              </h1>
              <p className="text-[#71717a] text-sm">
                {t(
                  'KVKK Madde 10 Kapsamında Aydınlatma Yükümlülüğü',
                  'Disclosure Obligation under KVKK Article 10'
                )}
              </p>
            </div>

            <div className="prose prose-invert max-w-none">
              <div className="bg-[#1a1a1f] border border-[#2a2a32] p-8 space-y-6">
                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('1. Veri Sorumlusu', '1. Data Controller')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      'Veri Sorumlusu: Liksus Elektrik Güç Sistemleri Ltd. Şti. (Afectus Shield)',
                      'Data Controller: Liksus Electric Power Systems Ltd. (Afectus Shield)'
                    )}
                  </p>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t('Adres: İstanbul, Türkiye', 'Address: Istanbul, Turkey')}
                  </p>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t('E-posta: info@afectusshield.com', 'Email: info@afectusshield.com')}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('2. Kişisel Verilerin Hangi Amaçla İşleneceği', '2. Purpose of Processing Personal Data')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t(
                      'Kişisel verileriniz aşağıdaki amaçlarla işlenmektedir:',
                      'Your personal data is processed for the following purposes:'
                    )}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Yıldırımdan korunma sistemleri projelendirme hizmetlerinin sunulması', 'Providing lightning protection system design services')}</li>
                    <li>{t('Teknik danışmanlık ve destek hizmetlerinin sağlanması', 'Providing technical consultancy and support services')}</li>
                    <li>{t('Sözleşme ilişkilerinin kurulması ve yönetimi', 'Establishing and managing contractual relationships')}</li>
                    <li>{t('Yasal yükümlülüklerin yerine getirilmesi', 'Fulfillment of legal obligations')}</li>
                    <li>{t('Müşteri memnuniyeti ve hizmet kalitesinin artırılması', 'Increasing customer satisfaction and service quality')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('3. İşlenen Kişisel Verilerin Kimlere Aktarılabileceği', '3. To Whom Personal Data May Be Transferred')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t(
                      'Kişisel verileriniz aşağıdaki kişi ve kuruluşlara aktarılabilir:',
                      'Your personal data may be transferred to the following persons and organizations:'
                    )}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Yasal düzenlemeler gereği resmi merciler', 'Official authorities as required by legal regulations')}</li>
                    <li>{t('Hizmet sağlayıcılar (teknik altyapı, depolama)', 'Service providers (technical infrastructure, storage)')}</li>
                    <li>{t('İş ortakları (proje bazlı)', 'Business partners (project-based)')}</li>
                    <li>{t('Elektrik Mühendisleri Odası (EMO)', 'Chamber of Electrical Engineers (EMO)')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('4. Kişisel Veri Toplamanın Yöntemi ve Hukuki Sebebi', '4. Method and Legal Basis of Personal Data Collection')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t(
                      'Kişisel verileriniz:',
                      'Your personal data:'
                    )}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Web sitesi iletişim formu', 'Website contact form')}</li>
                    <li>{t('E-posta ve telefon iletişimi', 'Email and phone communication')}</li>
                    <li>{t('Sözleşme ve teknik dökümanlar', 'Contracts and technical documents')}</li>
                    <li>{t('Ziyaret kayıtları', 'Visit records')}</li>
                  </ul>
                  <p className="text-[#a1a1aa] leading-relaxed mt-3">
                    {t(
                      'yoluyla otomatik veya otomatik olmayan yöntemlerle toplanmakta ve KVKK\'nın 5. ve 6. maddelerinde belirtilen hukuki sebeplere dayalı olarak işlenmektedir.',
                      'are collected through automatic or non-automatic methods and processed based on the legal grounds specified in Articles 5 and 6 of the KVKK.'
                    )}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('5. Haklarınız', '5. Your Rights')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t(
                      'KVKK Madde 11 kapsamında aşağıdaki haklara sahipsiniz:',
                      'Under KVKK Article 11, you have the following rights:'
                    )}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Kişisel verilerinizin işlenip işlenmediğini öğrenme', 'Learning whether your personal data is processed')}</li>
                    <li>{t('Kişisel verileriniz işlenmişse buna ilişkin bilgi talep etme', 'Requesting information if your personal data has been processed')}</li>
                    <li>{t('Kişisel verilerin işlenme amacını ve bunların amacına uygun kullanılıp kullanılmadığını öğrenme', 'Learning the purpose of processing and whether they are used accordingly')}</li>
                    <li>{t('Kişisel verilerin yurt içinde veya yurt dışında aktarıldığı üçüncü kişileri bilme', 'Knowing third parties to whom personal data is transferred domestically or abroad')}</li>
                    <li>{t('Kişisel verilerin eksik veya yanlış işlenmiş olması hâlinde bunların düzeltilmesini isteme', 'Requesting correction if personal data is incomplete or incorrect')}</li>
                    <li>{t('KVKK\'nın 7. maddesinde öngörülen şartlar çerçevesinde kişisel verilerin silinmesini veya yok edilmesini isteme', 'Requesting deletion or destruction of personal data under the conditions stipulated in Article 7 of the KVKK')}</li>
                  </ul>
                </section>
              </div>
            </div>

            <p className="text-[#71717a] text-xs mt-8 text-center">
              {t('Son Güncelleme: Şubat 2026', 'Last Updated: February 2026')}
            </p>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}