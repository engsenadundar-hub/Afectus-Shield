import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { SEO } from '../components/SEO';
import { PageHeader } from '../components/PageHeader';
import { Shield, Users, Award, Target, CheckCircle2, Box } from 'lucide-react';

export function AboutPage() {
  const { t, language } = useLanguage();

  const stats = [
    { value: '15+', labelTr: 'Yıllık Mühendislik Tecrübesi', labelEn: 'Years of Engineering' },
    { value: '50+', labelTr: 'Tamamlanan Proje', labelEn: 'Completed Projects' },
    { value: '30+', labelTr: 'Referans Müşteri', labelEn: 'Reference Clients' },
    { value: '24/7', labelTr: 'Teknik Destek', labelEn: 'Technical Support' },
  ];

  const values = [
    {
      icon: Shield,
      titleTr: 'Güvenlik Öncelikli',
      titleEn: 'Safety First',
      descTr: 'Tüm projelerimizde güvenlik standartlarına tam uyum sağlıyoruz.',
      descEn: 'We ensure full compliance with safety standards in all our projects.',
    },
    {
      icon: Box,
      titleTr: '3D Modelleme Teknolojisi',
      titleEn: '3D Modeling Technology',
      descTr: 'İleri düzey yazılımlarla 3D modelleme ve yuvarlanan küre metodu uyguluyoruz.',
      descEn: 'We apply 3D modeling and rolling sphere method with advanced software.',
    },
    {
      icon: Award,
      titleTr: 'Mükemmellik',
      titleEn: 'Excellence',
      descTr: 'Uluslararası standartlarda kaliteli hizmet sunuyoruz.',
      descEn: 'We deliver quality service at international standards.',
    },
    {
      icon: Users,
      titleTr: 'Müşteri Odaklı',
      titleEn: 'Customer Focused',
      descTr: 'Müşteri memnuniyeti ve uzun vadeli iş ortaklıkları önceliğimizdir.',
      descEn: 'Customer satisfaction and long-term partnerships are our priority.',
    },
    {
      icon: Target,
      titleTr: 'İnovasyon',
      titleEn: 'Innovation',
      descTr: 'Sürekli gelişen teknolojileri takip ediyor ve uyguluyoruz.',
      descEn: 'We follow and implement continuously evolving technologies.',
    },
  ];

  const certifications = [
    { nameTr: 'EMO Elektrik Mühendisleri Odası Üyeliği', nameEn: 'Chamber of Electrical Engineers Membership' },
    { nameTr: 'ISO 9001 Kalite Yönetim Sistemi', nameEn: 'ISO 9001 Quality Management System' },
    { nameTr: 'IEC 62305 Yetkilendirilmiş Firma', nameEn: 'IEC 62305 Authorized Company' },
    { nameTr: 'Akrediteli Laboratuvar İşbirliği', nameEn: 'Accredited Laboratory Partnership' },
  ];

  return (
    <>
      <SEO
        titleTr="Hakkımızda | İzmir Yıldırım Koruma Uzmanları - Afectus Shield"
        titleEn="About Us | Izmir Lightning Protection Experts - Afectus Shield"
        descriptionTr="15+ yıllık deneyimle İzmir'de yıldırım koruma sistemleri. IEC 62305 sertifikalı mühendisler, 500+ başarılı proje, ATEX uyumlu çözümler. Liksus Elektrik Güç Sistemleri."
        descriptionEn="Lightning protection systems in Izmir with 15+ years experience. IEC 62305 certified engineers, 500+ successful projects, ATEX compliant solutions. Liksus Elektrik Güç Sistemleri."
        canonical="/hakkimizda"
      />
      <div className="min-h-screen bg-background" style={{ position: 'relative' }}>
        <Header />
        
        {/* Hero Section */}
        <section className="relative pt-32 pb-24 border-b border-border overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img
              src="https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=1400&q=90&auto=format&fit=crop"
              alt="About Afectus Shield"
              width={800}
                  height={500}
                  loading="lazy"
                  className="w-full h-full object-cover opacity-15"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/90 via-background/95 to-background"></div>
          </div>

          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                {t('Hakkımızda', 'About Us')}
              </span>
              <h1 className="text-foreground mb-6">
                {t('Yıldırımdan Korunmada Güvenilir Ortağınız', 'Your Trusted Partner in Lightning Protection')}
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                {t(
                  'Afectus Shield olarak, endüstriyel tesislerin yıldırım risklerine karşı en üst düzeyde korunmasını sağlıyoruz.',
                  'As Afectus Shield, we ensure maximum protection of industrial facilities against lightning risks.'
                )}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="relative py-16 bg-card border-b border-border">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-5xl font-bold text-accent mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground uppercase tracking-wide">
                    {t(stat.labelTr, stat.labelEn)}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="relative py-24 bg-background">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-start">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                  {t('Hikayemiz', 'Our Story')}
                </span>
                <h2 className="text-3xl font-bold text-foreground mb-6">
                  {t('Deneyim ve Uzmanlık', 'Experience & Expertise')}
                </h2>
                
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  {t(
                    'Afectus Shield, 2010 yılından bu yana yıldırımdan korunma sistemleri alanında faaliyet göstermektedir. Elektrik mühendisliği kökenli kurucularımız, endüstriyel güvenlik alanındaki derin deneyimlerini bu şirkette bir araya getirmişlerdir.',
                    'Afectus Shield has been operating in lightning protection systems since 2010. Our founders with electrical engineering background brought together their deep experience in industrial safety in this company.'
                  )}
                </p>

                <p className="text-muted-foreground leading-relaxed">
                  {t(
                    'IEC 62305 standartlarına tam uyumlu çözümlerimizle, fabrikalardan enerji santrallerine, veri merkezlerinden telekomünikasyon tesislerine kadar geniş bir yelpazede hizmet vermekteyiz. 3D modelleme teknolojimiz ve yuvarlanan küre metodu uygulamalarımzla sektörde öncü konumdayız.',
                    'With our IEC 62305 compliant solutions, we serve a wide range from factories to power plants, data centers to telecommunication facilities. We are pioneers in the sector with our 3D modeling technology and rolling sphere method applications.'
                  )}
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="relative grid grid-rows-2 gap-4 h-[520px]"
              >
                <div className="relative overflow-hidden border border-border">
                  <img
                    src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=900&q=85&auto=format&fit=crop"
                    alt="Lightning protection installation on rooftop"
                    width={900}
                    height={260}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative overflow-hidden border border-border">
                    <img
                      src="https://images.unsplash.com/photo-1581093196277-8b9e9c5e0e5a?w=500&q=85&auto=format&fit=crop"
                      alt="Engineer risk analysis"
                      width={450}
                      height={240}
                      loading="lazy"
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent" />
                  </div>
                  <div className="relative overflow-hidden border border-border">
                    <img
                      src="https://images.unsplash.com/photo-1602193438882-fedb6b7c72b9?w=500&q=85&auto=format&fit=crop"
                      alt="Lightning rod on industrial building"
                      width={450}
                      height={240}
                      loading="lazy"
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent" />
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="relative py-24 bg-card border-t border-border">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              className="text-center mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                {t('Değerlerimiz', 'Our Values')}
              </span>
              <h2 className="text-foreground mb-6">
                {t('Çalışma Prensiplerimiz', 'Our Working Principles')}
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="border border-border bg-background p-8 hover:border-accent transition-all duration-300"
                >
                  <value.icon className="w-12 h-12 text-accent mb-6" strokeWidth={2} />
                  <h3 className="text-xl font-semibold text-foreground mb-4">
                    {t(value.titleTr, value.titleEn)}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t(value.descTr, value.descEn)}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Certifications Section */}
        <section className="relative py-24 bg-background border-t border-border">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              className="text-center mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                {t('Sertifikalar', 'Certifications')}
              </span>
              <h2 className="text-foreground mb-6">
                {t('Belgeler ve Standartlar', 'Certificates & Standards')}
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-4">
              {certifications.map((cert, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-center gap-4 border border-border bg-card p-6 hover:border-accent transition-all duration-300"
                >
                  <CheckCircle2 className="w-6 h-6 text-accent flex-shrink-0" strokeWidth={2.5} />
                  <span className="text-foreground">
                    {t(cert.nameTr, cert.nameEn)}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}