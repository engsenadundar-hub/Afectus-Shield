import { Link } from 'react-router';
import { useLanguage } from '../contexts/LanguageContext';
import { SEO } from '../components/SEO';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { ArrowLeft } from 'lucide-react';

export function CookiePolicyPage() {
  const { t } = useLanguage();

  return (
    <>
      <SEO />
      <div className="min-h-screen bg-[#0f0f12]" style={{ position: 'relative' }}>
        <Header />
        
        <main className="py-24 px-6">
          <div className="max-w-4xl mx-auto">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-[#a1a1aa] hover:text-[#dc2626] transition-colors duration-200 mb-8"
            >
              <ArrowLeft className="w-4 h-4" strokeWidth={2.5} />
              <span className="text-sm font-medium uppercase tracking-wider">
                {t('Ana Sayfaya Dön', 'Back to Home')}
              </span>
            </Link>

            <div className="mb-12">
              <div className="w-16 h-1 bg-[#dc2626] mb-6"></div>
              <h1 className="text-4xl md:text-5xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                {t('ÇEREZ POLİTİKASI', 'COOKIE POLICY')}
              </h1>
            </div>

            <div className="prose prose-invert max-w-none">
              <div className="bg-[#1a1a1f] border border-[#2a2a32] p-8 space-y-6">
                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('1. Çerez Nedir?', '1. What Are Cookies?')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      'Çerezler, ziyaret ettiğiniz web siteleri tarafından tarayıcınız aracılığıyla cihazınıza yerleştirilen küçük metin dosyalarıdır. Çerezler, web sitelerinin daha verimli çalışmasını sağlar ve site sahiplerine bilgi sağlar.',
                      'Cookies are small text files placed on your device by websites you visit through your browser. Cookies enable websites to work more efficiently and provide information to site owners.'
                    )}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('2. Kullanılan Çerez Türleri', '2. Types of Cookies Used')}
                  </h2>
                  
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-bold text-[#d4d4d8] mb-2">
                        {t('Zorunlu Çerezler', 'Necessary Cookies')}
                      </h3>
                      <p className="text-[#a1a1aa] leading-relaxed">
                        {t(
                          'Web sitesinin düzgün çalışması için gereklidir. Bu çerezler olmadan site bazı özelliklerini kullanamaz.',
                          'Necessary for the website to function properly. Without these cookies, the site cannot use some of its features.'
                        )}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-[#d4d4d8] mb-2">
                        {t('Performans Çerezleri', 'Performance Cookies')}
                      </h3>
                      <p className="text-[#a1a1aa] leading-relaxed">
                        {t(
                          'Ziyaretçilerin siteyi nasıl kullandığı hakkında bilgi toplar. Bu veriler, site deneyimini iyileştirmek için kullanılır.',
                          'Collects information about how visitors use the site. This data is used to improve the site experience.'
                        )}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-[#d4d4d8] mb-2">
                        {t('İşlevsel Çerezler', 'Functional Cookies')}
                      </h3>
                      <p className="text-[#a1a1aa] leading-relaxed">
                        {t(
                          'Tercihlerinizi hatırlar (dil seçimi gibi) ve kişiselleştirilmiş özellikler sunar.',
                          'Remembers your preferences (such as language selection) and provides personalized features.'
                        )}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-lg font-bold text-[#d4d4d8] mb-2">
                        {t('Analitik Çerezler', 'Analytics Cookies')}
                      </h3>
                      <p className="text-[#a1a1aa] leading-relaxed">
                        {t(
                          'Web sitesi trafiğini ve kullanıcı davranışlarını analiz etmek için kullanılır.',
                          'Used to analyze website traffic and user behavior.'
                        )}
                      </p>
                    </div>
                  </div>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('3. Çerezlerin Kullanım Amaçları', '3. Purposes of Cookie Usage')}
                  </h2>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Web sitesinin düzgün çalışmasını sağlamak', 'Ensuring the website functions properly')}</li>
                    <li>{t('Kullanıcı deneyimini iyileştirmek', 'Improving user experience')}</li>
                    <li>{t('Dil tercihlerini hatırlamak', 'Remembering language preferences')}</li>
                    <li>{t('Site trafiğini ve kullanımını analiz etmek', 'Analyzing site traffic and usage')}</li>
                    <li>{t('Güvenlik önlemlerini sağlamak', 'Providing security measures')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('4. Çerezleri Yönetme', '4. Managing Cookies')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t(
                      'Çerezleri kontrol etmek veya silmek için tarayıcı ayarlarınızı kullanabilirsiniz. Çoğu tarayıcı çerezleri otomatik olarak kabul eder, ancak bu ayarları değiştirebilirsiniz:',
                      'You can use your browser settings to control or delete cookies. Most browsers automatically accept cookies, but you can change these settings:'
                    )}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('Tarayıcı ayarlarından çerezleri devre dışı bırakma', 'Disabling cookies from browser settings')}</li>
                    <li>{t('Mevcut çerezleri silme', 'Deleting existing cookies')}</li>
                    <li>{t('Çerez kullanımı konusunda uyarı alma', 'Receiving warnings about cookie usage')}</li>
                  </ul>
                  <p className="text-[#a1a1aa] leading-relaxed mt-3">
                    {t(
                      'Not: Çerezleri devre dışı bırakmak, web sitesinin bazı işlevlerini etkileyebilir.',
                      'Note: Disabling cookies may affect some functions of the website.'
                    )}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('5. Üçüncü Taraf Çerezler', '5. Third-Party Cookies')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      'Web sitemiz, analiz ve performans iyileştirme amacıyla üçüncü taraf hizmet sağlayıcıların çerezlerini kullanabilir. Bu çerezler, ilgili üçüncü tarafların gizlilik politikalarına tabidir.',
                      'Our website may use third-party service provider cookies for analysis and performance improvement purposes. These cookies are subject to the privacy policies of the respective third parties.'
                    )}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('6. Güncelleme', '6. Updates')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      'Bu Çerez Politikası zaman zaman güncellenebilir. Değişiklikler bu sayfada yayınlanacaktır.',
                      'This Cookie Policy may be updated from time to time. Changes will be published on this page.'
                    )}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('7. İletişim', '7. Contact')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t(
                      'Çerez politikamız hakkında sorularınız için: info@afectusshield.com',
                      'For questions about our cookie policy: info@afectusshield.com'
                    )}
                  </p>
                </section>
              </div>
            </div>

            <p className="text-[#71717a] text-xs mt-8 text-center">
              {t('Son Güncelleme: Şubat 2026', 'Last Updated: February 2026')}
            </p>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}