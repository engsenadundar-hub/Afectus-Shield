import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Link } from 'react-router';
import { Header } from '../components/Header';
import { QuoteForm } from '../components/QuoteForm';
import { Footer } from '../components/Footer';
import { SEO } from '../components/SEO';
import { FileSearch, PenTool, Wrench, ClipboardCheck, ShieldAlert, ArrowRight } from 'lucide-react';

export function ServicesOverviewPage() {
  const { t } = useLanguage();

  const services = [
    {
      icon: FileSearch,
      titleTr: 'Risk Analizi',
      titleEn: 'Risk Analysis',
      slug: 'risk-analizi',
      descTr: 'IEC 62305 standardına göre kapsamlı risk değerlendirmesi ve raporlama.',
      descEn: 'Comprehensive risk assessment and reporting according to IEC 62305 standard.',
      features: [
        { tr: 'Tesis bazlı risk analizi', en: 'Facility-based risk analysis' },
        { tr: 'IEC 62305-2 uyumlu hesaplamalar', en: 'IEC 62305-2 compliant calculations' },
        { tr: 'Detaylı raporlama', en: 'Detailed reporting' },
      ],
      image: 'https://images.unsplash.com/photo-1581093196277-8b9e9c5e0e5a?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: PenTool,
      titleTr: 'Mühendislik Tasarımı',
      titleEn: 'Engineering Design',
      slug: 'muhendislik-tasarimi',
      descTr: 'Tesise özel yıldırımdan korunma sistemi mühendislik projeleri.',
      descEn: 'Facility-specific lightning protection system engineering projects.',
      features: [
        { tr: 'Özel sistem tasarımı', en: 'Custom system design' },
        { tr: '3D modelleme ve simülasyon', en: '3D modeling and simulation' },
        { tr: 'Proje onay süreçleri', en: 'Project approval processes' },
      ],
      image: 'https://images.unsplash.com/photo-1453023795691-9b2b92a39c9e?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: Wrench,
      titleTr: 'Uygulama ve Montaj',
      titleEn: 'Implementation & Installation',
      slug: 'uygulama-montaj',
      descTr: 'Sertifikalı ekip ile profesyonel sistem kurulumu ve entegrasyon.',
      descEn: 'Professional system setup and integration with certified team.',
      features: [
        { tr: 'Sertifikalı montaj ekibi', en: 'Certified installation team' },
        { tr: 'Kaliteli malzeme garantisi', en: 'Quality material guarantee' },
        { tr: 'Anahtar teslim çözümler', en: 'Turnkey solutions' },
      ],
      image: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: ClipboardCheck,
      titleTr: 'Test ve Raporlama',
      titleEn: 'Testing & Reporting',
      slug: 'test-raporlama',
      descTr: 'Akrediteli laboratuvar ölçümleri ve belgelendirme süreçleri.',
      descEn: 'Accredited laboratory measurements and certification processes.',
      features: [
        { tr: 'Topraklama direnci ölçümü', en: 'Grounding resistance measurement' },
        { tr: 'Süreklilik testleri', en: 'Continuity tests' },
        { tr: 'Resmi belgelendirme', en: 'Official certification' },
      ],
      image: 'https://images.unsplash.com/photo-1581093450021-4a7360e9c6e3?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: ShieldAlert,
      titleTr: 'Periyodik Bakım',
      titleEn: 'Periodic Maintenance',
      slug: 'periyodik-bakim',
      descTr: 'Yıllık kontrol, ölçüm ve sistem güncelleme hizmetleri.',
      descEn: 'Annual inspection, measurement and system update services.',
      features: [
        { tr: 'Yıllık bakım kontratları', en: 'Annual maintenance contracts' },
        { tr: 'Sistem performans analizi', en: 'System performance analysis' },
        { tr: '7/24 acil destek', en: '24/7 emergency support' },
      ],
      image: 'https://images.unsplash.com/photo-1565814636199-ae8133055c1c?w=800&q=85&auto=format&fit=crop',
    },
  ];

  return (
    <>
      <SEO
        titleTr="Yıldırım Koruma Hizmetleri | Risk Analizi & Paratoner Montajı İzmir"
        titleEn="Lightning Protection Services | Risk Analysis & Installation Izmir"
        descriptionTr="İzmir'de IEC 62305:2024 standartlarında risk analizi, paratoner sistem tasarımı, montaj, periyodik kontrol, SPD kurulumu ve topraklama hizmetleri. Uygun fiyat, hızlı kurulum."
        descriptionEn="Risk analysis, lightning rod system design, installation, periodic inspection, SPD setup and grounding services per IEC 62305:2024 in Izmir. Competitive pricing, fast installation."
        canonical="/hizmetler"
      />
      <div className="min-h-screen bg-background" style={{ position: 'relative' }}>
        <Header />
        
        {/* Hero Section */}
        <section className="relative pt-32 pb-24 border-b border-border">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                {t('Hizmetlerimiz', 'Our Services')}
              </span>
              <h1 className="text-foreground mb-6">
                {t('Uçtan Uca Yıldırımdan Korunma Çözümleri', 'End-to-End Lightning Protection Solutions')}
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                {t(
                  'Risk analizinden periyodik bakıma kadar tüm süreçlerde profesyonel destek sunuyoruz.',
                  'We provide professional support throughout all processes from risk analysis to periodic maintenance.'
                )}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="relative py-24">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid gap-12">
              {services.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className={`grid lg:grid-cols-2 gap-8 items-center ${
                    index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                    <div className="border border-border overflow-hidden h-96">
                      <img
                        src={service.image}
                        alt={t(service.titleTr, service.titleEn)}
                        width={800}
                  height={500}
                  loading="lazy"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  </div>

                  <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                    <div className="w-16 h-16 flex items-center justify-center border border-border mb-6">
                      <service.icon className="w-8 h-8 text-accent" strokeWidth={2.5} />
                    </div>
                    
                    <h2 className="text-3xl font-bold text-foreground mb-4 uppercase tracking-wide">
                      {t(service.titleTr, service.titleEn)}
                    </h2>
                    
                    <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                      {t(service.descTr, service.descEn)}
                    </p>

                    <ul className="space-y-3 mb-8">
                      {service.features.map((feature, fIndex) => (
                        <li key={fIndex} className="flex items-start gap-3">
                          <div className="w-1.5 h-1.5 bg-accent mt-2 flex-shrink-0"></div>
                          <span className="text-foreground">{t(feature.tr, feature.en)}</span>
                        </li>
                      ))}
                    </ul>

                    <Link
                      to={`/hizmetler/${service.slug}`}
                      className="inline-flex items-center gap-3 border-2 border-border text-foreground px-6 py-3 font-semibold uppercase tracking-wide transition-all duration-200 hover:border-accent hover:text-accent hover:-translate-y-1"
                    >
                      {t('Detaylı Bilgi', 'Learn More')}
                      <ArrowRight className="w-5 h-5" strokeWidth={2.5} />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <QuoteForm />
        <Footer />
      </div>
    </>
  );
}