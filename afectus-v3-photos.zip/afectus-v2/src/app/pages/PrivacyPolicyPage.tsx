import { Link } from 'react-router';
import { useI18n } from '../contexts/LanguageContext';
import { SEO } from '../components/SEO';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { ArrowLeft } from 'lucide-react';

export function PrivacyPolicyPage() {
  const { t } = useI18n();

  return (
    <>
      <SEO />
      <div className="min-h-screen bg-[#0f0f12]" style={{ position: 'relative' }}>
        <Header />
        
        <main className="py-24 px-6">
          <div className="max-w-4xl mx-auto">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-[#a1a1aa] hover:text-[#dc2626] transition-colors duration-200 mb-8"
            >
              <ArrowLeft className="w-4 h-4" strokeWidth={2.5} />
              <span className="text-sm font-medium uppercase tracking-wider">
                {t('common.backToHome')}
              </span>
            </Link>

            <div className="mb-12">
              <div className="w-16 h-1 bg-[#dc2626] mb-6"></div>
              <h1 className="text-4xl md:text-5xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                {t('footer.legal.privacy')}
              </h1>
            </div>

            <div className="prose prose-invert max-w-none">
              <div className="bg-[#1a1a1f] border border-[#2a2a32] p-8 space-y-6">
                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('privacy.section1.title')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t('privacy.section1.content')}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('privacy.section2.title')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed mb-3">
                    {t('privacy.section2.intro')}
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('privacy.section2.item1')}</li>
                    <li>{t('privacy.section2.item2')}</li>
                    <li>{t('privacy.section2.item3')}</li>
                    <li>{t('privacy.section2.item4')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('privacy.section3.title')}
                  </h2>
                  <ul className="list-disc list-inside space-y-2 text-[#a1a1aa]">
                    <li>{t('privacy.section3.item1')}</li>
                    <li>{t('privacy.section3.item2')}</li>
                    <li>{t('privacy.section3.item3')}</li>
                    <li>{t('privacy.section3.item4')}</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('privacy.section4.title')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t('privacy.section4.content')}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('privacy.section5.title')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t('privacy.section5.content')}
                  </p>
                </section>

                <section>
                  <h2 className="text-2xl font-bold text-[#d4d4d8] uppercase tracking-tight mb-4">
                    {t('privacy.section6.title')}
                  </h2>
                  <p className="text-[#a1a1aa] leading-relaxed">
                    {t('privacy.section6.content')}
                  </p>
                </section>
              </div>
            </div>

            <p className="text-[#71717a] text-xs mt-8 text-center">
              {t('privacy.lastUpdated')}
            </p>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}