import { useI18n } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Shield, Zap } from 'lucide-react';

export function LPLLevelsSection() {
  const { t } = useI18n();

  const lplLevels = [
    {
      level: 'I',
      index: 0,
      colorClass: 'from-red-600 to-red-700',
      textColor: 'text-red-500',
      borderColor: 'border-red-500',
      glowColor: 'rgba(239, 68, 68, 0.3)',
    },
    {
      level: 'II',
      index: 1,
      colorClass: 'from-red-600 to-red-700',
      textColor: 'text-accent',
      borderColor: 'border-accent',
      glowColor: 'rgba(230, 57, 70, 0.3)',
    },
    {
      level: 'III',
      index: 2,
      colorClass: 'from-yellow-500 to-yellow-600',
      textColor: 'text-yellow-500',
      borderColor: 'border-yellow-500',
      glowColor: 'rgba(234, 179, 8, 0.3)',
    },
    {
      level: 'IV',
      index: 3,
      colorClass: 'from-green-500 to-green-600',
      textColor: 'text-green-500',
      borderColor: 'border-green-500',
      glowColor: 'rgba(34, 197, 94, 0.3)',
    },
  ];

  return (
    <section className="relative py-24 bg-background overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl"
          animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Header */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
            {t('lplLevels.title')}
          </span>
          <h2 className="text-foreground mb-6">
            {t('lplLevels.heading')}
          </h2>
          <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            {t('lplLevels.description')}
          </p>
        </motion.div>

        {/* LPL Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {lplLevels.map((lpl, index) => (
            <motion.div
              key={lpl.level}
              className="relative group"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              {/* Card */}
              <div className="relative border border-border bg-card p-6 transition-all duration-300 group-hover:border-accent group-hover:-translate-y-2 min-h-[280px] flex flex-col">
                {/* Glow effect on hover */}
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl"
                  style={{ backgroundColor: lpl.glowColor }}
                />

                {/* Content */}
                <div className="relative z-10">
                  {/* Level badge */}
                  <div
                    className={`inline-flex items-center gap-2 px-4 py-2 mb-4 bg-gradient-to-r ${lpl.colorClass} text-white font-bold`}
                  >
                    <Shield className="w-4 h-4" strokeWidth={2.5} />
                    <span className="uppercase tracking-wider text-sm">
                      {t(`lplLevels.levels.${lpl.index}.level`)}
                    </span>
                  </div>

                  {/* Risk level */}
                  <h3 className="text-foreground mb-2 text-lg">
                    {t(`lplLevels.levels.${lpl.index}.risk`)}
                  </h3>

                  {/* Current rating */}
                  <div className="flex items-center gap-2 mb-4">
                    <Zap className="w-5 h-5 text-accent" strokeWidth={2.5} />
                    <span className="text-muted-foreground font-bold">
                      {t(`lplLevels.levels.${lpl.index}.current`)}
                    </span>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground/80 leading-relaxed">
                    {t(`lplLevels.levels.${lpl.index}.desc`)}
                  </p>
                </div>

                {/* Bottom accent line */}
                <div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${lpl.colorClass} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300`}
                />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Rolling Sphere Method Explanation */}
        <motion.div
          className="border border-border bg-card p-8 relative overflow-hidden"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          {/* Background accent */}
          <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-accent to-transparent" />

          <div className="relative z-10 ml-4">
            <h3 className="text-xl font-bold text-foreground mb-6">
              {t('lplLevels.protectionMethodsTitle')}
            </h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              {[0, 1, 2].map((index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-accent/10 border border-accent flex items-center justify-center flex-shrink-0">
                    <Shield className="w-5 h-5 text-accent" strokeWidth={2.5} />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground mb-1">
                      {t(`lplLevels.methods.${index}.name`)}
                    </p>
                    <div className="text-sm text-muted-foreground/80">
                      {t('lplLevels.rollingSphereLegend')} {t(`lplLevels.methods.${index}.radius`)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}