import { useI18n } from '../contexts/LanguageContext';
import { Link } from 'react-router';
import { ArrowRight, Phone } from 'lucide-react';
import { motion } from 'motion/react';

export function ContactCTA() {
  const { t } = useI18n();

  return (
    <section className="relative py-24 overflow-hidden bg-gradient-to-br from-ink-950 via-background to-ink-950">
      {/* Decorative Elements */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(to right, #E63946 1px, transparent 1px),
              linear-gradient(to bottom, #E63946 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {/* Badge */}
          <div className="inline-block mb-6 px-4 py-2 bg-accent/10 border border-accent">
            <span className="text-accent font-medium text-xs uppercase" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
              {t('cta.contact')}
            </span>
          </div>

          {/* Title */}
          <h2 className="text-foreground mb-6">
            {t('cta.title')}
          </h2>

          {/* Description */}
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
            {t('cta.description')}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/iletisim"
              className="group inline-flex items-center justify-center gap-3 bg-accent text-white px-8 py-4 font-semibold transition-all duration-300 hover:bg-[#B91C2C] hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0"
            >
              <span>{t('cta.button')}</span>
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" strokeWidth={2.5} />
            </Link>

            <a
              href="tel:+905537206972"
              className="inline-flex items-center justify-center gap-3 border-2 border-accent text-accent px-8 py-4 font-semibold transition-all duration-300 hover:bg-accent hover:text-white hover:-translate-y-0.5 active:translate-y-0"
            >
              <Phone className="w-5 h-5" strokeWidth={2.5} />
              <span>0553 720 69 72</span>
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}