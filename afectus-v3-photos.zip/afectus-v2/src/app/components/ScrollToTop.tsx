import { useLayoutEffect } from 'react';
import { useLocation } from 'react-router';

export function ScrollToTop() {
  const { pathname } = useLocation();

  useLayoutEffect(() => {
    // Force scroll to top BEFORE paint - more aggressive
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    
    // Also use window.scrollTo as backup
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}