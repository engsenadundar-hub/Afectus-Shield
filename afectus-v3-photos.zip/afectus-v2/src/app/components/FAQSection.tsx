import { useI18n } from '../contexts/LanguageContext';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus } from 'lucide-react';

export function FAQSection() {
  const { t, language } = useI18n();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = t('faq.questions', { returnObjects: true }) as Array<{
    question: string;
    answer: string;
  }>;

  return (
    <section className="relative py-24 bg-background">
      <div className="max-w-4xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-block mb-4 px-4 py-2 bg-accent/10 border border-accent">
              <span className="text-accent font-medium text-xs uppercase" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                FAQ
              </span>
            </div>
            <h2 className="text-foreground mb-4">
              {t('faq.title')}
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              {t('faq.subtitle')}
            </p>
          </motion.div>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="border border-border bg-card overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between gap-4 p-6 text-left hover:bg-accent/5 transition-colors duration-200"
              >
                <span className="font-semibold text-foreground pr-8">
                  {faq.question}
                </span>
                <div className="flex-shrink-0 w-8 h-8 border border-accent flex items-center justify-center">
                  {openIndex === index ? (
                    <Minus className="w-5 h-5 text-accent" strokeWidth={2.5} />
                  ) : (
                    <Plus className="w-5 h-5 text-accent" strokeWidth={2.5} />
                  )}
                </div>
              </button>

              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6 text-muted-foreground leading-relaxed border-t border-border pt-6">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}