import { useState } from 'react';
import { useI18n } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Search, Ruler, Wrench, ClipboardCheck, Box } from 'lucide-react';

export function ProcessSection() {
  const { t } = useI18n();
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const steps = [
    { icon: Search, index: 0 },
    { icon: Ruler, index: 1 },
    { icon: Wrench, index: 2 },
    { icon: ClipboardCheck, index: 3 },
  ];

  return (
    <section id="process" className="relative py-24 bg-background border-t border-border">
      {/* Background geometric pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-32 h-32 border border-accent rotate-45"></div>
        <div className="absolute bottom-20 right-20 w-40 h-40 border border-accent rotate-12"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
            {t('processSection.title')}
          </span>
          <h2 className="text-foreground">
            {t('processSection.heading')}
          </h2>
        </motion.div>

        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-20 left-0 right-0 h-0.5 bg-border">
            <motion.div
              className="h-full bg-accent"
              initial={{ width: '0%' }}
              whileInView={{ width: '100%' }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 1.5, delay: 0.5 }}
            />
          </div>

          {/* Progress Dots */}
          <div className="hidden lg:flex absolute top-[76px] left-0 right-0 justify-between px-[12.5%]">
            {steps.map((_, index) => (
              <motion.div
                key={`dot-${index}`}
                className={`w-4 h-4 border-2 transition-all duration-300 ${
                  hoveredIndex === index
                    ? 'bg-accent border-accent scale-125 shadow-[0_0_12px_rgba(230,57,70,0.6)]'
                    : 'bg-card border-accent'
                }`}
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
              />
            ))}
          </div>

          {/* Steps */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                className="group relative"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div className="relative bg-card border border-border p-8 transition-all duration-300 hover:border-accent hover:-translate-y-1">
                  {/* Animated grid on hover */}
                  <div
                    className="absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-5"
                    style={{
                      backgroundImage: `
                        linear-gradient(to right, #E63946 1px, transparent 1px),
                        linear-gradient(to bottom, #E63946 1px, transparent 1px)
                      `,
                      backgroundSize: '20px 20px',
                    }}
                  />

                  <div className="relative">
                    {/* Step Number */}
                    <div className="absolute -top-4 -left-4 w-12 h-12 bg-accent text-white flex items-center justify-center font-bold border-2 border-card" style={{ fontFamily: "Barlow Condensed, sans-serif", fontSize: "1.3rem", letterSpacing: "0.02em" }}>
                      {index + 1}
                    </div>

                    {/* Icon */}
                    <div className="mb-6 mt-4">
                      <div className="w-16 h-16 border border-border flex items-center justify-center transition-all duration-300 group-hover:border-accent">
                        <step.icon
                          className="w-8 h-8 text-muted-foreground transition-colors duration-300 group-hover:text-accent"
                          strokeWidth={2}
                        />
                      </div>
                    </div>

                    {/* Title */}
                    <h3
                      className={`text-lg font-semibold mb-3 transition-colors duration-300 ${
                        hoveredIndex === index ? 'text-accent' : 'text-foreground'
                      }`}
                    >
                      {t(`processSection.steps.${index}.title`)}
                    </h3>

                    {/* Description */}
                    <p className="text-center text-sm text-muted-foreground mb-4">
                      {t(`processSection.steps.${index}.desc`)}
                    </p>

                    {/* Details (visible on hover) */}
                    <motion.div
                      className="overflow-hidden"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{
                        height: hoveredIndex === index ? 'auto' : 0,
                        opacity: hoveredIndex === index ? 1 : 0,
                      }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="pt-4 border-t border-border">
                        <Box className="w-5 h-5 text-accent mx-auto mb-2" strokeWidth={2} />
                        <p className="text-xs text-muted-foreground/80 text-center leading-relaxed">
                          {t(`processSection.steps.${index}.details`)}
                        </p>
                      </div>
                    </motion.div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}