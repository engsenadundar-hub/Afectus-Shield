import { useState } from 'react';
import { useI18n, useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { XCircle, CheckCircle, User } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function InteractiveProblemSolution() {
  const { t } = useI18n();
  const { language } = useLanguage();
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const problems = [
    {
      titleKey: 'interactiveProblemSolution.problems.items.0.title',
      descKey: 'interactiveProblemSolution.problems.items.0.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.problems.items.1.title',
      descKey: 'interactiveProblemSolution.problems.items.1.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.problems.items.2.title',
      descKey: 'interactiveProblemSolution.problems.items.2.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.problems.items.3.title',
      descKey: 'interactiveProblemSolution.problems.items.3.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.problems.items.4.title',
      descKey: 'interactiveProblemSolution.problems.items.4.desc',
    },
  ];

  const solutions = [
    {
      titleKey: 'interactiveProblemSolution.solutions.items.0.title',
      descKey: 'interactiveProblemSolution.solutions.items.0.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.solutions.items.1.title',
      descKey: 'interactiveProblemSolution.solutions.items.1.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.solutions.items.2.title',
      descKey: 'interactiveProblemSolution.solutions.items.2.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.solutions.items.3.title',
      descKey: 'interactiveProblemSolution.solutions.items.3.desc',
    },
    {
      titleKey: 'interactiveProblemSolution.solutions.items.4.title',
      descKey: 'interactiveProblemSolution.solutions.items.4.desc',
    },
  ];

  return (
    <section id="problem-solution" className="relative py-16 sm:py-24 bg-border/30 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <motion.div
          className="text-center mb-12 sm:mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
            {t('interactiveProblemSolution.subtitle')}
          </span>
          <h2 className="text-foreground mb-4 text-2xl sm:text-3xl md:text-4xl lg:text-5xl">
            {t('interactiveProblemSolution.title')}
          </h2>
        </motion.div>

        {/* Interactive Grid - Two Columns Side by Side */}
        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 mb-12 sm:mb-16 items-start">
          {/* Left Column - Problems */}
          <div className="h-full">
            <motion.div
              className="flex items-center gap-3 mb-6 sm:mb-8"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <XCircle className="w-6 sm:w-8 h-6 sm:h-8 text-red-600 flex-shrink-0" strokeWidth={2.5} />
              <h3 className="text-xl sm:text-2xl font-bold text-foreground">
                {t('interactiveProblemSolution.problems.heading')}
              </h3>
            </motion.div>

            <div className="space-y-3 sm:space-y-4">
              {problems.map((problem, index) => (
                <motion.div
                  key={`problem-${index}`}
                  className={`group border-l-4 bg-card p-4 sm:p-6 transition-all duration-300 cursor-pointer min-h-[100px] sm:min-h-[120px] flex items-start ${
                    hoveredIndex === index 
                      ? 'border-red-600 shadow-lg shadow-red-600/20' 
                      : 'border-red-600/30 hover:border-red-600/50'
                  }`}
                  onMouseEnter={() => setHoveredIndex(index)}
                  onMouseLeave={() => setHoveredIndex(null)}
                  onTouchStart={() => setHoveredIndex(index)}
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex items-start gap-2 sm:gap-3 w-full">
                    <XCircle 
                      className={`w-5 sm:w-6 h-5 sm:h-6 flex-shrink-0 mt-1 transition-all duration-300 ${
                        hoveredIndex === index ? 'text-red-600 scale-110' : 'text-red-600/70'
                      }`} 
                      strokeWidth={2.5} 
                    />
                    <div className="flex-1">
                      <h4 className={`font-bold mb-1 sm:mb-2 text-sm sm:text-base transition-colors duration-300 ${
                        hoveredIndex === index ? 'text-red-600' : 'text-foreground'
                      }`}>
                        {t(problem.titleKey)}
                      </h4>
                      <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                        {t(problem.descKey)}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right Column - Solutions */}
          <div className="h-full">
            <motion.div
              className="flex items-center gap-3 mb-6 sm:mb-8"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <CheckCircle className="w-6 sm:w-8 h-6 sm:h-8 text-green-600 flex-shrink-0" strokeWidth={2.5} />
              <h3 className="text-xl sm:text-2xl font-bold text-foreground">
                {t('interactiveProblemSolution.solutions.heading')}
              </h3>
            </motion.div>

            <div className="space-y-3 sm:space-y-4">
              {solutions.map((solution, index) => (
                <motion.div
                  key={`solution-${index}`}
                  className={`group border-l-4 bg-card p-4 sm:p-6 transition-all duration-300 cursor-pointer min-h-[100px] sm:min-h-[120px] flex items-start ${
                    hoveredIndex === index 
                      ? 'border-green-600 shadow-lg shadow-green-600/20' 
                      : 'border-green-600/30 hover:border-green-600/50'
                  }`}
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex items-start gap-2 sm:gap-3 w-full">
                    <CheckCircle 
                      className={`w-5 sm:w-6 h-5 sm:h-6 flex-shrink-0 mt-1 transition-all duration-300 ${
                        hoveredIndex === index ? 'text-green-600 scale-110' : 'text-green-600/70'
                      }`} 
                      strokeWidth={2.5} 
                    />
                    <div className="flex-1">
                      <h4 className={`font-bold mb-1 sm:mb-2 text-sm sm:text-base transition-colors duration-300 ${
                        hoveredIndex === index ? 'text-green-600' : 'text-foreground'
                      }`}>
                        {t(solution.titleKey)}
                      </h4>
                      <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                        {t(solution.descKey)}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Section - Engineer Image + CTA */}
        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 items-start">
          {/* Engineer Image */}
          <motion.div
            className="relative overflow-hidden border-2 sm:border-4 border-accent"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=600&h=800&fit=crop"
              alt={t('interactiveProblemSolution.engineerAlt')}
              className="w-full h-[350px] sm:h-[450px] lg:h-[500px] object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#0A0E1A] via-[#0A0E1A]/90 to-transparent p-4 sm:p-6">
              <div className="flex items-center gap-2 sm:gap-3 text-white">
                <User className="w-6 sm:w-8 h-6 sm:h-8 text-accent flex-shrink-0" strokeWidth={2.5} />
                <div>
                  <p className="font-bold text-base sm:text-lg">{t('interactiveProblemSolution.engineerTitle')}</p>
                  <p className="text-xs sm:text-sm text-accent">{t('interactiveProblemSolution.engineerSubtitle')}</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Free Consultation CTA */}
          <motion.div
            className="bg-accent p-6 sm:p-8 lg:p-12 h-full flex flex-col justify-center"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4 sm:mb-6">
              {t('interactiveProblemSolution.cta.title')}
            </h3>
            <p className="text-white/90 mb-6 sm:mb-8 leading-relaxed text-base sm:text-lg">
              {t('interactiveProblemSolution.cta.description')}
            </p>
            <a
              href="https://wa.me/905537206972"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-accent px-6 sm:px-10 py-3 sm:py-4 font-bold uppercase tracking-wide hover:bg-[#0A0E1A] hover:text-white transition-all duration-300 border-2 border-white hover:border-white text-center text-sm sm:text-base"
            >
              {t('interactiveProblemSolution.cta.button')}
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}