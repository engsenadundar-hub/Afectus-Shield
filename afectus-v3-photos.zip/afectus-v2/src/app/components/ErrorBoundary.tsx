import { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
}

class ErrorBoundaryClass extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log error to console (in production, send to error tracking service like Sentry)
    console.error('Error Boundary caught an error:', error, errorInfo);
    
    this.setState({
      error,
      errorInfo,
    });

    // TODO: Send to error tracking service (Sentry, LogRocket, etc.)
    // logErrorToService(error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return <ErrorFallback error={this.state.error} />;
    }

    return this.props.children;
  }
}

function ErrorFallback({ error }: { error?: Error }) {
  const handleReload = () => {
    window.location.reload();
  };

  const handleGoHome = () => {
    window.location.href = '/';
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <div className="max-w-2xl w-full text-center">
        {/* Icon */}
        <div className="mb-8 flex justify-center">
          <div className="w-24 h-24 bg-accent/10 border-2 border-accent flex items-center justify-center">
            <AlertTriangle className="w-12 h-12 text-accent" strokeWidth={2.5} />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-foreground mb-4">
          Beklenmeyen Bir Hata Oluştu
        </h1>
        <h2 className="text-2xl text-muted-foreground mb-8">
          Something Went Wrong
        </h2>

        {/* Error Message (dev mode only) */}
        {process.env.NODE_ENV === 'development' && error && (
          <div className="mb-8 p-6 bg-card border border-accent/30 text-left">
            <p className="text-sm font-mono text-accent mb-2">Error Details:</p>
            <p className="text-sm font-mono text-muted-foreground break-all">
              {error.toString()}
            </p>
          </div>
        )}

        {/* Description */}
        <p className="text-muted-foreground mb-12 max-w-md mx-auto leading-relaxed">
          Üzgünüz, bir sorun oluştu. Sayfayı yenilemeyi deneyin veya ana sayfaya dönün.
          <br />
          <span className="text-sm">
            Sorry, something went wrong. Try refreshing the page or return to the homepage.
          </span>
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={handleReload}
            className="inline-flex items-center justify-center gap-2 bg-accent text-white px-8 py-4 font-semibold transition-all duration-200 hover:bg-[#B91C2C] hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0"
          >
            <RefreshCw className="w-5 h-5" strokeWidth={2.5} />
            <span>Sayfayı Yenile / Reload Page</span>
          </button>

          <button
            onClick={handleGoHome}
            className="inline-flex items-center justify-center gap-2 border-2 border-accent text-accent px-8 py-4 font-semibold transition-all duration-200 hover:bg-accent hover:text-white hover:-translate-y-0.5 active:translate-y-0"
          >
            <Home className="w-5 h-5" strokeWidth={2.5} />
            <span>Ana Sayfa / Home</span>
          </button>
        </div>

        {/* Support Info */}
        <div className="mt-12 pt-8 border-t border-border">
          <p className="text-sm text-muted-foreground mb-3">
            Sorun devam ederse bizimle iletişime geçin:
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center text-sm">
            <a
              href="mailto:info@afectusshield.com"
              className="text-accent hover:underline font-medium"
            >
              info@afectusshield.com
            </a>
            <span className="hidden sm:inline text-border">|</span>
            <a
              href="tel:+905537206972"
              className="text-accent hover:underline font-medium"
            >
              0553 720 69 72
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

// Export wrapper component
export function ErrorBoundary({ children, fallback }: Props) {
  return (
    <ErrorBoundaryClass fallback={fallback}>
      {children}
    </ErrorBoundaryClass>
  );
}
