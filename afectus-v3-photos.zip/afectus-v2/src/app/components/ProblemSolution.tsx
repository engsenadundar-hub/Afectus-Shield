import { useI18n } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { AlertTriangle, ShieldCheck, Send } from 'lucide-react';
import { Link } from 'react-router';

export function ProblemSolution() {
  const { t } = useI18n();

  const problemItems = [
    'problemSolution.problem.items.0',
    'problemSolution.problem.items.1',
    'problemSolution.problem.items.2',
    'problemSolution.problem.items.3',
  ];

  const solutionItems = [
    'problemSolution.solution.items.0',
    'problemSolution.solution.items.1',
    'problemSolution.solution.items.2',
    'problemSolution.solution.items.3',
  ];

  return (
    <section className="relative py-24 bg-background overflow-hidden">
      {/* Background image for context - Industrial facility aerial */}
      <div className="absolute inset-0 opacity-10">
        <img 
          src="https://images.unsplash.com/photo-1769148068846-7c87d89e36b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZmFjaWxpdHklMjBhZXJpYWx8ZW58MXx8fHwxNzcxMzMzODE4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Industrial facility aerial view background"
          width={1080}
          height={720}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid md:grid-cols-2 gap-12">
          {/* PROBLEM SIDE */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
          >
            {/* Problem side image - Old electrical equipment */}
            <div className="mb-6 h-64 overflow-hidden border border-accent/20">
              <img 
                src="https://images.unsplash.com/photo-1759830337357-29c472b6746c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZWxlY3RyaWNhbCUyMHRyYW5zZm9ybWVyJTIwb3V0ZG9vcnxlbnwxfHx8fDE3NzE3NzI3NjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Old industrial electrical transformer"
                width={600}
                height={256}
                className="w-full h-full object-cover grayscale"
                loading="lazy"
              />
            </div>
            
            <div className="flex items-center gap-3 mb-6">
              <AlertTriangle className="w-8 h-8 text-accent" strokeWidth={2.5} />
              <span className="text-sm font-bold text-muted-foreground uppercase tracking-wider">
                {t('problemSolution.problem.title')}
              </span>
            </div>
            <h2 className="mb-6 text-foreground">
              {t('problemSolution.problem.heading')}
            </h2>
            <ul className="space-y-4">
              {problemItems.map((itemKey, index) => (
                <li key={index} className="flex items-start gap-3 text-muted-foreground">
                  <div className="w-2 h-2 bg-accent mt-2.5 flex-shrink-0"></div>
                  <span className="leading-relaxed">{t(itemKey)}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* SOLUTION SIDE */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
          >
            {/* Solution side image - Modern system */}
            <div className="mb-6 h-64 overflow-hidden border border-accent/20">
              <img 
                src="https://images.unsplash.com/photo-1768803431559-7ed75e1ac9f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpY2FsJTIwZW5naW5lZXIlMjBpbnNwZWN0aW9uJTIwb3V0ZG9vcnxlbnwxfHx8fDE3NzE3NzI3NzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Electrical engineer performing outdoor inspection"
                width={600}
                height={256}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>

            <div className="flex items-center gap-3 mb-6">
              <ShieldCheck className="w-8 h-8 text-accent" strokeWidth={2.5} />
              <span className="text-sm font-bold text-muted-foreground uppercase tracking-wider">
                {t('problemSolution.solution.title')}
              </span>
            </div>
            <h2 className="mb-6 text-foreground">
              {t('problemSolution.solution.heading')}
            </h2>
            <ul className="space-y-4 mb-8">
              {solutionItems.map((itemKey, index) => (
                <li key={index} className="flex items-start gap-3 text-muted-foreground">
                  <div className="w-2 h-2 bg-accent mt-2.5 flex-shrink-0"></div>
                  <span className="leading-relaxed">{t(itemKey)}</span>
                </li>
              ))}
            </ul>

            {/* CTA Button */}
            <Link to="/iletisim" className="group relative inline-flex items-center justify-center gap-3 bg-accent text-white px-8 py-4 font-semibold transition-all duration-300 hover:bg-[#B91C2C] hover:shadow-xl hover:-translate-y-0.5 overflow-hidden">
              <div className="absolute inset-0 bg-white/10 transform -skew-x-12 -translate-x-full transition-transform duration-500 group-hover:translate-x-full"></div>
              <span className="relative z-10">{t('problemSolution.cta')}</span>
              <Send className="w-5 h-5 relative z-10 transition-transform duration-300 group-hover:translate-x-1" strokeWidth={2.5} />
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}