import { motion } from 'motion/react';
import { useI18n } from '../contexts/LanguageContext';
import { Factory, Zap, Building2, Server, FlaskConical, Hospital, ArrowRight, MapPin, Calendar } from 'lucide-react';
import { Link } from 'react-router';

const projects = [
  {
    icon: Factory,
    image: 'https://images.unsplash.com/photo-1513828583688-c52b4e3f531f?w=800&q=85&auto=format&fit=crop',
    sectorTr: 'Otomotiv Yan Sanayi',
    sectorEn: 'Automotive Supplier',
    titleTr: 'Büyük Ölçekli Üretim Tesisi',
    titleEn: 'Large-Scale Manufacturing Facility',
    descTr: '42.000 m² kapalı alana sahip üretim tesisinde IEC 62305 Seviye I koruma. LPS tasarımı, SPD koordinasyonu ve topraklama sistemi.',
    descEn: '42,000 m² production facility with IEC 62305 Level I protection. LPS design, SPD coordination and earthing system.',
    locationTr: 'Marmara Bölgesi',
    locationEn: 'Marmara Region',
    year: '2024',
    tagsTr: ['IEC 62305 LPL I', 'SPD Tip 1+2', 'Topraklama'],
    tagsEn: ['IEC 62305 LPL I', 'SPD Type 1+2', 'Earthing'],
    accent: false,
  },
  {
    icon: Zap,
    image: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800&q=85&auto=format&fit=crop',
    sectorTr: 'Yenilenebilir Enerji',
    sectorEn: 'Renewable Energy',
    titleTr: '20 MWp Güneş Enerji Santrali',
    titleEn: '20 MWp Solar Power Plant',
    descTr: 'GES alanında yuvarlanan küre metodu ile risk analizi. Inverter ve trafolar için Tip 1 parafudr, çerçeve topraklaması.',
    descEn: 'Rolling sphere method risk analysis for solar plant. Type 1 SPD for inverters and transformers, frame earthing.',
    locationTr: 'Ege Bölgesi',
    locationEn: 'Aegean Region',
    year: '2024',
    tagsTr: ['GES', 'Risk Analizi', 'Yuvarlanan Küre'],
    tagsEn: ['Solar', 'Risk Analysis', 'Rolling Sphere'],
    accent: true,
  },
  {
    icon: FlaskConical,
    image: 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&q=85&auto=format&fit=crop',
    sectorTr: 'Petrokimya / ATEX',
    sectorEn: 'Petrochemical / ATEX',
    titleTr: 'Patlayıcı Ortam Sınıflandırma',
    titleEn: 'Explosive Atmosphere Classification',
    descTr: 'Zone 1 ve Zone 2 bölge sınıflandırması, ATEX uyumlu ekipman seçimi ve statik topraklama sistemleri.',
    descEn: 'Zone 1 and Zone 2 area classification, ATEX compliant equipment selection and static earthing systems.',
    locationTr: 'Akdeniz Bölgesi',
    locationEn: 'Mediterranean Region',
    year: '2023',
    tagsTr: ['ATEX Zone 1-2', 'Statik Topraklama', 'Bölge Sınıflandırma'],
    tagsEn: ['ATEX Zone 1-2', 'Static Earthing', 'Zone Classification'],
    accent: false,
  },
  {
    icon: Server,
    image: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=85&auto=format&fit=crop',
    sectorTr: 'Veri Merkezi',
    sectorEn: 'Data Center',
    titleTr: 'Tier III Veri Merkezi',
    titleEn: 'Tier III Data Center',
    descTr: '4 katlı veri merkezi binasında dahili ve harici LPS. EMC koruması, kafes yöntemi ve yalıtılmış paratoner sistemi.',
    descEn: '4-floor data center with internal and external LPS. EMC protection, mesh method and isolated lightning rod system.',
    locationTr: 'İç Anadolu',
    locationEn: 'Central Anatolia',
    year: '2023',
    tagsTr: ['Kafes Yöntemi', 'EMC', 'LPZ Koordinasyon'],
    tagsEn: ['Mesh Method', 'EMC', 'LPZ Coordination'],
    accent: false,
  },
  {
    icon: Hospital,
    image: 'https://images.unsplash.com/photo-1538108149393-dbcfd851b89d?w=800&q=85&auto=format&fit=crop',
    sectorTr: 'Sağlık',
    sectorEn: 'Healthcare',
    titleTr: 'Bölge Devlet Hastanesi',
    titleEn: 'Regional Public Hospital',
    descTr: 'Kritik tıbbi ekipman koruması için LPZ 2-3 bölge koordinasyonu. Kesintisiz güç sistemleri için özel SPD tasarımı.',
    descEn: 'LPZ 2-3 zone coordination for critical medical equipment protection. Custom SPD design for uninterruptible power systems.',
    locationTr: 'Karadeniz Bölgesi',
    locationEn: 'Black Sea Region',
    year: '2023',
    tagsTr: ['LPZ 2-3', 'Kritik Tesis', 'SPD Tasarım'],
    tagsEn: ['LPZ 2-3', 'Critical Facility', 'SPD Design'],
    accent: false,
  },
  {
    icon: Building2,
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800&q=85&auto=format&fit=crop',
    sectorTr: 'Lojistik / Depolama',
    sectorEn: 'Logistics / Warehousing',
    titleTr: 'E-Ticaret Dağıtım Merkezi',
    titleEn: 'E-Commerce Distribution Center',
    descTr: '28.000 m² yüksek tavanlı depo. Otomatik depolama sistemleri için mesafe hesaplamaları ve izole LPS çözümü.',
    descEn: '28,000 m² high-ceiling warehouse. Separation distance calculations and isolated LPS for automated storage systems.',
    locationTr: 'Marmara Bölgesi',
    locationEn: 'Marmara Region',
    year: '2022',
    tagsTr: ['İzole LPS', 'Mesafe Hesabı', 'SPD Tip 2'],
    tagsEn: ['Isolated LPS', 'Sep. Distance', 'SPD Type 2'],
    accent: false,
  },
];

export function ProjectsSection() {
  const { language } = useI18n();
  const isEn = language === 'en';

  return (
    <section className="relative py-24 bg-background border-t border-border">
      <div
        className="absolute inset-0 opacity-[0.015]"
        style={{
          backgroundImage: 'linear-gradient(var(--ink-600) 1px, transparent 1px), linear-gradient(90deg, var(--ink-600) 1px, transparent 1px)',
          backgroundSize: '80px 80px',
        }}
      />
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.7 }}
        >
          <span
            className="text-xs font-medium text-accent uppercase mb-4 block"
            style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.14em' }}
          >
            {isEn ? 'Selected Projects' : 'Seçili Projeler'}
          </span>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <h2 className="text-foreground max-w-lg">
              {isEn ? 'Projects We Completed' : 'Tamamladığımız Projeler'}
            </h2>
            <p className="text-muted-foreground max-w-md md:text-right" style={{ fontWeight: 300 }}>
              {isEn
                ? 'Each project referenced anonymously per client confidentiality agreements.'
                : 'Her proje, müşteri gizlilik anlaşmaları gereğince anonim referans verilmektedir.'}
            </p>
          </div>
          <div className="w-16 h-0.5 bg-accent mt-6" />
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: index * 0.07 }}
              className={`group relative flex flex-col border transition-all duration-300 hover:-translate-y-1 ${
                project.accent
                  ? 'border-accent bg-accent/5 hover:bg-accent/8'
                  : 'border-border bg-card hover:border-accent'
              }`}
            >
              {/* Proje fotoğrafı */}
              <div className="relative h-44 overflow-hidden">
                <img
                  src={project.image}
                  alt={isEn ? project.titleEn : project.titleTr}
                  width={600}
                  height={176}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/60 to-transparent" />
                {project.accent && <div className="absolute top-0 left-0 right-0 h-0.5 bg-accent" />}
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full" />
              </div>

              <div className="p-6 flex flex-col gap-4 flex-1">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 flex items-center justify-center border transition-colors duration-300 flex-shrink-0 ${
                    project.accent ? 'border-accent bg-accent/15' : 'border-border group-hover:border-accent'
                  }`}>
                    <project.icon className="w-5 h-5 text-accent" strokeWidth={2} />
                  </div>
                  <span
                    className="text-xs text-muted-foreground uppercase"
                    style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.1em' }}
                  >
                    {isEn ? project.sectorEn : project.sectorTr}
                  </span>
                </div>
                <h3 className="text-foreground leading-tight group-hover:text-accent transition-colors duration-200">
                  {isEn ? project.titleEn : project.titleTr}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed flex-1" style={{ fontWeight: 300 }}>
                  {isEn ? project.descEn : project.descTr}
                </p>
                <div className="flex flex-wrap gap-2">
                  {(isEn ? project.tagsEn : project.tagsTr).map((tag, i) => (
                    <span
                      key={i}
                      className="text-xs px-2 py-1 border border-border text-muted-foreground"
                      style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.06em' }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-border/50">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <MapPin className="w-3.5 h-3.5" strokeWidth={2} />
                    <span style={{ fontFamily: 'DM Mono, monospace' }}>
                      {isEn ? project.locationEn : project.locationTr}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Calendar className="w-3.5 h-3.5" strokeWidth={2} />
                    <span style={{ fontFamily: 'DM Mono, monospace' }}>{project.year}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="mt-12 flex flex-col sm:flex-row items-center justify-between gap-6 pt-8 border-t border-border"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <p className="text-muted-foreground text-sm" style={{ fontWeight: 300 }}>
            {isEn
              ? 'Selected examples. Contact us for sector-specific case studies.'
              : 'Seçili örneklerdir. Sektörünüze özel vaka çalışmaları için iletişime geçin.'}
          </p>
          <Link
            to="/iletisim"
            className="group inline-flex items-center gap-2 text-sm font-semibold text-accent hover:text-accent/80 transition-colors whitespace-nowrap"
            style={{ fontFamily: 'Barlow Condensed, sans-serif', letterSpacing: '0.06em', textTransform: 'uppercase' }}
          >
            {isEn ? 'Get a Quote' : 'Teklif Al'}
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" strokeWidth={2.5} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
