import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { MessageCircle, X } from 'lucide-react';

export function WhatsAppButton() {
  const [visible, setVisible] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        >
          {/* Tooltip */}
          <AnimatePresence>
            {showTooltip && (
              <motion.div
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.2 }}
                className="bg-card border border-border px-4 py-3 shadow-xl max-w-[200px]"
              >
                <p className="text-xs text-foreground leading-relaxed" style={{ fontWeight: 300 }}>
                  Hızlı teknik danışmanlık için WhatsApp'tan yazın.
                </p>
                <div className="absolute right-[-6px] top-1/2 -translate-y-1/2 w-3 h-3 bg-card border-r border-t border-border rotate-45" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Button */}
          <motion.a
            href="https://wa.me/905537206972?text=Merhaba%2C%20yıldırımdan%20korunma%20sistemi%20hakkında%20bilgi%20almak%20istiyorum."
            target="_blank"
            rel="noopener noreferrer"
            aria-label="WhatsApp ile iletişim"
            className="relative w-14 h-14 flex items-center justify-center shadow-2xl transition-transform duration-200 hover:scale-110 active:scale-95"
            style={{ backgroundColor: '#25D366', borderRadius: 0 }}
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            whileHover={{ y: -2 }}
          >
            {/* Ping animation */}
            <span className="absolute inset-0 animate-ping opacity-20" style={{ backgroundColor: '#25D366' }} />
            <MessageCircle className="w-7 h-7 text-white relative z-10" strokeWidth={2} />
          </motion.a>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
