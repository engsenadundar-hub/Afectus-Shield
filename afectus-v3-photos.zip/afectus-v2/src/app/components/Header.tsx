import { useLanguage, useI18n } from '../contexts/LanguageContext';
import { Link, useLocation, useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import { Menu, X, Mail, Phone, MessageCircle, ChevronDown, FileSearch, PenTool, Wrench, ClipboardCheck, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { analytics } from '../utils/analytics';
import { ContactBar } from './ContactBar';

interface NavItem {
  path: string;
  label: string;
  dropdown?: Array<{
    path: string;
    label: string;
    description: string;
    icon: React.ElementType;
  }>;
}

export function Header() {
  const { language, setLanguage } = useLanguage();
  const { t } = useI18n();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
    setActiveDropdown(null);
  }, [location.pathname]);

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileMenuOpen]);

  const handleLanguageChange = (newLang: 'tr' | 'en') => {
    if (newLang !== language) {
      analytics.trackLanguageSwitch(language, newLang);
      setLanguage(newLang);
    }
  };

  const serviceDropdownItems = language === 'tr' ? [
    {
      path: '/hizmetler/risk-analizi',
      label: 'Risk Analizi',
      description: 'IEC 62305-2 standardına göre kapsamlı risk değerlendirmesi',
      icon: FileSearch,
    },
    {
      path: '/hizmetler/muhendislik-tasarimi',
      label: 'Mühendislik Tasarımı',
      description: 'Tesise özel LPS sistem tasarımı ve EMO onaylı proje',
      icon: PenTool,
    },
    {
      path: '/hizmetler/uygulama-montaj',
      label: 'Uygulama & Montaj',
      description: 'Sertifikalı ekip ile profesyonel sistem kurulumu',
      icon: Wrench,
    },
    {
      path: '/hizmetler/test-olcum',
      label: 'Test & Ölçüm',
      description: 'Kurulum sonrası kapsamlı test ve ölçüm hizmetleri',
      icon: ClipboardCheck,
    },
    {
      path: '/hizmetler/bakim-denetim',
      label: 'Bakım & Denetim',
      description: 'Periyodik bakım ve IEC 62305 uyumluluk denetimi',
      icon: ShieldAlert,
    },
  ] : [
    {
      path: '/hizmetler/risk-analizi',
      label: 'Risk Analysis',
      description: 'Comprehensive risk assessment per IEC 62305-2 standard',
      icon: FileSearch,
    },
    {
      path: '/hizmetler/muhendislik-tasarimi',
      label: 'Engineering Design',
      description: 'Facility-specific LPS system design and EMO-approved project',
      icon: PenTool,
    },
    {
      path: '/hizmetler/uygulama-montaj',
      label: 'Application & Installation',
      description: 'Professional system installation with certified team',
      icon: Wrench,
    },
    {
      path: '/hizmetler/test-olcum',
      label: 'Testing & Measurement',
      description: 'Comprehensive post-installation testing and measurement',
      icon: ClipboardCheck,
    },
    {
      path: '/hizmetler/bakim-denetim',
      label: 'Maintenance & Inspection',
      description: 'Periodic maintenance and IEC 62305 compliance inspection',
      icon: ShieldAlert,
    },
  ];

  const navItems: NavItem[] = [
    { path: '/', label: t('header.nav.home') },
    { path: '/hakkimizda', label: t('header.nav.about') },
    {
      path: '/hizmetler',
      label: t('header.nav.services'),
      dropdown: serviceDropdownItems,
    },
    { path: '/surec', label: t('header.nav.process') },
    { path: '/sektorler', label: t('header.nav.industries') },
    { path: '/blog', label: t('header.nav.blog') },
    { path: '/iletisim', label: t('header.nav.contact') },
  ];

  const isActivePath = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <>
      <ContactBar />
      <motion.header
        className={`fixed top-[40px] left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'backdrop-blur-md border-b' : 'bg-transparent'
        }`}
        style={scrolled ? { background: 'rgba(17,19,24,0.95)', borderColor: 'var(--ink-600)' } : {}}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between gap-4">

            {/* Logo */}
            <div className="flex items-center flex-shrink-0">
              <Link to="/" className="relative group flex items-center" aria-label={t('header.nav.home')}>
                <div className="flex items-center justify-center">
                  <img
                    src="/logo.png"
                    alt="Afectus Shield Logo"
                    width={180}
                    height={60}
                    className="h-8 md:h-10 w-auto transition-all duration-200"
                    style={{ filter: 'brightness(0) invert(1)' }}
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                      if (fallback) fallback.style.display = 'flex';
                    }}
                  />
                  <div className="hidden items-center gap-2">
                    <div className="w-1 h-8 bg-accent"></div>
                    <span style={{ fontFamily: 'Barlow Condensed, sans-serif', fontWeight: 800, fontSize: '1.25rem', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--ink-50)' }}>
                      AFECTUS <span style={{ color: 'var(--red-500)' }}>SHIELD</span>
                    </span>
                  </div>
                </div>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              {navItems.map((item) => (
                <div
                  key={item.path}
                  className="relative"
                  onMouseEnter={() => item.dropdown && setActiveDropdown(item.path)}
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <Link
                    to={item.path}
                    className={`text-sm font-semibold uppercase tracking-wider transition-colors duration-200 hover:text-accent relative flex items-center gap-1 ${
                      isActivePath(item.path) ? 'text-accent' : 'text-foreground'
                    }`}
                  >
                    {item.label}
                    {item.dropdown && (
                      <motion.span
                        animate={{ rotate: activeDropdown === item.path ? 180 : 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <ChevronDown className="w-3 h-3" />
                      </motion.span>
                    )}
                    {isActivePath(item.path) && (
                      <motion.div
                        layoutId="activeTab"
                        className="absolute -bottom-1 left-0 right-0 h-0.5 bg-accent"
                        initial={false}
                        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                      />
                    )}
                  </Link>

                  {/* ── İKONLU KART DROPDOWN ── */}
                  <AnimatePresence>
                    {item.dropdown && activeDropdown === item.path && (
                      <motion.div
                        initial={{ opacity: 0, y: -8, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -8, scale: 0.98 }}
                        transition={{ duration: 0.18, ease: 'easeOut' }}
                        className="absolute top-full left-1/2 -translate-x-1/2 mt-3 z-50"
                        style={{ width: '320px' }}
                      >
                        {/* Ok/üçgen */}
                        <div
                          className="absolute left-1/2 -translate-x-1/2 -top-1.5 w-3 h-3 rotate-45 border-l border-t"
                          style={{
                            background: 'var(--card, #161B24)',
                            borderColor: 'var(--ink-600, #2D3748)',
                          }}
                        />

                        <div
                          className="border shadow-2xl overflow-hidden"
                          style={{
                            background: 'var(--card, #161B24)',
                            borderColor: 'var(--ink-600, #2D3748)',
                          }}
                        >
                          {/* Üst kırmızı şerit */}
                          <div className="h-0.5 bg-accent w-full" />

                          <div className="py-2">
                            {item.dropdown.map((dropItem, idx) => {
                              const Icon = dropItem.icon;
                              return (
                                <Link
                                  key={dropItem.path}
                                  to={dropItem.path}
                                  className="flex items-center gap-3 px-4 py-3 group transition-all duration-150 hover:bg-accent/8"
                                  style={{
                                    borderBottom: idx < item.dropdown!.length - 1
                                      ? '1px solid var(--ink-700, #1E2533)'
                                      : 'none',
                                  }}
                                >
                                  {/* İkon kutu */}
                                  <div
                                    className="flex-shrink-0 w-9 h-9 flex items-center justify-center transition-all duration-150 group-hover:bg-accent"
                                    style={{
                                      background: 'var(--ink-700, #1E2533)',
                                    }}
                                  >
                                    <Icon
                                      className="w-4 h-4 transition-colors duration-150 group-hover:text-white"
                                      style={{ color: 'var(--accent, #E63946)' }}
                                      strokeWidth={2}
                                    />
                                  </div>

                                  {/* Metin */}
                                  <div className="flex flex-col min-w-0">
                                    <span
                                      className="text-sm font-semibold leading-tight transition-colors duration-150 group-hover:text-accent"
                                      style={{ color: 'var(--ink-50, #F8F9FA)' }}
                                    >
                                      {dropItem.label}
                                    </span>
                                    <span
                                      className="text-xs leading-snug mt-0.5 truncate"
                                      style={{ color: 'var(--ink-400, #8A9BB3)' }}
                                    >
                                      {dropItem.description}
                                    </span>
                                  </div>
                                </Link>
                              );
                            })}
                          </div>

                          {/* Alt: Tüm hizmetler linki */}
                          <div
                            className="px-4 py-2.5 border-t"
                            style={{ borderColor: 'var(--ink-600, #2D3748)', background: 'var(--ink-800, #0D1017)' }}
                          >
                            <Link
                              to="/hizmetler"
                              className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider transition-colors duration-150 hover:text-accent"
                              style={{ color: 'var(--ink-400, #8A9BB3)' }}
                            >
                              <span>{language === 'tr' ? 'Tüm Hizmetleri Gör' : 'View All Services'}</span>
                              <span className="text-accent">→</span>
                            </Link>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-3">
              {/* Language Toggle */}
              <div className="flex items-center gap-1 bg-card/50 border border-border p-1">
                <button
                  onClick={() => handleLanguageChange('tr')}
                  className={`px-3 py-1 text-xs font-bold transition-all duration-200 ${
                    language === 'tr' ? 'bg-accent text-white' : 'text-muted-foreground hover:text-foreground'
                  }`}
                  aria-label={t('header.language.turkish')}
                >
                  TR
                </button>
                <button
                  onClick={() => handleLanguageChange('en')}
                  className={`px-3 py-1 text-xs font-bold transition-all duration-200 ${
                    language === 'en' ? 'bg-accent text-white' : 'text-muted-foreground hover:text-foreground'
                  }`}
                  aria-label={t('header.language.english')}
                >
                  EN
                </button>
              </div>

              {/* Contact Actions - Desktop */}
              <div className="hidden md:flex items-center gap-2">
                <a
                  href="tel:+905537206972"
                  onClick={() => analytics.trackPhoneClick()}
                  className="p-2 border border-border hover:border-accent hover:bg-accent/10 transition-all duration-200 group"
                  aria-label={t('header.cta.call')}
                >
                  <Phone className="w-4 h-4 text-foreground group-hover:text-accent" strokeWidth={2.5} />
                </a>

                <a
                  href="https://wa.me/905537206972"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => analytics.trackWhatsAppClick()}
                  className="p-2 border border-border hover:border-accent hover:bg-accent/10 transition-all duration-200 group"
                  aria-label="WhatsApp"
                >
                  <MessageCircle className="w-4 h-4 text-foreground group-hover:text-accent" strokeWidth={2.5} />
                </a>

                <Link
                  to="/iletisim"
                  className="bg-accent text-white px-4 py-2 text-sm font-semibold hover:bg-[#B91C2C] transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0"
                >
                  {t('header.cta.getQuote')}
                </Link>
              </div>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 border border-border hover:border-accent transition-colors"
                aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6 text-foreground" strokeWidth={2.5} />
                ) : (
                  <Menu className="w-6 h-6 text-foreground" strokeWidth={2.5} />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="lg:hidden mt-4 pt-4 border-t border-border overflow-hidden"
              >
                <nav className="flex flex-col gap-1">
                  {navItems.map((item) => (
                    <div key={item.path}>
                      <Link
                        to={item.path}
                        className={`flex items-center justify-between px-4 py-3 text-sm font-semibold uppercase tracking-wider transition-all duration-200 border-l-2 ${
                          isActivePath(item.path)
                            ? 'border-accent bg-accent/10 text-accent'
                            : 'border-transparent hover:border-accent hover:bg-accent/5 text-foreground'
                        }`}
                        onClick={() => {
                          if (item.dropdown) {
                            setActiveDropdown(activeDropdown === item.path ? null : item.path);
                          }
                        }}
                      >
                        {item.label}
                        {item.dropdown && (
                          <motion.span
                            animate={{ rotate: activeDropdown === item.path ? 180 : 0 }}
                            transition={{ duration: 0.2 }}
                          >
                            <ChevronDown className="w-4 h-4" />
                          </motion.span>
                        )}
                      </Link>

                      {/* Mobile Dropdown — ikonlu */}
                      <AnimatePresence>
                        {item.dropdown && activeDropdown === item.path && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            {item.dropdown.map((dropItem) => {
                              const Icon = dropItem.icon;
                              return (
                                <Link
                                  key={dropItem.path}
                                  to={dropItem.path}
                                  className="flex items-center gap-3 pl-6 pr-4 py-2.5 group transition-all duration-150 hover:bg-accent/8 border-l-2 border-accent/20 ml-4"
                                >
                                  <div
                                    className="flex-shrink-0 w-7 h-7 flex items-center justify-center"
                                    style={{ background: 'var(--ink-700, #1E2533)' }}
                                  >
                                    <Icon
                                      className="w-3.5 h-3.5"
                                      style={{ color: 'var(--accent, #E63946)' }}
                                      strokeWidth={2}
                                    />
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="text-xs font-semibold text-foreground group-hover:text-accent transition-colors">
                                      {dropItem.label}
                                    </span>
                                    <span className="text-xs" style={{ color: 'var(--ink-400, #8A9BB3)' }}>
                                      {dropItem.description}
                                    </span>
                                  </div>
                                </Link>
                              );
                            })}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </nav>

                {/* Mobile Contact Actions */}
                <div className="mt-4 pt-4 border-t border-border space-y-3">
                  <a
                    href="tel:+905537206972"
                    onClick={() => analytics.trackPhoneClick()}
                    className="flex items-center gap-3 px-4 py-3 border border-border hover:border-accent hover:bg-accent/10 transition-all duration-200"
                  >
                    <Phone className="w-5 h-5 text-accent" strokeWidth={2.5} />
                    <span className="text-sm font-semibold text-foreground">{t('header.cta.call')}</span>
                  </a>

                  <a
                    href="https://wa.me/905537206972"
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => analytics.trackWhatsAppClick()}
                    className="flex items-center gap-3 px-4 py-3 border border-border hover:border-accent hover:bg-accent/10 transition-all duration-200"
                  >
                    <MessageCircle className="w-5 h-5 text-accent" strokeWidth={2.5} />
                    <span className="text-sm font-semibold text-foreground">WhatsApp</span>
                  </a>

                  <Link
                    to="/iletisim"
                    className="block text-center bg-accent text-white px-6 py-3 text-sm font-semibold hover:bg-[#B91C2C] transition-colors"
                  >
                    {t('header.cta.getQuote')}
                  </Link>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.header>
    </>
  );
}
