import { motion } from 'motion/react';
import { Home } from 'lucide-react';
import { Link } from 'react-router';
import { useI18n } from '../contexts/LanguageContext';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  breadcrumbs?: Array<{ label: string; path?: string }>;
  imagePath?: string;
  fallbackImage?: string;
}

export function PageHeader({ 
  title, 
  subtitle, 
  breadcrumbs, 
  imagePath,
  fallbackImage = 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=1920&h=600&fit=crop'
}: PageHeaderProps) {
  const { t } = useI18n();

  // Eğer imagePath verilmişse onu kullan, yoksa fallback'e dön
  const backgroundImage = imagePath || fallbackImage;

  return (
    <section className="relative h-[400px] flex items-center justify-center overflow-hidden border-b-4 border-accent pt-[100px] md:pt-[120px]">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ 
          backgroundImage: `url('${backgroundImage}')`,
          backgroundPosition: 'center',
          backgroundSize: 'cover'
        }}
      >
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A0E1A]/80 via-[#0A0E1A]/70 to-[#0A0E1A]/90"></div>
        
        {/* Accent Overlay */}
        <div className="absolute inset-0 bg-accent/10"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
        {/* Breadcrumbs */}
        {breadcrumbs && breadcrumbs.length > 0 && (
          <motion.nav
            className="flex items-center justify-center gap-2 mb-6 text-sm"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <Link 
              to="/" 
              className="flex items-center gap-1 text-white/70 hover:text-accent transition-colors"
            >
              <Home className="w-4 h-4" />
              <span>{t('header.nav.home')}</span>
            </Link>
            {breadcrumbs.map((crumb, index) => (
              <div key={index} className="flex items-center gap-2">
                <span className="text-white/50">/</span>
                {crumb.path ? (
                  <Link 
                    to={crumb.path}
                    className="text-white/70 hover:text-accent transition-colors"
                  >
                    {crumb.label}
                  </Link>
                ) : (
                  <span className="text-white font-semibold">{crumb.label}</span>
                )}
              </div>
            ))}
          </motion.nav>
        )}

        {/* Title */}
        <motion.h1
          className="text-white mb-4"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {title}
        </motion.h1>

        {/* Subtitle */}
        {subtitle && (
          <motion.p
            className="text-lg text-white/90 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            {subtitle}
          </motion.p>
        )}

        {/* Accent Line */}
        <motion.div
          className="w-24 h-1 bg-accent mx-auto mt-6"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        />
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0A0E1A] to-transparent"></div>
    </section>
  );
}