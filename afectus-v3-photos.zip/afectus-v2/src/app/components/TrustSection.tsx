import { useI18n } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { FileCheck, ShieldCheck, TrendingUp } from 'lucide-react';

export function TrustSection() {
  const { t } = useI18n();

  const trustItems = [
    {
      icon: FileCheck,
      key: 'emo',
    },
    {
      icon: ShieldCheck,
      key: 'insurance',
    },
    {
      icon: TrendingUp,
      key: 'compliance',
    },
  ];

  return (
    <section className="relative py-24 bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {trustItems.map((item, index) => (
            <motion.div
              key={index}
              className="group relative"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div className="flex flex-col items-center text-center p-8 border border-border bg-background transition-all duration-300 hover:border-accent hover:-translate-y-1">
                <div className="w-16 h-16 flex items-center justify-center border border-border mb-6 transition-all duration-300 group-hover:border-accent">
                  <item.icon
                    className="w-8 h-8 text-muted-foreground transition-colors duration-300 group-hover:text-accent"
                    strokeWidth={2}
                  />
                </div>
                <div className="text-5xl font-extrabold text-foreground mb-2 transition-colors duration-300 group-hover:text-accent" style={{ fontFamily: "Barlow Condensed, sans-serif", letterSpacing: "-0.02em" }}>
                  {t(`trust.${item.key}.title`)}
                </div>
                <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                  {t(`trust.${item.key}.desc`)}
                </p>
                {/* Additional info for each card */}
                <div className="mt-3 flex flex-col gap-1">
                  <p className="text-xs font-semibold text-accent">
                    {t(`trust.${item.key}.detail1`)}
                  </p>
                  <p className="text-xs font-medium text-muted-foreground">
                    {t(`trust.${item.key}.detail2`)}
                  </p>
                </div>
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full"></div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}