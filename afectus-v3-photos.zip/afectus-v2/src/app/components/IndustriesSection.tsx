import { useI18n } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Factory, Zap, ShoppingCart, Server, Flame, Hospital } from 'lucide-react';

const INDUSTRY_PHOTOS = [
  'https://images.unsplash.com/photo-1581244936167-05c94e8ed71a?w=600&q=85&auto=format&fit=crop', // Factory
  'https://images.unsplash.com/photo-1466611653911-0265b1d1a1b1?w=600&q=85&auto=format&fit=crop', // Energy/Power
  'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=600&q=85&auto=format&fit=crop', // Commercial building
  'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&q=85&auto=format&fit=crop',  // Data center
  'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=600&q=85&auto=format&fit=crop', // Petrochemical
  'https://images.unsplash.com/photo-1519494026892-476079a9e9e0?w=600&q=85&auto=format&fit=crop', // Healthcare
];

export function IndustriesSection() {
  const { t } = useI18n();

  const industries = [
    { icon: Factory, key: 'industrial' },
    { icon: Zap, key: 'energy' },
    { icon: ShoppingCart, key: 'commercial' },
    { icon: Server, key: 'residential' },
    { icon: Flame, key: 'telecom' },
    { icon: Hospital, key: 'healthcare' },
  ];

  return (
    <section id="industries" className="relative py-24 bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
            {t('industriesSection.title')}
          </span>
          <h2 className="text-foreground">
            {t('industriesSection.heading')}
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {industries.map((industry, index) => (
            <motion.div
              key={index}
              className="group relative overflow-hidden"
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.07 }}
            >
              {/* Fotoğraf arka plan */}
              <div className="relative h-52 overflow-hidden">
                <img
                  src={INDUSTRY_PHOTOS[index]}
                  alt={t(`industriesSection.items.${industry.key}`)}
                  width={600}
                  height={208}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {/* Koyu overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-background/20 transition-opacity duration-300" />
                {/* Hover kırmızı overlay */}
                <div className="absolute inset-0 bg-accent/0 group-hover:bg-accent/10 transition-all duration-300" />
                {/* Alt kırmızı şerit */}
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full" />
              </div>

              {/* İçerik */}
              <div className="absolute inset-0 flex flex-col items-center justify-end pb-6 px-6">
                <div className="w-12 h-12 border border-border/60 flex items-center justify-center mb-3 transition-all duration-300 group-hover:border-accent bg-background/60 backdrop-blur-sm">
                  <industry.icon
                    className="w-6 h-6 text-muted-foreground transition-colors duration-300 group-hover:text-accent"
                    strokeWidth={2}
                  />
                </div>
                <p className="text-center text-sm text-foreground font-semibold transition-colors duration-300 group-hover:text-accent">
                  {t(`industriesSection.items.${industry.key}`)}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
