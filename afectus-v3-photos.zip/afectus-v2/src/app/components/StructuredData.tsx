import { Helmet } from 'react-helmet-async';

interface StructuredDataProps {
  type?: 'Organization' | 'WebPage' | 'Article' | 'Service' | 'FAQPage' | 'LocalBusiness';
  pageTitle?: string;
  pageDescription?: string;
  datePublished?: string;
  dateModified?: string;
}

export function StructuredData({
  type = 'WebPage',
  pageTitle,
  pageDescription,
  datePublished,
  dateModified,
}: StructuredDataProps) {
  // ENHANCED ORGANIZATION DATA with full details
  const organizationData = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Afectus Shield',
    legalName: 'Afectus Shield Yıldırım Koruma Sistemleri',
    description: 'Professional Lightning Protection Systems compliant with IEC 62305 and TS EN standards. Risk analysis, engineering design, installation, testing, and maintenance services for industrial facilities.',
    url: 'https://www.afectusshield.com',
    logo: {
      '@type': 'ImageObject',
      url: 'https://www.afectusshield.com/logo.png',
      width: 250,
      height: 60,
    },
    image: 'https://www.afectusshield.com/og-image.jpg',
    telephone: '+90-553-720-6972',
    email: 'info@afectusshield.com',
    address: {
      '@type': 'PostalAddress',
      addressCountry: 'TR',
      addressLocality: 'İstanbul',
      addressRegion: 'İstanbul',
      postalCode: '34000',
      streetAddress: 'İstanbul, Türkiye',
    },
    contactPoint: [
      {
        '@type': 'ContactPoint',
        telephone: '+90-553-720-6972',
        contactType: 'Customer Service',
        contactOption: 'TollFree',
        areaServed: ['TR', 'EU', 'ME'],
        availableLanguage: ['Turkish', 'English'],
        hoursAvailable: {
          '@type': 'OpeningHoursSpecification',
          dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
          opens: '09:00',
          closes: '18:00',
        },
      },
      {
        '@type': 'ContactPoint',
        telephone: '+90-553-720-6972',
        contactType: 'Technical Support',
        areaServed: 'TR',
        availableLanguage: ['Turkish', 'English'],
      },
      {
        '@type': 'ContactPoint',
        telephone: '+90-553-720-6972',
        contactType: 'Sales',
        areaServed: 'TR',
        availableLanguage: ['Turkish', 'English'],
      },
    ],
    sameAs: [
      'https://www.linkedin.com/company/afectusshield',
      'https://www.instagram.com/afectusshield',
      'https://wa.me/905537206972',
    ],
    foundingDate: '2020',
    areaServed: {
      '@type': 'Country',
      name: 'Turkey',
    },
    slogan: 'Professional Lightning Protection Systems',
    knowsAbout: [
      'Lightning Protection',
      'IEC 62305',
      'TS EN 62305',
      'Risk Analysis',
      'Electrical Engineering',
      'Industrial Safety',
      'ATEX Zones',
      'Explosive Atmospheres Protection',
    ],
    serviceArea: {
      '@type': 'GeoCircle',
      geoMidpoint: {
        '@type': 'GeoCoordinates',
        latitude: 41.0082,
        longitude: 28.9784,
      },
      geoRadius: '1000',
    },
  };

  const webPageData = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: pageTitle || 'Afectus Shield - Professional Lightning Protection Systems',
    description:
      pageDescription ||
      'IEC 62305 & TS EN compliant lightning protection systems. Risk analysis, engineering design, installation, testing and maintenance services for industrial facilities.',
    url: typeof window !== 'undefined' ? window.location.href : 'https://www.afectusshield.com',
    inLanguage: ['tr-TR', 'en-US'],
    isPartOf: {
      '@type': 'WebSite',
      name: 'Afectus Shield',
      url: 'https://www.afectusshield.com',
    },
    publisher: {
      '@type': 'Organization',
      name: 'Afectus Shield',
      logo: {
        '@type': 'ImageObject',
        url: 'https://www.afectusshield.com/logo.png',
      },
    },
    breadcrumb: {
      '@type': 'BreadcrumbList',
      itemListElement: [
        {
          '@type': 'ListItem',
          position: 1,
          name: 'Ana Sayfa',
          item: 'https://www.afectusshield.com',
        },
      ],
    },
  };

  const serviceData = {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: pageTitle || 'Lightning Protection Services',
    description:
      pageDescription || 'Comprehensive lightning protection system design, installation, testing and maintenance',
    provider: {
      '@type': 'Organization',
      name: 'Afectus Shield',
      telephone: '+90-553-720-6972',
      email: 'info@afectusshield.com',
    },
    areaServed: {
      '@type': 'Country',
      name: 'Turkey',
    },
    serviceType: 'Lightning Protection Systems',
    offers: {
      '@type': 'Offer',
      availability: 'https://schema.org/InStock',
      priceSpecification: {
        '@type': 'PriceSpecification',
        priceCurrency: 'TRY',
      },
    },
  };

  const articleData = datePublished
    ? {
        '@context': 'https://schema.org',
        '@type': 'Article',
        headline: pageTitle,
        description: pageDescription,
        datePublished: datePublished,
        dateModified: dateModified || datePublished,
        author: {
          '@type': 'Organization',
          name: 'Afectus Shield',
        },
        publisher: {
          '@type': 'Organization',
          name: 'Afectus Shield',
          logo: {
            '@type': 'ImageObject',
            url: 'https://www.afectusshield.com/logo.png',
          },
        },
        mainEntityOfPage: {
          '@type': 'WebPage',
          '@id': typeof window !== 'undefined' ? window.location.href : 'https://www.afectusshield.com',
        },
      }
    : null;

  // FAQ Page Schema
  const faqData = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: 'Yıldırımdan korunma sistemi nedir?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Yıldırımdan korunma sistemi, yapıları ve içindeki insanları yıldırım çarpmasının tehlikeli etkilerinden korumak için tasarlanmış bir dizi önlemdir. IEC 62305 ve TS EN standartlarına uygun olarak tasarlanır.',
        },
      },
      {
        '@type': 'Question',
        name: 'IEC 62305 standardı nedir?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'IEC 62305, yıldırımdan korunma sistemlerinin tasarımı, kurulumu ve bakımı için uluslararası standarttır. Risk analizi, koruma seviyesi belirleme ve sistem tasarımı için gereksinimleri tanımlar.',
        },
      },
      {
        '@type': 'Question',
        name: 'LPL (Lightning Protection Level) nedir?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'LPL (Yıldırım Koruma Seviyesi), binanın risk durumuna göre belirlenen koruma seviyesidir. LPL I (en yüksek koruma) ile LPL IV (standart koruma) arasında değişir.',
        },
      },
    ],
  };

  let structuredData;
  switch (type) {
    case 'Organization':
      structuredData = organizationData;
      break;
    case 'Service':
      structuredData = serviceData;
      break;
    case 'Article':
      structuredData = articleData;
      break;
    case 'FAQPage':
      structuredData = faqData;
      break;
    default:
      structuredData = webPageData;
  }

  return (
    <Helmet>
      <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
    </Helmet>
  );
}
