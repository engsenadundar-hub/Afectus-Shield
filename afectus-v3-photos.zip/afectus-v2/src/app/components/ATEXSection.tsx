import { useI18n, useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { Flame, Wind, AlertTriangle, Shield } from 'lucide-react';
import { ArrowRight } from 'lucide-react';

export function ATEXSection() {
  const { t } = useI18n();
  const { language } = useLanguage();

  const atexZones = [
    {
      icon: Flame,
      index: 0,
      color: 'from-red-600 to-red-700',
      bgColor: 'bg-red-600/10',
      borderColor: 'border-red-600/30',
      textColor: 'text-red-500',
    },
    {
      icon: Flame,
      index: 1,
      color: 'from-red-700 to-red-800',
      bgColor: 'bg-accent/10',
      borderColor: 'border-accent/30',
      textColor: 'text-accent',
    },
    {
      icon: Wind,
      index: 2,
      color: 'from-yellow-600 to-yellow-700',
      bgColor: 'bg-yellow-600/10',
      borderColor: 'border-yellow-600/30',
      textColor: 'text-yellow-500',
    },
    {
      icon: Flame,
      index: 0,
      color: 'from-red-700 to-red-800',
      bgColor: 'bg-red-700/10',
      borderColor: 'border-red-700/30',
      textColor: 'text-red-600',
    },
    {
      icon: Flame,
      index: 1,
      color: 'from-red-800 to-red-900',
      bgColor: 'bg-accent/10',
      borderColor: 'border-accent/30',
      textColor: 'text-accent',
    },
    {
      icon: Wind,
      index: 2,
      color: 'from-yellow-700 to-yellow-800',
      bgColor: 'bg-yellow-700/10',
      borderColor: 'border-yellow-700/30',
      textColor: 'text-yellow-600',
    },
  ];

  return (
    <section className="relative py-24 bg-card border-t border-border overflow-hidden">
      {/* Background pattern */}
      <div
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `
            linear-gradient(45deg, #E63946 1px, transparent 1px),
            linear-gradient(-45deg, #E63946 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Shield className="w-8 h-8 text-accent" strokeWidth={2.5} />
            <span className="text-xs font-medium text-accent uppercase mb-4 block" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
              {t('atex.title')}
            </span>
          </div>
          <h2 className="text-foreground mb-6">
            {t('atex.heading')}
          </h2>
          <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            {t('atex.description')}
          </p>
        </motion.div>

        {/* ATEX Zone Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {atexZones.map((zone, index) => (
            <motion.div
              key={index}
              className="group relative"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <div className={`relative border ${zone.borderColor} ${zone.bgColor} p-8 transition-all duration-300 group-hover:border-accent group-hover:-translate-y-1`}>
                {/* Icon */}
                <div className={`w-16 h-16 border ${zone.borderColor} flex items-center justify-center mb-6`}>
                  <zone.icon className={`w-8 h-8 ${zone.textColor}`} strokeWidth={2.5} />
                </div>

                {/* Zone Number */}
                <h3 className={`text-2xl font-bold ${zone.textColor} mb-2 transition-colors duration-300 group-hover:text-accent`}>
                  {t(`atex.zones.${zone.index}.zone`)}
                </h3>

                {/* Type */}
                <p className="text-sm font-semibold text-foreground mb-3 uppercase tracking-wide">
                  {t(`atex.zones.${zone.index}.type`)}
                </p>

                {/* Description */}
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {t(`atex.zones.${zone.index}.desc`)}
                </p>

                {/* Bottom accent line */}
                <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${zone.color} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300`} />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Industries requiring ATEX */}
        <motion.div
          className="border border-border bg-background p-8 mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <AlertTriangle className="w-6 h-6 text-accent" strokeWidth={2.5} />
            <h3 className="text-xl font-bold text-foreground uppercase">
              {t('atex.industries.title')}
            </h3>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <div key={index} className="flex items-center gap-3 text-muted-foreground hover:text-foreground transition-colors duration-200">
                <div className="w-2 h-2 bg-accent"></div>
                <span className="text-sm text-muted-foreground">
                  {t(`atex.industries.items.${index}`)}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* ATEX Consultation Form */}
        <motion.div
          className="border border-accent bg-card p-8 lg:p-12"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-3">
              {language === 'tr' ? 'ATEX Danışmanlığı Talebi' : 'ATEX Consultation Request'}
            </h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              {language === 'tr' 
                ? 'Patlayıcı ortam sınıflandırması ve ATEX uyumluluğu hakkında ücretsiz ön değerlendirme için formu doldurun.'
                : 'Fill out the form for a free preliminary assessment on explosive atmosphere classification and ATEX compliance.'}
            </p>
          </div>

          <form 
            name="atex-consultation" 
            method="POST" 
            data-netlify="true"
            netlify-honeypot="bot-field"
            className="max-w-3xl mx-auto space-y-6"
          >
            <input type="hidden" name="form-name" value="atex-consultation" />
            <p className="hidden">
              <label>
                Don't fill this out if you're human: <input name="bot-field" />
              </label>
            </p>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="atex-name" className="block text-sm font-semibold text-foreground mb-2">
                  {language === 'tr' ? 'Ad Soyad *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  id="atex-name"
                  name="name"
                  required
                  className="w-full px-4 py-3 bg-background border border-border focus:border-accent focus:outline-none transition-colors text-foreground"
                />
              </div>

              <div>
                <label htmlFor="atex-company" className="block text-sm font-semibold text-foreground mb-2">
                  {language === 'tr' ? 'Firma Adı *' : 'Company Name *'}
                </label>
                <input
                  type="text"
                  id="atex-company"
                  name="company"
                  required
                  className="w-full px-4 py-3 bg-background border border-border focus:border-accent focus:outline-none transition-colors text-foreground"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="atex-email" className="block text-sm font-semibold text-foreground mb-2">
                  {language === 'tr' ? 'E-posta *' : 'Email *'}
                </label>
                <input
                  type="email"
                  id="atex-email"
                  name="email"
                  required
                  className="w-full px-4 py-3 bg-background border border-border focus:border-accent focus:outline-none transition-colors text-foreground"
                />
              </div>

              <div>
                <label htmlFor="atex-phone" className="block text-sm font-semibold text-foreground mb-2">
                  {language === 'tr' ? 'Telefon *' : 'Phone *'}
                </label>
                <input
                  type="tel"
                  id="atex-phone"
                  name="phone"
                  required
                  className="w-full px-4 py-3 bg-background border border-border focus:border-accent focus:outline-none transition-colors text-foreground"
                />
              </div>
            </div>

            <div>
              <label htmlFor="atex-industry" className="block text-sm font-semibold text-foreground mb-2">
                {language === 'tr' ? 'Sektör / Faaliyet Alanı *' : 'Industry / Field of Activity *'}
              </label>
              <select
                id="atex-industry"
                name="industry"
                required
                className="w-full px-4 py-3 bg-background border border-border focus:border-accent focus:outline-none transition-colors text-foreground"
              >
                <option value="">{language === 'tr' ? 'Seçiniz...' : 'Select...'}</option>
                <option value="petrol-gaz">{language === 'tr' ? 'Petrol ve Gaz Rafinerileri' : 'Oil and Gas Refineries'}</option>
                <option value="kimya">{language === 'tr' ? 'Kimyasal Üretim Tesisleri' : 'Chemical Production Facilities'}</option>
                <option value="ilac">{language === 'tr' ? 'İlaç Sanayii' : 'Pharmaceutical Industry'}</option>
                <option value="gida">{language === 'tr' ? 'Gıda İşleme Tesisleri' : 'Food Processing Facilities'}</option>
                <option value="boya">{language === 'tr' ? 'Boya ve Kaplama Fabrikaları' : 'Paint and Coating Factories'}</option>
                <option value="maden">{language === 'tr' ? 'Maden İşletmeleri' : 'Mining Operations'}</option>
                <option value="diger">{language === 'tr' ? 'Diğer' : 'Other'}</option>
              </select>
            </div>

            <div>
              <label htmlFor="atex-message" className="block text-sm font-semibold text-foreground mb-2">
                {language === 'tr' ? 'Mesajınız / Proje Detayları' : 'Your Message / Project Details'}
              </label>
              <textarea
                id="atex-message"
                name="message"
                rows={5}
                className="w-full px-4 py-3 bg-background border border-border focus:border-accent focus:outline-none transition-colors text-foreground resize-none"
              ></textarea>
            </div>

            <div className="text-center">
              <button
                type="submit"
                className="bg-accent text-white px-10 py-4 font-bold uppercase tracking-wider hover:bg-[#B91C2C] transition-all duration-300 hover:-translate-y-0.5 inline-flex items-center gap-2"
              >
                {language === 'tr' ? 'Talep Gönder' : 'Send Request'}
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
}