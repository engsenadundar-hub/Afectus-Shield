import { useI18n } from '../contexts/LanguageContext';

export function SkipToContent() {
  const { t } = useI18n();
  
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[100] focus:px-4 focus:py-2 focus:bg-accent focus:text-white focus:font-semibold focus:shadow-lg"
    >
      {t('skipToContent')}
    </a>
  );
}