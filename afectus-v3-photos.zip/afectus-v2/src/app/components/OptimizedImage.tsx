import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

interface OptimizedImageProps {
  src: string;
  alt: string;
  className?: string;
  width?: number;
  height?: number;
  priority?: boolean;
  objectFit?: 'cover' | 'contain' | 'fill' | 'none' | 'scale-down';
}

export function OptimizedImage({
  src,
  alt,
  className = '',
  width,
  height,
  priority = false,
  objectFit = 'cover',
}: OptimizedImageProps) {
  const [imageSrc, setImageSrc] = useState<string>('');
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    // Create WebP version URL (if backend supports it)
    // For now, use original src
    setImageSrc(src);
  }, [src]);

  const handleLoad = () => {
    setImageLoaded(true);
  };

  const handleError = () => {
    setImageError(true);
    setImageLoaded(true);
  };

  // Placeholder blur effect
  const placeholderSrc = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ${width || 400} ${height || 300}'%3E%3Crect width='100%25' height='100%25' fill='%230A0E1A'/%3E%3C/svg%3E`;

  return (
    <div className={`relative overflow-hidden ${className}`} style={{ width, height }}>
      {/* Placeholder */}
      {!imageLoaded && (
        <div
          className="absolute inset-0 bg-gradient-to-br from-background via-card to-background animate-pulse"
          style={{ width: '100%', height: '100%' }}
        />
      )}

      {/* Main Image */}
      {!imageError ? (
        <motion.img
          src={imageSrc}
          alt={alt}
          className={`w-full h-full transition-opacity duration-500 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ objectFit }}
          loading={priority ? 'eager' : 'lazy'}
          decoding="async"
          onLoad={handleLoad}
          onError={handleError}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ 
            opacity: imageLoaded ? 1 : 0,
            scale: imageLoaded ? 1 : 1.05
          }}
          transition={{ duration: 0.5 }}
        />
      ) : (
        // Error fallback
        <div className="absolute inset-0 flex items-center justify-center bg-card border border-border">
          <div className="text-center px-4">
            <svg
              className="w-12 h-12 text-muted-foreground mx-auto mb-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
              />
            </svg>
            <p className="text-xs text-muted-foreground">Image not available</p>
          </div>
        </div>
      )}

      {/* Loading overlay */}
      {!imageLoaded && !imageError && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-accent border-t-transparent rounded-full animate-spin" />
        </div>
      )}
    </div>
  );
}

// Responsive Picture component with multiple sources
interface ResponsiveImageProps {
  src: string;
  srcMobile?: string;
  srcTablet?: string;
  alt: string;
  className?: string;
  priority?: boolean;
}

export function ResponsiveImage({
  src,
  srcMobile,
  srcTablet,
  alt,
  className = '',
  priority = false,
}: ResponsiveImageProps) {
  return (
    <picture>
      {/* Mobile */}
      {srcMobile && (
        <source media="(max-width: 640px)" srcSet={srcMobile} />
      )}
      
      {/* Tablet */}
      {srcTablet && (
        <source media="(max-width: 1024px)" srcSet={srcTablet} />
      )}
      
      {/* Desktop */}
      <OptimizedImage
        src={src}
        alt={alt}
        className={className}
        priority={priority}
      />
    </picture>
  );
}
