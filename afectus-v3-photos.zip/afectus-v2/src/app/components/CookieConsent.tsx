import { useState, useEffect } from 'react';
import { useI18n } from '../contexts/LanguageContext';
import { Shield } from 'lucide-react';
import { Link } from 'react-router';
import { motion } from 'motion/react';

export function CookieConsent() {
  const { t } = useI18n();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      // Delay showing the banner
      setTimeout(() => setIsVisible(true), 1000);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setIsVisible(false);
  };

  const handleReject = () => {
    localStorage.setItem('cookieConsent', 'rejected');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed bottom-0 left-0 right-0 z-[100] bg-[#0A0E1A] border-t-2 border-accent shadow-2xl"
      role="dialog"
      aria-label="Cookie Consent Banner"
    >
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-start gap-4">
              <Shield className="w-6 h-6 text-accent flex-shrink-0 mt-1" strokeWidth={2.5} />
              <div>
                <h3 className="text-lg font-bold text-[#E8EAED] mb-2 uppercase tracking-wide">
                  {t('cookieConsent.title')}
                </h3>
                <p className="text-sm text-[#BFC1C6] leading-relaxed">
                  {t('cookieConsent.description')}
                  {' '}
                  <Link
                    to="/gizlilik-politikasi"
                    className="text-accent font-semibold hover:underline transition-all duration-200"
                  >
                    {t('cookieConsent.privacyPolicy')}
                  </Link>
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0">
            <button
              onClick={handleReject}
              className="px-6 py-3 border-2 border-[#3C4043] text-[#E8EAED] font-semibold uppercase tracking-wide transition-all duration-300 hover:bg-[#3C4043] hover:border-accent hover:text-white"
            >
              {t('cookieConsent.reject')}
            </button>
            <button
              onClick={handleAccept}
              className="px-6 py-3 bg-accent text-white font-semibold uppercase tracking-wide transition-all duration-300 hover:bg-[#B91C2C] shadow-lg hover:shadow-xl"
            >
              {t('cookieConsent.accept')}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}