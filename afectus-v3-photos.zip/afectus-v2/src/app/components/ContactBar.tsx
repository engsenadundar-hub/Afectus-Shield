import { Mail, Phone, Linkedin, Instagram, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';

export function ContactBar() {
  return (
    <motion.div
      className="fixed top-0 left-0 right-0 z-[60] border-b border-border"
      style={{
        height: '40px',
        background: 'var(--ink-950)',
        borderLeft: '3px solid var(--red-500)',
      }}
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-full">
        <div className="flex items-center justify-between gap-3 sm:gap-6 h-full">
          {/* Sol: sosyal medya */}
          <div className="flex items-center gap-4">
            <a
              href="https://www.linkedin.com/company/afectus-shield"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs text-ink-400 hover:text-accent transition-colors duration-200"
              style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.08em' }}
              aria-label="LinkedIn"
            >
              <Linkedin className="w-3.5 h-3.5" strokeWidth={2} />
              <span className="hidden lg:inline">LinkedIn</span>
            </a>
            <a
              href="https://www.instagram.com/afectusshield"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs text-ink-400 hover:text-accent transition-colors duration-200"
              style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.08em' }}
              aria-label="Instagram"
            >
              <Instagram className="w-3.5 h-3.5" strokeWidth={2} />
              <span className="hidden lg:inline">Instagram</span>
            </a>
            <a
              href="https://wa.me/905537206972"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs text-ink-400 hover:text-accent transition-colors duration-200"
              style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.08em' }}
              aria-label="WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5" strokeWidth={2} />
              <span className="hidden lg:inline">WhatsApp</span>
            </a>
          </div>

          {/* Sağ: iletişim */}
          <div className="flex items-center gap-4 sm:gap-6">
            <a
              href="mailto:info@afectusshield.com"
              className="flex items-center gap-2 text-xs text-ink-300 hover:text-accent transition-colors duration-200"
              style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.06em' }}
            >
              <Mail className="w-3.5 h-3.5" strokeWidth={2} />
              <span className="hidden md:inline">info@afectusshield.com</span>
            </a>
            <a
              href="tel:+905537206972"
              className="flex items-center gap-2 text-xs text-ink-300 hover:text-accent transition-colors duration-200"
              style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.06em' }}
            >
              <Phone className="w-3.5 h-3.5" strokeWidth={2} />
              <span className="hidden md:inline">+90 (553) 720 69 72</span>
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
