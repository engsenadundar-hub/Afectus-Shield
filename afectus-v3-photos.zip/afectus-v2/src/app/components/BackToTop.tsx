import { useState, useEffect } from 'react';
import { ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function BackToTop() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      // Use window.scrollY (modern) instead of window.pageYOffset (deprecated)
      if (window.scrollY > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    // Check immediately on mount
    toggleVisibility();

    window.addEventListener('scroll', toggleVisibility, { passive: true });

    return () => {
      window.removeEventListener('scroll', toggleVisibility);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 20 }}
          transition={{ duration: 0.3 }}
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 z-40 w-12 h-12 bg-[#E63946] hover:bg-[#B91C2C] border-2 border-[#E63946] hover:border-[#00D9FF] flex items-center justify-center group transition-all duration-300 shadow-lg hover:shadow-2xl"
          aria-label="Back to top"
        >
          <ChevronUp 
            className="w-6 h-6 text-white group-hover:scale-110 transition-transform" 
            strokeWidth={3} 
          />
        </motion.button>
      )}
    </AnimatePresence>
  );
}