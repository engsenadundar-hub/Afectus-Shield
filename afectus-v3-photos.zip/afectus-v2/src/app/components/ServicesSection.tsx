import { useI18n } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { FileSearch, PenTool, Wrench, ClipboardCheck, ShieldAlert, Zap, Cable, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router';

export function ServicesSection() {
  const { t } = useI18n();

  const services = [
    {
      icon: FileSearch,
      key: 'riskAnalysis',
      image: 'https://images.unsplash.com/photo-1581093196277-8b9e9c5e0e5a?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: PenTool,
      key: 'design',
      image: 'https://images.unsplash.com/photo-1453023795691-9b2b92a39c9e?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: Wrench,
      key: 'installation',
      image: 'https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: ClipboardCheck,
      key: 'testing',
      image: 'https://images.unsplash.com/photo-1581093450021-4a7360e9c6e3?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: ShieldAlert,
      key: 'maintenance',
      image: 'https://images.unsplash.com/photo-1565814636199-ae8133055c1c?w=800&q=85&auto=format&fit=crop',
    },
  ];

  const systemComponents = [
    {
      icon: Zap,
      key: 'lps',
      image: 'https://images.unsplash.com/photo-1602193438882-fedb6b7c72b9?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: Cable,
      key: 'spm',
      image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=85&auto=format&fit=crop',
    },
    {
      icon: ShieldCheck,
      key: 'spd',
      image: 'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?w=800&q=85&auto=format&fit=crop',
    },
  ];

  return (
    <section id="services" className="relative py-24 bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-xs font-medium text-accent uppercase tracking-wider" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }} className="text-xs mb-4 block">
            {t('servicesSection.title')}
          </span>
          <h2 className="text-foreground mb-6">{t('servicesSection.heading')}</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            {t('servicesSection.description')}
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="group relative overflow-hidden border border-border bg-background transition-all duration-300 hover:border-accent hover:-translate-y-1"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              {/* Card content */}
              <div className="p-8 relative z-10">
                {/* Animated grid background on hover */}
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-300"
                  style={{
                    backgroundImage: `
                      linear-gradient(to right, #E63946 1px, transparent 1px),
                      linear-gradient(to bottom, #E63946 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px',
                  }}
                />

                <div className="relative">
                  <div className="w-14 h-14 flex items-center justify-center border border-border mb-6 transition-all duration-300 group-hover:border-accent">
                    <service.icon className="w-7 h-7 text-muted-foreground transition-colors duration-300 group-hover:text-accent" strokeWidth={2.5} />
                  </div>
                  <h3 className="text-foreground mb-3">{t(`servicesSection.items.${service.key}.title`)}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{t(`servicesSection.items.${service.key}.desc`)}</p>
                </div>
              </div>

              {/* Bottom accent line */}
              <div className="absolute bottom-0 left-0 w-0 h-1 bg-accent transition-all duration-300 group-hover:w-full" />
            </motion.div>
          ))}
        </div>

        {/* CTA Button */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
        >
          <Link
            to="/hizmetler"
            className="inline-flex items-center justify-center border-2 border-border text-foreground px-8 py-4 font-semibold transition-all duration-200 hover:border-accent hover:text-accent hover:-translate-y-1"
          >
            {t('servicesSection.viewAll')}
          </Link>
        </motion.div>
      </div>

      {/* System Components Section */}
      <div className="max-w-7xl mx-auto px-6 mt-24 pt-24 border-t border-border">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-xs font-medium text-accent uppercase tracking-wider" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }} className="text-xs mb-4 block">
            {t('servicesSection.systemComponents.title')}
          </span>
          <h2 className="text-foreground mb-6">
            {t('servicesSection.systemComponents.heading')}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {t('servicesSection.systemComponents.description')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {systemComponents.map((component, index) => (
            <motion.div
              key={index}
              className="group relative overflow-hidden border border-border bg-background transition-all duration-300 hover:border-accent hover:-translate-y-1"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              {/* Component Image */}
              <div className="h-56 overflow-hidden relative">
                <img 
                  src={component.image}
                  alt={t(`servicesSection.systemComponents.${component.key}.title`)}
                  width={600}
                  height={224}
                  loading="lazy"
                  className="w-full h-full object-cover transition-all duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent"></div>
              </div>

              {/* Content */}
              <div className="p-8 relative">
                {/* Grid overlay on hover */}
                <div
                  className="absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-5"
                  style={{
                    backgroundImage: `
                      linear-gradient(to right, #E63946 1px, transparent 1px),
                      linear-gradient(to bottom, #E63946 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px',
                  }}
                />

                <div className="relative">
                  <div className="w-14 h-14 flex items-center justify-center border border-border mb-6 transition-all duration-300 group-hover:border-accent">
                    <component.icon className="w-7 h-7 text-muted-foreground transition-colors duration-300 group-hover:text-accent" strokeWidth={2.5} />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-4">
                    {t(`servicesSection.systemComponents.${component.key}.title`)}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {t(`servicesSection.systemComponents.${component.key}.desc`)}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}