import { useI18n, useLanguage } from '../contexts/LanguageContext';
import { Link } from 'react-router';
import { Mail, Phone, MapPin, Linkedin, Instagram, MessageCircle } from 'lucide-react';

export function Footer() {
  const { t } = useI18n();
  const { language } = useLanguage();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-background border-t border-accent py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8 sm:gap-10 lg:gap-12 mb-8 sm:mb-12">
          {/* Logo & About */}
          <div className="lg:col-span-2">
            <div className="mb-4">
              <img
                src="/logo.png"
                alt="Afectus Shield"
                width={160}
                height={54}
                className="h-8 w-auto mb-3"
                style={{ filter: 'brightness(0) invert(1)' }}
                onError={(e) => {
                  const el = e.currentTarget;
                  el.style.display = 'none';
                  const next = el.nextElementSibling as HTMLElement;
                  if (next) next.style.display = 'block';
                }}
              />
              <span className="hidden text-lg font-bold tracking-tight text-foreground" style={{ fontFamily: 'Barlow Condensed, sans-serif' }}>
                AFECTUS SHIELD
              </span>
              <div className="w-12 h-0.5 bg-accent mt-2"></div>
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed mb-6">
              {t('footer.company.description')}
            </p>
            
            {/* Social Media Links */}
            <div className="flex items-center gap-3">
              <a
                href="https://wa.me/905537206972"
                target="_blank"
                rel="noopener noreferrer"
                className="group w-10 h-10 flex items-center justify-center border border-border hover:border-[#25D366] transition-all duration-300"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-5 h-5 text-muted-foreground group-hover:text-[#25D366] transition-colors duration-300" strokeWidth={2} />
              </a>
              <a
                href="https://www.linkedin.com/company/afectusshield"
                target="_blank"
                rel="noopener noreferrer"
                className="group w-10 h-10 flex items-center justify-center border border-border hover:border-accent transition-all duration-300"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5 text-muted-foreground group-hover:text-accent transition-colors duration-300" strokeWidth={2} />
              </a>
              <a
                href="https://www.instagram.com/afectusshield"
                target="_blank"
                rel="noopener noreferrer"
                className="group w-10 h-10 flex items-center justify-center border border-border hover:border-accent transition-all duration-300"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5 text-muted-foreground group-hover:text-accent transition-colors duration-300" strokeWidth={2} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <div className="text-foreground mb-4 uppercase tracking-wider text-xs sm:text-sm font-semibold">
              {t('footer.quickLinks.title')}
            </div>
            <nav className="space-y-2 sm:space-y-3">
              <Link
                to="/hakkimizda"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.quickLinks.about')}
              </Link>
              <Link
                to="/surec"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.quickLinks.process')}
              </Link>
              <Link
                to="/sektorler"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.quickLinks.industries')}
              </Link>
              <Link
                to="/blog"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('header.nav.blog')}
              </Link>
              <Link
                to="/iletisim"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.quickLinks.contact')}
              </Link>
            </nav>
          </div>

          {/* Services */}
          <div>
            <div className="text-foreground mb-4 uppercase tracking-wider text-xs sm:text-sm font-semibold">
              {t('footer.services.title')}
            </div>
            <nav className="space-y-2 sm:space-y-3">
              <Link
                to="/hizmetler"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('header.nav.services')}
              </Link>
              <Link
                to="/hizmetler/risk-analizi"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.services.riskAnalysis')}
              </Link>
              <Link
                to="/hizmetler/muhendislik-tasarim"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.services.design')}
              </Link>
              <Link
                to="/hizmetler/montaj-uygulama"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.services.installation')}
              </Link>
              <Link
                to="/hizmetler/test-olcum"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.services.testing')}
              </Link>
              <Link
                to="/hizmetler/bakim-denetim"
                className="block text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.services.maintenance')}
              </Link>
            </nav>
          </div>

          {/* Contact Info */}
          <div>
            <div className="text-foreground mb-4 uppercase tracking-wider text-xs sm:text-sm font-semibold">
              {t('footer.contact.title')}
            </div>
            <div className="space-y-3 sm:space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 sm:w-5 h-4 sm:h-5 text-accent flex-shrink-0 mt-0.5" strokeWidth={2} />
                <span className="text-xs sm:text-sm text-muted-foreground">
                  {t('footer.contact.address')}
                </span>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="w-4 sm:w-5 h-4 sm:h-5 text-accent flex-shrink-0 mt-0.5" strokeWidth={2} />
                <a
                  href="tel:+905537206972"
                  className="text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200"
                >
                  {t('footer.contact.phone')}
                </a>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-4 sm:w-5 h-4 sm:h-5 text-accent flex-shrink-0 mt-0.5" strokeWidth={2} />
                <a
                  href="mailto:info@afectusshield.com"
                  className="text-xs sm:text-sm text-muted-foreground hover:text-accent transition-colors duration-200 break-all"
                >
                  {t('footer.contact.email')}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 sm:pt-8 border-t border-border">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-xs sm:text-sm text-muted-foreground text-center md:text-left">
              <p className="mb-1">{t('footer.copyright', { year: currentYear })}</p>
              <p className="text-xs text-muted-foreground/70">{t('footer.department')}</p>
            </div>
            
            {/* Legal Links */}
            <nav className="flex flex-wrap justify-center gap-3 sm:gap-4 text-xs sm:text-sm">
              <Link
                to="/kvkk"
                className="text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.legal.kvkk')}
              </Link>
              <Link
                to="/gizlilik-politikasi"
                className="text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.legal.privacy')}
              </Link>
              <Link
                to="/cerez-politikasi"
                className="text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.legal.cookies')}
              </Link>
              <Link
                to="/aydinlatma-metni"
                className="text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {t('footer.legal.disclosure')}
              </Link>
            </nav>
          </div>
        </div>
      </div>
    </footer>
  );
}