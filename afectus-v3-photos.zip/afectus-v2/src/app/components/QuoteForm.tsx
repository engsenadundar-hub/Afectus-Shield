import { useState } from 'react';
import { motion } from 'motion/react';
import { useI18n } from '../contexts/LanguageContext';
import { Send, CheckCircle2, Phone } from 'lucide-react';

interface QuoteFormProps {
  serviceTr?: string;
  serviceEn?: string;
}

export function QuoteForm({ serviceTr = '', serviceEn = '' }: QuoteFormProps) {
  const { language } = useI18n();
  const isEn = language === 'en';

  const [data, setData] = useState({ name: '', email: '', phone: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!data.name || !data.email) return;
    setSubmitting(true);
    try {
      const encode = (d: Record<string, string>) =>
        Object.keys(d).map(k => encodeURIComponent(k) + '=' + encodeURIComponent(d[k])).join('&');
      const res = await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encode({ 'form-name': 'teklif', service: serviceTr || serviceEn, ...data }),
      });
      if (res.ok) {
        setSubmitted(true);
      } else {
        throw new Error();
      }
    } catch {
      setError(isEn ? 'Could not send. Please call us.' : 'Gönderilemedi. Lütfen arayın.');
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="border border-accent bg-accent/5 p-8 text-center"
      >
        <CheckCircle2 className="w-12 h-12 text-accent mx-auto mb-4" strokeWidth={1.5} />
        <h3 className="text-foreground mb-2">{isEn ? 'Request Received' : 'Talebiniz Alındı'}</h3>
        <p className="text-muted-foreground text-sm" style={{ fontWeight: 300 }}>
          {isEn
            ? 'We will get back to you within 24 hours.'
            : '24 saat içinde size geri dönüş yapacağız.'}
        </p>
      </motion.div>
    );
  }

  return (
    <section className="py-16 bg-card border-t border-border">
      <div className="max-w-3xl mx-auto px-6">
        <div className="mb-8">
          <span
            className="text-xs font-medium text-accent uppercase mb-3 block"
            style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.14em' }}
          >
            {isEn ? 'Quick Quote' : 'Hızlı Teklif'}
          </span>
          <h2 className="text-foreground">
            {isEn ? 'Request a Quote for This Service' : 'Bu Hizmet İçin Teklif Alın'}
          </h2>
          <div className="w-12 h-0.5 bg-accent mt-4" />
        </div>

        <form
          name="teklif"
          method="POST"
          data-netlify="true"
          data-netlify-honeypot="bot-field"
          onSubmit={handleSubmit}
          className="space-y-4"
        >
          <input type="hidden" name="form-name" value="teklif" />
          <input type="hidden" name="service" value={serviceTr || serviceEn} />
          <p className="hidden"><input name="bot-field" /></p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-muted-foreground mb-2" style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.1em' }}>
                {isEn ? 'Full Name *' : 'Ad Soyad *'}
              </label>
              <input
                type="text"
                name="name"
                required
                value={data.name}
                onChange={e => setData({ ...data, name: e.target.value })}
                className="w-full bg-background border border-border px-4 py-3 text-foreground text-sm focus:border-accent focus:outline-none transition-colors"
                placeholder={isEn ? 'Your name' : 'Adınız'}
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-2" style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.1em' }}>
                {isEn ? 'Email *' : 'E-posta *'}
              </label>
              <input
                type="email"
                name="email"
                required
                value={data.email}
                onChange={e => setData({ ...data, email: e.target.value })}
                className="w-full bg-background border border-border px-4 py-3 text-foreground text-sm focus:border-accent focus:outline-none transition-colors"
                placeholder={isEn ? 'your@email.com' : 'e-posta@adresiniz.com'}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-muted-foreground mb-2" style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.1em' }}>
              {isEn ? 'Phone' : 'Telefon'}
            </label>
            <input
              type="tel"
              name="phone"
              value={data.phone}
              onChange={e => setData({ ...data, phone: e.target.value })}
              className="w-full bg-background border border-border px-4 py-3 text-foreground text-sm focus:border-accent focus:outline-none transition-colors"
              placeholder="+90 5xx xxx xx xx"
            />
          </div>

          <div>
            <label className="block text-xs text-muted-foreground mb-2" style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.1em' }}>
              {isEn ? 'Message' : 'Mesaj'}
            </label>
            <textarea
              name="message"
              rows={4}
              value={data.message}
              onChange={e => setData({ ...data, message: e.target.value })}
              className="w-full bg-background border border-border px-4 py-3 text-foreground text-sm focus:border-accent focus:outline-none transition-colors resize-none"
              placeholder={isEn ? 'Brief description of your facility and requirements...' : 'Tesisiniz ve ihtiyacınız hakkında kısa bilgi...'}
            />
          </div>

          {error && <p className="text-sm text-accent">{error}</p>}

          <div className="flex flex-col sm:flex-row gap-4 items-center pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="group inline-flex items-center gap-3 bg-accent text-white px-8 py-4 font-semibold transition-all duration-200 hover:bg-[#B91C2C] disabled:opacity-60 disabled:cursor-not-allowed hover:-translate-y-0.5"
            >
              <Send className="w-4 h-4" strokeWidth={2.5} />
              {submitting
                ? (isEn ? 'Sending...' : 'Gönderiliyor...')
                : (isEn ? 'Send Request' : 'Teklif Talep Et')}
            </button>
            <a
              href="tel:+905537206972"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors"
              style={{ fontFamily: 'DM Mono, monospace', letterSpacing: '0.06em' }}
            >
              <Phone className="w-4 h-4" strokeWidth={2} />
              0553 720 69 72
            </a>
          </div>
        </form>
      </div>
    </section>
  );
}
