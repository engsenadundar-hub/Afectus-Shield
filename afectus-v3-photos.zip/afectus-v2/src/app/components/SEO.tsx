import { useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useLocation } from 'react-router';

interface SEOProps {
  titleTr?: string;
  titleEn?: string;
  title?: string;
  descriptionTr?: string;
  descriptionEn?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  canonical?: string;
  type?: 'website' | 'article' | 'product' | 'service';
  schema?: any;
}

export function SEO({ 
  titleTr,
  titleEn,
  title, 
  descriptionTr,
  descriptionEn,
  description, 
  keywords,
  ogImage = 'https://afectusshield.com/og-image.jpg',
  canonical,
  type = 'website',
  schema
}: SEOProps) {
  const { language } = useLanguage();
  const location = useLocation();

  // Default SEO content
  const defaultTitleTr = 'Afectus Shield - Endüstriyel Yıldırımdan Korunma Sistemleri | IEC 62305';
  const defaultTitleEn = 'Afectus Shield - Industrial Lightning Protection Systems | IEC 62305';
  
  const defaultDescriptionTr = 'IEC 62305 ve TS EN standartlarına uygun profesyonel yıldırımdan korunma sistemleri. Risk analizi, mühendislik tasarımı ve sertifikalı uygulama hizmetleri. ATEX, GES-RES, fabrikalar için özel çözümler.';
  const defaultDescriptionEn = 'Professional lightning protection systems compliant with IEC 62305 & TS EN standards. Risk analysis, engineering design and certified implementation services. Specialized solutions for ATEX, solar-wind energy, industrial facilities.';
  
  const defaultKeywordsTr = 'yıldırımdan korunma, paratoner, IEC 62305, TS EN, risk analizi, lightning protection, endüstriyel güvenlik, elektrik güvenliği, ATEX, GES, RES, topraklama, surge protection, SPD, LPS, Gebze, Kocaeli';
  const defaultKeywordsEn = 'lightning protection, lightning rod, IEC 62305, TS EN, risk analysis, industrial safety, electrical safety, ATEX, solar energy, wind energy, grounding, surge protection, SPD, LPS, Turkey';

  // Support both titleTr/titleEn and title props
  const pageTitle = title || 
    (language === 'tr' ? (titleTr || defaultTitleTr) : (titleEn || defaultTitleEn));
  const pageDescription = description || 
    (language === 'tr' ? (descriptionTr || defaultDescriptionTr) : (descriptionEn || defaultDescriptionEn));
  const pageKeywords = keywords || (language === 'tr' ? defaultKeywordsTr : defaultKeywordsEn);
  
  // Build full URL for canonical and og:url
  const baseUrl = 'https://afectusshield.com';
  const fullUrl = `${baseUrl}${location.pathname}`;
  const canonicalUrl = canonical || fullUrl;

  useEffect(() => {
    // Update document title
    document.title = pageTitle;

    // Update HTML lang attribute
    document.documentElement.lang = language === 'tr' ? 'tr' : 'en';

    // Update or create meta tags
    const updateMetaTag = (name: string, content: string, isProperty = false) => {
      const attribute = isProperty ? 'property' : 'name';
      let meta = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
      
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, name);
        document.head.appendChild(meta);
      }
      
      meta.content = content;
    };

    // Standard meta tags
    updateMetaTag('description', pageDescription);
    updateMetaTag('keywords', pageKeywords);
    updateMetaTag('author', 'Afectus Shield');
    updateMetaTag('robots', 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
    updateMetaTag('language', language === 'tr' ? 'Turkish' : 'English');
    updateMetaTag('revisit-after', '7 days');
    updateMetaTag('rating', 'general');

    // Open Graph meta tags
    updateMetaTag('og:title', pageTitle, true);
    updateMetaTag('og:description', pageDescription, true);
    updateMetaTag('og:type', type, true);
    updateMetaTag('og:url', fullUrl, true);
    updateMetaTag('og:image', ogImage, true);
    updateMetaTag('og:image:width', '1200', true);
    updateMetaTag('og:image:height', '630', true);
    updateMetaTag('og:image:alt', pageTitle, true);
    updateMetaTag('og:locale', language === 'tr' ? 'tr_TR' : 'en_US', true);
    updateMetaTag('og:locale:alternate', language === 'tr' ? 'en_US' : 'tr_TR', true);
    updateMetaTag('og:site_name', 'Afectus Shield', true);

    // Twitter Card meta tags
    updateMetaTag('twitter:card', 'summary_large_image');
    updateMetaTag('twitter:title', pageTitle);
    updateMetaTag('twitter:description', pageDescription);
    updateMetaTag('twitter:image', ogImage);
    updateMetaTag('twitter:image:alt', pageTitle);

    // Mobile optimization
    let viewport = document.querySelector('meta[name="viewport"]') as HTMLMetaElement;
    if (!viewport) {
      viewport = document.createElement('meta');
      viewport.name = 'viewport';
      viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=5.0';
      document.head.appendChild(viewport);
    }

    // Theme color
    updateMetaTag('theme-color', '#E63946');
    updateMetaTag('msapplication-TileColor', '#0A0E1A');
    updateMetaTag('msapplication-navbutton-color', '#E63946');
    updateMetaTag('apple-mobile-web-app-status-bar-style', 'black-translucent');
    updateMetaTag('apple-mobile-web-app-capable', 'yes');

    // Add favicon links if they don't exist
    const addLink = (rel: string, href: string, type?: string, sizes?: string) => {
      let link = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement;
      
      if (!link) {
        link = document.createElement('link');
        link.rel = rel;
        document.head.appendChild(link);
      }
      
      link.href = href;
      if (type) link.type = type;
      if (sizes) link.setAttribute('sizes', sizes);
    };

    addLink('icon', '/favicon.svg', 'image/svg+xml');
    addLink('apple-touch-icon', '/favicon.svg', 'image/svg+xml', '180x180');

    // Add canonical link
    let canonicalLink = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.rel = 'canonical';
      document.head.appendChild(canonicalLink);
    }
    
    canonicalLink.href = canonicalUrl;

    // Add alternate language links
    const addAlternateLink = (hreflang: string, href: string) => {
      let link = document.querySelector(`link[hreflang="${hreflang}"]`) as HTMLLinkElement;
      
      if (!link) {
        link = document.createElement('link');
        link.rel = 'alternate';
        link.hreflang = hreflang;
        document.head.appendChild(link);
      }
      
      link.href = href;
    };

    addAlternateLink('tr', `${baseUrl}${location.pathname}`);
    addAlternateLink('x-default', `${baseUrl}${location.pathname}`);

    // Add structured data (Schema.org JSON-LD)
    if (schema) {
      let scriptTag = document.querySelector('script[type="application/ld+json"][data-page-schema]') as HTMLScriptElement;
      
      if (!scriptTag) {
        scriptTag = document.createElement('script');
        scriptTag.type = 'application/ld+json';
        scriptTag.setAttribute('data-page-schema', 'true');
        document.head.appendChild(scriptTag);
      }
      
      scriptTag.textContent = JSON.stringify(schema);
    }

    // Add BreadcrumbList schema for non-home pages
    if (location.pathname !== '/') {
      const breadcrumbSchema = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": language === 'tr' ? "Ana Sayfa" : "Home",
            "item": baseUrl
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": pageTitle.split(' - ')[0],
            "item": fullUrl
          }
        ]
      };

      let breadcrumbScript = document.querySelector('script[type="application/ld+json"][data-breadcrumb]') as HTMLScriptElement;
      
      if (!breadcrumbScript) {
        breadcrumbScript = document.createElement('script');
        breadcrumbScript.type = 'application/ld+json';
        breadcrumbScript.setAttribute('data-breadcrumb', 'true');
        document.head.appendChild(breadcrumbScript);
      }
      
      breadcrumbScript.textContent = JSON.stringify(breadcrumbSchema);
    }

  }, [pageTitle, pageDescription, pageKeywords, ogImage, language, canonicalUrl, fullUrl, location.pathname, type, schema, baseUrl]);

  return null;
}