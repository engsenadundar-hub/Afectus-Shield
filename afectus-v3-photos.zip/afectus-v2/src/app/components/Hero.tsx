import { useI18n } from '../contexts/LanguageContext';
import { motion, useScroll, useTransform } from 'motion/react';
import { Shield, FileCheck, ClipboardCheck, Building2, ArrowRight } from 'lucide-react';
import { Link } from 'react-router';
import { useRef } from 'react';

export function Hero() {
  const { t, language } = useI18n();
  const containerRef = useRef<HTMLElement>(null);
  
  // Parallax effect: background moves slower than content
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
    layoutEffect: false, // Use standard effect to avoid SSR issues
  });
  
  const backgroundY = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);
  const contentY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);

  const features = [
    {
      icon: Shield,
      key: 'hero.features.iec',
    },
    {
      icon: ClipboardCheck,
      key: 'hero.features.risk',
    },
    {
      icon: FileCheck,
      key: 'hero.features.cert',
    },
    {
      icon: Building2,
      key: 'hero.features.expertise',
    },
  ];

  return (
    <section ref={containerRef} className="relative min-h-[600px] md:min-h-screen flex items-center justify-center overflow-visible bg-background pt-[100px] md:pt-[120px]">
      {/* Background Image with Parallax */}
      <motion.div 
        className="absolute inset-0"
        style={{ y: backgroundY }}
      >
        <img 
          src="https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=1920&q=90&auto=format&fit=crop"
          alt="Bright lightning bolt striking through dramatic storm clouds"
          loading="eager"
          fetchPriority="high"
          width={1080}
          height={720}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/75 to-background/60"></div>
      </motion.div>

      {/* Blueprint Grid Background */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(to right, #E63946 1px, transparent 1px),
            linear-gradient(to bottom, #E63946 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />

      {/* Subtle Lightning Animation - Hide on mobile */}
      <motion.div
        className="absolute top-20 right-20 w-96 h-96 opacity-[0.05] hidden md:block"
        animate={{
          opacity: [0.03, 0.08, 0.03],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <path
            d="M50 10 L30 40 L45 40 L35 80 L65 45 L50 45 L70 10 Z"
            fill="none"
            stroke="#E63946"
            strokeWidth="0.5"
          />
        </svg>
      </motion.div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-32">
        <div className="max-w-4xl">
          {/* Main Heading */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          >
            <div className="inline-block mb-6 px-4 py-2 bg-accent/10 border border-accent">
              <span className="text-accent font-semibold text-sm tracking-wider uppercase" style={{ fontFamily: "DM Mono, monospace", letterSpacing: "0.14em" }}>
                {t('hero.subtitle')}
              </span>
            </div>
            
            <h1 className="text-foreground mb-6 leading-tight">
              {t('hero.title')}
            </h1>

            <p className="text-xl text-muted-foreground mb-12 max-w-3xl leading-relaxed">
              {t('hero.description')}
            </p>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Link
              to="/iletisim"
              className="group inline-flex items-center justify-center gap-3 bg-accent text-white px-8 py-4 font-semibold transition-all duration-300 hover:bg-[#B91C2C] hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0"
            >
              <span>{t('hero.cta.primary')}</span>
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" strokeWidth={2.5} />
            </Link>
            
            <Link
              to="/hizmetler"
              className="inline-flex items-center justify-center gap-3 border-2 border-accent text-accent px-8 py-4 font-semibold transition-all duration-300 hover:bg-accent hover:text-white hover:-translate-y-0.5 active:translate-y-0"
            >
              <span>{t('hero.cta.secondary')}</span>
            </Link>
          </motion.div>

          {/* Features Grid */}
          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            {features.map((feature, index) => (
              <motion.div
                key={feature.key}
                className="group relative bg-background/30 backdrop-blur-sm border border-border/50 p-6 hover:border-accent transition-all duration-300"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 + index * 0.1 }}
                whileHover={{ y: -4 }}
              >
                <div className="flex flex-col items-start gap-4">
                  <div className="w-12 h-12 bg-accent/10 border border-accent flex items-center justify-center group-hover:bg-accent/20 transition-colors duration-300">
                    <feature.icon className="w-6 h-6 text-accent" strokeWidth={2.5} />
                  </div>
                  <p className="text-sm text-foreground font-medium leading-tight">
                    {t(feature.key)}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-12 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="w-6 h-10 border-2 border-accent/50 rounded-full flex items-start justify-center p-2"
        >
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            className="w-1.5 h-1.5 bg-accent rounded-full"
          />
        </motion.div>
      </motion.div>
    </section>
  );
}